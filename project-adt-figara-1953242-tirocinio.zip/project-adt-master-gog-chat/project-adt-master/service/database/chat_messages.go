package database

import (
	"fmt"
	"time"
)

// ChatMessage rappresenta una riga nella tabella dei messaggi della chat.
type ChatMessage struct {
	ID          uint64
	ExerciseID  uint64
	SenderID    uint64
	ReceiverID  uint64
	Message     string
	Timestamp   time.Time
}

// GetMessagesByExerciseID recupera tutti i messaggi per una data esercitazione.
func (db *appdbimpl) GetMessagesByExerciseID(exerciseID uint64) ([]ChatMessage, error) {
	var messages []ChatMessage

	rows, err := db.c.Query(`
		SELECT id, exercise_id, sender_id, receiver_id, message, timestamp 
		FROM chat_messages 
		WHERE exercise_id=$1 
		ORDER BY timestamp ASC
	`, exerciseID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var msg ChatMessage
		if err := rows.Scan(&msg.ID, &msg.ExerciseID, &msg.SenderID, &msg.ReceiverID, &msg.Message, &msg.Timestamp); err != nil {
			return nil, err
		}
		messages = append(messages, msg)
	}

	if err := rows.Err(); err != nil {
		return nil, err
	}

	return messages, nil
}

// InsertMessage inserisce un nuovo messaggio nella tabella.
func (db *appdbimpl) InsertMessage(exerciseID, senderID, receiverID uint64, message string, timestamp time.Time) error {
	_, err := db.c.Exec(`
		INSERT INTO chat_messages (exercise_id, sender_id, receiver_id, message, timestamp) 
		VALUES ($1, $2, $3, $4, $5)
	`, exerciseID, senderID, receiverID, message, timestamp)
	return err
}
