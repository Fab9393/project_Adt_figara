package database

import (
	"golang.org/x/crypto/bcrypt"
	"time"
)
func (db *appdbimpl) CheckUserCredentials(email string, password string) (bool, error) {
	var hash string
	err := db.c.QueryRow("SELECT password FROM users WHERE email = $1", email).Scan(&hash)
	if err != nil {
		return false, err
	}

	err = bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
	if err != nil {
		return false, nil
	}

	return true, nil
}


func (db *appdbimpl) SaveSession(sessionID string, userID uint64, expiration time.Time) error {
    // controlla se la tabella sessions esiste nel database
    // se non esiste, creala

    // Fa la query SQL per salvare la sessione nel database
    _, err := db.c.Exec("INSERT INTO sessions (session_id, userID, expiration) VALUES ($1, $2, $3)", sessionID, userID, expiration)
    if err != nil {
        // Restituisci l'errore
        return err
    }

    // Restituisci nil se il salvataggio è andato a buon fine
    return nil  // Restituisci nil se il salvataggio è andato a buon fine
}
