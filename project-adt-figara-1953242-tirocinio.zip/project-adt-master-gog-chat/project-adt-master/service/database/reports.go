package database

import (
    "database/sql"
)

// ListReports returns a list of all reports
func  (db *appdbimpl) ListReports(exercitationId uint64) ([]Report, error) {
	var ret []Report
	rows, err := db.c.Query(`
		SELECT id, mitre_tactic_id, exercitation_id, team_id, issued_by, issued_when, target, attack_outcome, comments, type
		FROM reports
		WHERE exercitation_id = $1
		ORDER BY issued_when DESC
	`, exercitationId)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var r Report
		err := rows.Scan(
			&r.Id, &r.MitreTacticId, &r.ExercitationId, &r.TeamId, &r.IssuedBy, &r.IssuedWhen, &r.Target, &r.AttackOutcome, &r.Comments, &r.Type,
		)
		if err != nil {
			return nil, err
		}
		ret = append(ret, r)
	}
	return ret, nil
}

// ListRedTeamReports returns a list of all red team reports
func  (db *appdbimpl) ListRedTeamReports(exercitationId uint64) ([]Report, error) {
	var ret []Report
	rows, err := db.c.Query(`
		SELECT id, mitre_tactic_id, exercitation_id, team_id, issued_by, issued_when, target, attack_outcome, comments, type
		FROM reports
		WHERE exercitation_id = $1 AND type = false
		ORDER BY issued_when DESC
	`, exercitationId)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var r Report
		err := rows.Scan(
			&r.Id, &r.MitreTacticId, &r.ExercitationId, &r.TeamId, &r.IssuedBy, &r.IssuedWhen, &r.Target, &r.AttackOutcome, &r.Comments, &r.Type,
		)
		if err != nil {
			return nil, err
		}
		ret = append(ret, r)
	}
	return ret, nil
}

// ListBlueTeamReports returns a list of all blue team reports
func  (db *appdbimpl) ListBlueTeamReports(exercitationId uint64) ([]Report, error) {
	var ret []Report
	rows, err := db.c.Query(`
		SELECT id, mitre_tactic_id, exercitation_id, team_id, issued_by, issued_when, target, attack_outcome, comments, type
		FROM reports
		WHERE exercitation_id = $1 AND type = true
		ORDER BY issued_when DESC
	`, exercitationId)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var r Report
		err := rows.Scan(
			&r.Id, &r.MitreTacticId, &r.ExercitationId, &r.TeamId, &r.IssuedBy, &r.IssuedWhen, &r.Target, &r.AttackOutcome, &r.Comments, &r.Type,
		)
		if err != nil {
			return nil, err
		}
		ret = append(ret, r)
	}
	return ret, nil
}


// GetReport returns a single report
func  (db *appdbimpl) GetReport(reportId uint64) (Report, error) {
	var ret Report
	err := db.c.QueryRow(`
		SELECT id, mitre_tactic_id, exercitation_id, issued_by, issued_when, target, attack_outcome, comments, type
		FROM reports
		WHERE id = $1
	`, reportId).Scan(
		&ret.Id, &ret.MitreTacticId, &ret.ExercitationId, &ret.IssuedBy, &ret.IssuedWhen, &ret.Target, &ret.AttackOutcome, &ret.Comments, &ret.Type,
	)
	if err != nil {
		return Report{}, err
	}
	return ret, nil
}

// CreateReport creates a new report
func (db *appdbimpl) CreateReport(report Report) (Report, error) {
	err := db.c.QueryRow(`
		INSERT INTO reports (mitre_tactic_id, exercitation_id, team_id, issued_by, issued_when, target, attack_outcome, comments, type)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
		RETURNING id
	`, report.MitreTacticId, report.ExercitationId, report.TeamId, report.IssuedBy, report.IssuedWhen, report.Target, report.AttackOutcome, report.Comments, report.Type).Scan(&report.Id)
	if err != nil {
		return Report{}, err
	}
	return report, nil
}


func (db *appdbimpl) CreateReportTechnique(id uint64, reportTechnique ReportTechnique) (ReportTechnique, error) {
	_, err := db.c.Exec(`
		INSERT INTO report_techniques (id_report, id_mitre_technique, is_subtechnique, type)
		VALUES ($1, $2, $3, $4)
	`, id, reportTechnique.IdMitreTechnique, reportTechnique.IsSubtechnique, reportTechnique.Type)
	if err != nil {
		return ReportTechnique{}, err
	}
	return reportTechnique, nil
}

/*
// detection e mitigation sono associate per forza a ReportTechnique quando blue
type ReportMitigation struct {
	IdReport 				uint64 	`json:"id_report"`
	IdReportDetection 		uint64 	`json:"id_report_detection"`
	IdMitreMitigation 		uint64 	`json:"id_mitre_mitigation"`

	MitreDetection		MitreDatasource `json:"mitre_datasource"`
	MitreMitigation		MitreMitigation `json:"mitre_mitigation"`
}


*/
func (db *appdbimpl) CreateReportDetection(id uint64, reportDetection ReportDetection) (ReportDetection, error) {
	var x uint64
	err := db.c.QueryRow(`
		INSERT INTO report_detections (id_report, id_mitre_datasource)
		VALUES ($1, $2)
		RETURNING id
	`, id, reportDetection.IdMitreDatasource).Scan(&x)
	if err != nil {
		return ReportDetection{}, err
	}
	reportDetection.Id = x
	reportDetection.IdReport = id
	return reportDetection, nil
}


func (db *appdbimpl) CreateReportMitigation(id uint64, reportMitigation ReportMitigation) (ReportMitigation, error) {
    var err error

    if reportMitigation.IdReportDetection == 0 {
        _, err = db.c.Exec(`
            INSERT INTO report_mitigations (id_report, id_mitre_mitigation, id_report_detection)
            VALUES ($1, $2, 0)
        `, id, reportMitigation.IdMitreMitigation)
    } else {
        _, err = db.c.Exec(`
            INSERT INTO report_mitigations (id_report, id_mitre_mitigation, id_report_detection)
            VALUES ($1, $2, $3)
        `, id, reportMitigation.IdMitreMitigation, reportMitigation.IdReportDetection)
    }

    if err != nil {
        return ReportMitigation{}, err
    }

    return reportMitigation, nil
}

func (db *appdbimpl) GetAssociatedDetectionsAndMitigationsIds(exercitation_id uint64, technique_id uint64) ([]uint64, []uint64, error) {
    var detections []uint64
    var mitigations []uint64

    rows, err := db.c.Query(`
        SELECT rd.id AS report_detection, rm.id AS report_mitigation
        FROM reports r
        LEFT JOIN report_techniques AS rt ON rt.id_report = r.id
        LEFT JOIN report_detections AS rd ON rd.id_report = r.id
        LEFT JOIN report_mitigations AS rm ON rm.id_report = r.id
        JOIN exercitations AS e ON e.id = r.exercitation_id AND r.type = true
        WHERE e.id = $1 AND rt.id_mitre_technique = $2
    `, exercitation_id, technique_id)
    if err != nil {
        return nil, nil, err
    }
    defer rows.Close()

    for rows.Next() {
        var detectionId sql.NullInt64
        var mitigationId sql.NullInt64
        if err := rows.Scan(&detectionId, &mitigationId); err != nil {
            return nil, nil, err
        }
            detections = append(detections, uint64(detectionId.Int64))
        
            mitigations = append(mitigations, uint64(mitigationId.Int64))
        
    }
    if err := rows.Err(); err != nil {
        return nil, nil, err
    }

    return detections, mitigations, nil
}
// getreportdetectionbyid
func (db *appdbimpl) GetReportDetectionById(id uint64) (ReportDetection, error) {
	var ret ReportDetection
	err := db.c.QueryRow(`
		SELECT id, id_report, id_mitre_datasource
		FROM report_detections
		WHERE id = $1
	`, id).Scan(
		&ret.Id, &ret.IdReport, &ret.IdMitreDatasource,
	)
	if err != nil {
		return ReportDetection{}, err
	}
	return ret, nil
}

func (db *appdbimpl) GetReportMitigationById(id uint64) (ReportMitigation, error) {
	var ret ReportMitigation
	err := db.c.QueryRow(`
		SELECT id, id_report, id_mitre_mitigation, id_report_detection
		FROM report_mitigations
		WHERE id = $1
	`, id).Scan(
		&ret.Id, &ret.IdReport, &ret.IdMitreMitigation, &ret.IdReportDetection,
	)
	if err != nil {
		return ReportMitigation{}, err
	}
	return ret, nil
}