package database

func (db *appdbimpl) GetTechniquesFromExercitationId(exercitationID uint64) ([]ReportTechnique, error) {
	var reportTechniques []ReportTechnique
	rows, err := db.c.Query(`SELECT rt.id_report, rt.id_mitre_technique, rt.is_subtechnique, rt.type
		FROM report_techniques rt
		JOIN reports r ON rt.id_report = r.id
		JOIN exercitations e ON r.exercitation_id = e.id
		WHERE e.id = $1`, exercitationID)
	if err != nil {
		return nil, err
	}
	defer func() {_ = rows.Close()}()

	for rows.Next() {
		var reportTechnique ReportTechnique
		err := rows.Scan(&reportTechnique.IdReport, &reportTechnique.IdMitreTechnique, &reportTechnique.IsSubtechnique, &reportTechnique.Type)
		if err != nil {
			return nil, err
		}

		reportTechniques = append(reportTechniques, reportTechnique)
	}
	if err = rows.Err(); err != nil {
		return nil, err
	}

	return reportTechniques, nil
}


func (db *appdbimpl) GetTechniquesFromExercitationAndReportId(exercitationID uint64, reportID uint64) ([]ReportTechnique, error) {
	var reportTechniques []ReportTechnique
	rows, err := db.c.Query(`SELECT rt.id_report, rt.id_mitre_technique, rt.is_subtechnique, rt.type
		FROM report_techniques rt
		JOIN reports r ON rt.id_report = r.id
		JOIN exercitations e ON r.exercitation_id = e.id
		WHERE e.id = $1 AND r.id = $2`, exercitationID, reportID)
	if err != nil {
		return nil, err
	}
	defer func() {_ = rows.Close()}()

	for rows.Next() {
		var reportTechnique ReportTechnique
		err := rows.Scan(&reportTechnique.IdReport, &reportTechnique.IdMitreTechnique, &reportTechnique.IsSubtechnique, &reportTechnique.Type)
		if err != nil {
			return nil, err
		}

		reportTechniques = append(reportTechniques, reportTechnique)
	}
	if err = rows.Err(); err != nil {
		return nil, err
	}

	return reportTechniques, nil
}