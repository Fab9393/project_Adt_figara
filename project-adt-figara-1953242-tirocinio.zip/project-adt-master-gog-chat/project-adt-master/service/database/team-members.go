package database

// given a team id get all members of the team
func (db *appdbimpl) ListTeamMembers(id uint64) ([]TeamMember, error) {
	var ret []TeamMember

	rows, err := db.c.Query(`SELECT * FROM team_members WHERE team_id=$1`, id)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()

	for rows.Next() {
		var tm TeamMember
		err = rows.Scan(&tm.TeamId, &tm.UserId)
		if err != nil {
			return nil, err
		}

		ret = append(ret, tm)
	}
	if err = rows.Err(); err != nil {
		return nil, err
	}

	return ret, nil
}

func (db *appdbimpl) CreateTeamMember(teamID, userID uint64) (TeamMember, error) {
	_, err := db.c.Exec(`INSERT INTO team_members (team_id, user_id) VALUES (?, ?)`, teamID, userID)
	if err != nil {
		return TeamMember{}, err
	}

	return TeamMember{TeamId: teamID, UserId: userID}, nil
}

func (db *appdbimpl) DeleteTeamMember(teamID, userID uint64) error {
	res, err := db.c.Exec(`DELETE FROM team_members WHERE team_id=$1 AND user_id=$2`, teamID, userID)
	if err != nil {
		return err
	}

	affected, err := res.RowsAffected()
	if err != nil {
		return err
	} else if affected == 0 {
		// If we didn't delete any row, then the profile didn't exist
		return ErrTeamMemberDoesNotExist
	}
	return nil
}