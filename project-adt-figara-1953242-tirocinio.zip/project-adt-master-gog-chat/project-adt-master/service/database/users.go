package database

import (
	"fmt"
)

// GetRoleFromUserId()
func (db *appdbimpl) GetRoleFromUserId(id uint64) (string, error) {
	var ret string

	// Plain simple SELECT query
	row := db.c.QueryRow(`SELECT role FROM users WHERE id=$1`, id)

	err := row.Scan(&ret)
	if err != nil {
		return "", err
	}

	return ret, nil
}

// get user from token in cookie
func (db *appdbimpl) GetUserFromToken(token string) (User, error) {
	var ret User

	// Plain simple SELECT query
	row := db.c.QueryRow(`SELECT id, first_name, last_name, nickname, email, role FROM users WHERE id=(SELECT userID FROM sessions WHERE session_id=$1)`, token)

	err := row.Scan(&ret.Id, &ret.FirstName, &ret.LastName, &ret.Nickname, &ret.Email, &ret.Role)
	if err != nil {
		return ret, err
	}

	return ret, nil
}

func (db *appdbimpl) GetUserByEmail(email string ) (User, error) {
	var ret User

	// Plain simple SELECT query
	row := db.c.QueryRow(`SELECT id, first_name, last_name, nickname, email FROM users WHERE email=$1`, email)

	err := row.Scan(&ret.Id, &ret.FirstName, &ret.LastName, &ret.Nickname, &ret.Email)
	if err != nil {
		return ret, err
	}

	return ret, nil
}

func (db *appdbimpl) GetUserIDFromSession(token string) (uint64, error) {
	var id uint64

	err := db.c.QueryRow("SELECT userID FROM sessions WHERE session_id = $1", token).Scan(&id)
	if err != nil {
		return 0, err
	}

	return id, nil
}

func (db *appdbimpl) GetUserIDFromEmail(email string) (uint64, error) {
	var id uint64
	err := db.c.QueryRow("SELECT id FROM users WHERE email = $1", email).Scan(&id)
	if err != nil {
		return 0, err
	}

	return id, nil
}

func (db *appdbimpl) CreateUser(p User) (User, error) {
    err := db.c.QueryRow(`
        INSERT INTO users (first_name, last_name, nickname, email, password)
        VALUES ($1, $2, $3, $4, $5)
        RETURNING id;
    `, p.FirstName, p.LastName, p.Nickname, p.Email, p.Password).Scan(&p.Id)

    if err != nil {
        return User{}, err
    }

    // Inserisci l'utente come membro del team blu
    _, err = db.c.Exec(`
        INSERT INTO team_members (team_id, user_id)
        VALUES (2, $1);
    `, p.Id)
    if err != nil {
        return User{}, fmt.Errorf("errore durante l'inserimento del membro del team blu: %w", err)
    }

    return p, nil
}

func (db *appdbimpl) GetUser(id uint64) (User, error) {
	var ret User

	// Plain simple SELECT query
	row := db.c.QueryRow(`SELECT id, first_name, last_name, nickname, email FROM users WHERE id=$1`, id)

	err := row.Scan(&ret.Id, &ret.FirstName, &ret.LastName, &ret.Nickname, &ret.Email)
	if err != nil {
		return User{}, ErrUserDoesNotExist
	}

	return ret, nil
}

func (db *appdbimpl) DeleteUser(id uint64) error {
	res, err := db.c.Exec(`DELETE FROM users WHERE id=$1`, id)
	if err != nil {
		return err
	}

	affected, err := res.RowsAffected()
	if err != nil {
		return err
	} else if affected == 0 {
		// If we didn't delete any row, then the user didn't exist
		return ErrUserDoesNotExist
	}
	return nil
}

func (db *appdbimpl) ListUsers() ([]User, error) {
	var ret []User

	// Plain simple SELECT query
	rows, err := db.c.Query(`SELECT id, first_name, last_name, nickname, email FROM users`)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		var p User
		err = rows.Scan(&p.Id, &p.FirstName, &p.LastName, &p.Nickname, &p.Email)
		if err != nil {
			return nil, err
		}

		ret = append(ret, p)
	}
	if err = rows.Err(); err != nil {
		return nil, err
	}

	return ret, nil
}

func (db *appdbimpl) SearchUsers(name string, page int, size int, sort string, order_by string) (int, []User, error) {
    var ret []User
    var count int
    var err error
	
	if name == "" {
		name = "a"
	}

	// Count the number of users that match the name
	row := db.c.QueryRow(`SELECT COUNT(*) AS "count" FROM users WHERE first_name LIKE '%' || $1 || '%' OR last_name LIKE '%' || $1 || '%' OR nickname LIKE '%' || $1 || '%' OR email LIKE '%' || $1 || '%'`, name)
	err = row.Scan(&count)
	if err != nil {
		fmt.Println(err)
		return 0, nil, err
	}

	fmt.Println(count)
	// 
 
	
	rows, err  := db.c.Query(`SELECT id, first_name, last_name, nickname, email FROM users WHERE first_name LIKE '%' || $1 || '%' OR last_name LIKE '%' || $1 || '%' OR nickname LIKE '%' || $1 || '%' OR email LIKE '%' || $1 || '%'`, name)
	if err != nil {
		return 0, nil, err
	}
	defer rows.Close()
    
	// Read the result set and build the list to be returned
    for rows.Next() {
        var u User
        err = rows.Scan(&u.Id, &u.FirstName, &u.LastName, &u.Nickname, &u.Email)
        if err != nil {
            return 0, nil, err
        }
        ret = append(ret, u)
    }
    if err = rows.Err(); err != nil {
        return 0, nil, err
    }

    return count, ret, nil
}

// GetTeamRoleFromUserId retrieves the team role of a user given their ID
func (db *appdbimpl) GetTeamRoleFromUserId(id uint64) (string, error) {
    var role string

    // Query to get the team role of a user
    query := `SELECT teams.role FROM teams 
        INNER JOIN team_members ON teams.id = team_members.team_id 
        WHERE team_members.user_id = $1`

    row := db.c.QueryRow(query, id)

    err := row.Scan(&role)
    if err != nil {
        return "", err
    }

    return role, nil
}




