package database

import (
	"database/sql"
	"errors"
)

func (db *appdbimpl) GetUserRoleInExcercitation(userID uint64, exercitationID uint64) (string, error) {
	var role string

	err := db.c.QueryRow(`
			SELECT 
		CASE teams.role
			WHEN 'Red' THEN 'red'
			WHEN 'Blue' THEN 'blue'
			ELSE ''
		END AS role
		FROM users
		JOIN team_members ON team_members.user_id = users.id
		JOIN teams ON teams.id = team_members.team_id
		JOIN exercitation_teams ON exercitation_teams.team_id = teams.id
		WHERE 
		users.id = $1
		AND exercitation_teams.exercitation_id = $2;`, userID, exercitationID).Scan(&role)

	if err != nil {
		return "", err
	}

	return role, nil
}


func (db *appdbimpl) GetOngoingExercitation() (Exercitation, error) {
    var ret Exercitation
    
    err := db.c.QueryRow(`
        SELECT id, name, start_date, end_date
        FROM exercitations
        WHERE start_date <= now() AND end_date >= now()
    `).Scan(
        &ret.Id, &ret.Name, &ret.Start, &ret.End,
    )
    if err != nil {
        if errors.Is(err, sql.ErrNoRows) {
            return Exercitation{}, ErrExercitationDoesNotExist
        }
        return Exercitation{}, err
    }

    teams, err := db.GetTeamsFromExercitation(ret.Id)
    if err != nil {
        return Exercitation{}, err
    }
    ret.Teams = teams
    return ret, nil
}


func (db *appdbimpl) GetExercitation(id uint64) (Exercitation, error) {
	var ret Exercitation

	row := db.c.QueryRow(`SELECT * FROM exercitations WHERE id=$1`, id)

	err := row.Scan(&ret.Id, &ret.Name, &ret.Start, &ret.End)
	if err != nil {
		return Exercitation{}, ErrExercitationDoesNotExist
	}

	// get all teams from this exercitations
	teams, err := db.GetTeamsFromExercitation(id)
	if err != nil {
		return Exercitation{}, err
	}

	ret.Teams = teams

	return ret, nil
}

func (db *appdbimpl) ListExercitations() ([]Exercitation, error) {
	var ret []Exercitation

	rows, err := db.c.Query(`SELECT * FROM exercitations ORDER BY start_date DESC`)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()

	for rows.Next() {
		var e Exercitation
		err = rows.Scan(&e.Id, &e.Name, &e.Start, &e.End)
		if err != nil {
			return nil, err
		}

		// get all teams from this exercitations
		teams, err := db.GetTeamsFromExercitation(e.Id)
		if err != nil {
			return nil, err
		}
		e.Teams = teams

		ret = append(ret, e)
	}
	if err = rows.Err(); err != nil {
		return nil, err
	}

	return ret, nil
}

func (db *appdbimpl) CreateExercitation(e Exercitation) (Exercitation, error) {
	err := db.c.QueryRow(`
        INSERT INTO exercitations (name, start_date, end_date)
        VALUES ($1, $2, $3)
        RETURNING id;
    `, e.Name, e.Start, e.End).Scan(&e.Id)

	if err != nil {
		return Exercitation{}, err
	}

	return e, nil
}


func (db *appdbimpl) DeleteExercitation(id uint64) error {
	res, err := db.c.Exec(`DELETE FROM exercitations WHERE id=$1`, id)
	if err != nil {
		return err
	}

	affected, err := res.RowsAffected()
	if err != nil {
		return err
	} else if affected == 0 {
		// If we didn't delete any row, then the profile didn't exist
		return ErrExercitationDoesNotExist
	}
	return nil
}

func (db *appdbimpl) UpdateExercitation(e Exercitation) (Exercitation, error) {
	_, err := db.c.Exec(`UPDATE exercitations SET name=$1, start_date=$2, end_date=$3, WHERE id=$4;`, e.Name, e.Start, e.End, e.Id)
	if err != nil {
		return Exercitation{}, err
	}

	return e, nil
}

func (db *appdbimpl) GetTeamsFromExercitation(id uint64) ([]Team, error) {
	var ret []Team
	rows, err := db.c.Query(`SELECT team_id FROM exercitation_teams WHERE exercitation_id=$1`, id)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()
	for rows.Next() {
		var teamID uint64
		err = rows.Scan(&teamID)
		if err != nil {
			return nil, err
		}

		team, err := db.GetTeam(teamID)
		if err != nil {
			return nil, err
		}

		ret = append(ret, team)
	}
	if err = rows.Err(); err != nil {
		return nil, err
	}
	return ret, nil
}

