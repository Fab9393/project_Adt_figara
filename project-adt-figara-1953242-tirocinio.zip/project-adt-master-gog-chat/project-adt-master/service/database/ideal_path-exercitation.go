package database

import (
    "fmt"
)

// Inserimento per l'ideal path
func (db *appdbimpl) AddIdealPath(exercitationID uint64, elements []IdealPathElement) error {
    // Inserisci i dati dell'ideal path nel database
    for _, element := range elements {
        // Inserisci l'elemento dell'ideal path nella tabella ideal_path
        _, err := db.c.Exec("INSERT INTO ideal_path (tecnica, tattica, target, detection, mitigation, exercitation_id) VALUES ($1, $2, $3, $4, $5, $6)",
    element.Tecnica, element.Tattica, element.Target, element.Detection, element.Mitigation, exercitationID)
        if err != nil {
            return fmt.Errorf("error inserting ideal path element: %w", err)
        }

        // Recupera l'ID dell'elemento appena inserito
        var idealPathID int
        err = db.c.QueryRow("SELECT id FROM ideal_path ORDER BY id DESC LIMIT 1").Scan(&idealPathID)
        if err != nil {
            return fmt.Errorf("error retrieving last inserted ideal path element ID: %w", err)
        }
    }
    return nil
}

// Recupero per l'ideal path
// GetIdealPathsByExercitationID restituisce una lista di idealPath dato l'ID di un'esercitazione.
func (db *appdbimpl) GetIdealPath(exercitationID uint64) ([]IdealPathElement, error) {
    // Esegui la query per recuperare gli idealPath associati all'esercitazione specificata
    rows, err := db.c.Query("SELECT tecnica, tattica, target, detection, mitigation FROM ideal_path WHERE exercitation_id = $1", exercitationID)
    if err != nil {
        return nil, fmt.Errorf("error querying ideal paths: %w", err)
    }
    defer rows.Close()

    // Inizializza una slice per contenere gli idealPath
    var idealPaths []IdealPathElement

    // Scansiona i risultati della query e popola la slice idealPaths
    for rows.Next() {
        var idealPath IdealPathElement
        if err := rows.Scan(&idealPath.Tecnica, &idealPath.Tattica, &idealPath.Target, &idealPath.Detection, &idealPath.Mitigation); err != nil {
            return nil, fmt.Errorf("error scanning ideal path row: %w", err)
        }
        idealPaths = append(idealPaths, idealPath)
    }

    // Controlla se ci sono errori durante la scansione dei risultati
    if err := rows.Err(); err != nil {
        return nil, fmt.Errorf("error iterating over ideal path rows: %w", err)
    }

    return idealPaths, nil
}

