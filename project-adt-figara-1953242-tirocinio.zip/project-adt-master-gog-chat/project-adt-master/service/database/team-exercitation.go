package database

func (db *appdbimpl) AssignTeamToExercitation(teamID, exercitationID uint64) error {
	_, err := db.c.Exec(`INSERT INTO exercitation_teams (exercitation_id, team_id) VALUES ($1, $2)`, exercitationID, teamID)
	return err
}

func (db *appdbimpl) RemoveTeamFromExercitation(teamID, exercitationID uint64) error {
	_, err := db.c.Exec(`DELETE FROM exercitation_teams WHERE exercitation_id=$1 AND team_id=$2`, exercitationID, teamID)
	return err
}

func (db *appdbimpl) ListTeamsOfExercitation(exercitationID uint64) ([]Team, error) {
	var ret []Team

	// Plain simple SELECT query
	rows, err := db.c.Query(`SELECT DISTINCT t.id, t.name, t.role FROM 'teams' t join exercitation_teams et ON et.team_id = t.id join exercitation e on e.id = et.exercitation_id WHERE e.id = $1`, exercitationID)

	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		var t Team
		err = rows.Scan(&t.Id, &t.Name, &t.Role)
		if err != nil {
			return nil, err
		}

		ret = append(ret, t)
	}
	if err = rows.Err(); err != nil {
		return nil, err
	}

	return ret, nil
}
