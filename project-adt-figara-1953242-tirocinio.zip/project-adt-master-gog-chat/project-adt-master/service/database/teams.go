package database

import (
	"database/sql"
	"strings"
	"fmt"
)

// GetAdminTeam()
func (db *appdbimpl) GetAdminTeam() (Team, error) {
	var t Team
	row := db.c.QueryRow(`SELECT * FROM teams WHERE role = 'White' LIMIT 1`)
	err := row.Scan(&t.Id, &t.Name, &t.Role)
	if err != nil {
		return Team{}, err
	}
	return t, nil
}

func (db *appdbimpl) SearchTeams(name string, page int, size int, sort string, order_by string) (int, []Team, error) {
	var ret []Team
	var rows *sql.Rows
	var err error

	// count the number of teams that match the name
	var count int

	// if order_by and sort are empty, then we don't need to order the results
	row := db.c.QueryRow(`SELECT COUNT(*) AS "count" FROM teams WHERE name LIKE $1`, "%"+name+"%")

	if err != nil {
		return 0, nil, err
	}
	err = row.Scan(&count)
	if err != nil {
		return 0, nil, err
	}
	var q string

	// select all teams that match the name and the page size by size
	// TODO: this is a very bad way to do this, we should use prepared statements or at least reduce the number of if statements. This is just a quick and dirty way to do it for the demo purposes
	if page == 1 {
		if strings.ToUpper(sort) == "ASC" {
			q = fmt.Sprintf(`SELECT * FROM teams WHERE name LIKE '%%%s%%' ORDER BY %s ASC LIMIT %d`, name, order_by, size)
		} else if strings.ToUpper(sort) == "DESC" {
			q = fmt.Sprintf(`SELECT * FROM teams WHERE name LIKE '%%%s%%' ORDER BY %s DESC LIMIT %d`, name, order_by, size)
		} else {
			q = fmt.Sprintf(`SELECT * FROM teams WHERE name LIKE '%%%s%%' LIMIT %d`, name, size)
		}
	} else {
		if strings.ToUpper(sort) == "ASC" {
			q = fmt.Sprintf(`SELECT * FROM teams WHERE name LIKE '%%%s%%' ORDER BY %s DESC LIMIT %d OFFSET %d`, name, order_by, size, (page-1)*size)
		} else if strings.ToUpper(sort) == "DESC" {
			q = fmt.Sprintf(`SELECT * FROM teams WHERE name LIKE '%%%s%%' ORDER BY %s ASC LIMIT %d OFFSET %d`, name, order_by, size, (page-1)*size)
		} else {
			q = fmt.Sprintf(`SELECT * FROM teams WHERE name LIKE '%%%s%%' LIMIT %d OFFSET %d`, name, size, (page-1)*size)
		}
	}
	rows, err = db.c.Query(q)
	if err != nil {
		return 0, nil, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the result set and we build the list to be returned
	for rows.Next() {
		var t Team
		err = rows.Scan(&t.Id, &t.Name, &t.Role)
		if err != nil {
			return 0, nil, err
		}

		ret = append(ret, t)
	}
	if err = rows.Err(); err != nil {
		return 0, nil, err
	}

	return count, ret, nil
}

func (db *appdbimpl) GetTeam(id uint64) (Team, error) {
	var ret Team

	// Plain simple SELECT query
	row := db.c.QueryRow(`SELECT * FROM teams WHERE id=$1`, id)

	err := row.Scan(&ret.Id, &ret.Name, &ret.Role)
	if err != nil {
		return Team{}, ErrTeamDoesNotExist
	}

	return ret, nil
}

func (db *appdbimpl) ListTeams() ([]Team, error) {
	var ret []Team

	// Plain simple SELECT query
	rows, err := db.c.Query(`SELECT * FROM teams`)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		var t Team
		err = rows.Scan(&t.Id, &t.Name, &t.Role)
		if err != nil {
			return nil, err
		}

		ret = append(ret, t)
	}
	if err = rows.Err(); err != nil {
		return nil, err
	}

	return ret, nil
}

func (db *appdbimpl) DeleteTeam(id uint64) error {
	res, err := db.c.Exec(`DELETE FROM teams WHERE id=$1`, id)
	if err != nil {
		return err
	}

	affected, err := res.RowsAffected()
	if err != nil {
		return err
	} else if affected == 0 {
		// If we didn't delete any row, then the profile didn't exist
		return ErrTeamDoesNotExist
	}
	return nil
}

func (db *appdbimpl) CreateTeam(t Team) (Team, error) {
	err := db.c.QueryRow(`
        INSERT INTO teams (name, role)
        VALUES ($1, $2)
        RETURNING id;
    `, t.Name, t.Role).Scan(&t.Id)

	if err != nil {
		return Team{}, err
	}

	return t, nil
}

func (db *appdbimpl) GetTeamFromUserIdAndExercitationId(userId uint64, exercitationId uint64) (Team, error) {
	var ret Team

	// Plain simple SELECT query
	row := db.c.QueryRow(`SELECT t.id, t.name, t.role
	FROM teams t
	JOIN team_members tm ON t.id = tm.team_id
	JOIN exercitation_teams et ON t.id = et.team_id
	WHERE tm.user_id = $1 AND et.exercitation_id = $2;
	`, userId, exercitationId)

	err := row.Scan(&ret.Id, &ret.Name, &ret.Role)
	if err != nil {
		return Team{}, ErrTeamDoesNotExist
	}

	return ret, nil
}