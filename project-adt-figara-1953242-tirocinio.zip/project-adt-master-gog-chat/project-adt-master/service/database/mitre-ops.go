package database

func (db *appdbimpl) GetMitreTechniqueByName(techniqueName string) (MitreTechnique, error) {
	var ret MitreTechnique

	// Plain simple SELECT query
	rows, err := db.c.Query(`SELECT * FROM techniques WHERE technique_id = $1`, techniqueName)
	if err != nil {
		return ret, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		err = rows.Scan(&ret.Id, &ret.TechniqueId, &ret.Type, &ret.Name, &ret.Description, &ret.Created, &ret.Modified)
		if err != nil {
			return ret, err
		}
	}
	if err = rows.Err(); err != nil {
		return ret, err
	}

	return ret, nil
}
func (db *appdbimpl) ListMitreTechniques() ([]MitreTechnique, error) {
	var ret []MitreTechnique

	// Plain simple SELECT query
	rows, err := db.c.Query(`SELECT * FROM techniques t WHERE t.technique_id NOT LIKE '%.%' AND t.type NOT LIKE 'CAPEC' ORDER BY t.technique_id`)

	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		var t MitreTechnique
		err = rows.Scan(&t.Id, &t.TechniqueId, &t.Type, &t.Name, &t.Description, &t.Created, &t.Modified)
		if err != nil {
			return nil, err
		}

		ret = append(ret, t)
	}
	if err = rows.Err(); err != nil {
		return nil, err
	}

	return ret, nil
}

func (db *appdbimpl) ListMitreDatasources() ([]MitreDatasource, error) {
	var ret []MitreDatasource

	// Plain simple SELECT query
	/*
		JOIN data_sources dss ON dss.datasource_id = ds.id
		JOIN techniques AS t ON t.id = ds.mitre_attack_id
		WHERE t.id = ds.mitre_attack_id AND technique_id NOT LIKE '%.%' AND type NOT LIKE 'CAPEC'
	*/
	rows, err := db.c.Query(`
		SELECT DISTINCT ON (ds.name) ds.id, ds.name, ds.description 
		FROM datasource_base ds
		ORDER BY ds.name;
	`)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		var t MitreDatasource
		err = rows.Scan(&t.Id, &t.Name, &t.Description)
		if err != nil {
			return nil, err
		}

		ret = append(ret, t)
	}
	if err = rows.Err(); err != nil {
		return nil, err
	}

	return ret, nil
}

// func listallmitigations
func (db *appdbimpl) ListMitreMitigations() ([]MitreMitigation, error) {
	var ret []MitreMitigation

	// Plain simple SELECT query
	rows, err := db.c.Query(`select distinct on (m.name) m.id, m.technique_id, m.name, m.description from mitigations m where m.name LIKE 'M1%' group by m.id order by m.name`)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		var t MitreMitigation
		err = rows.Scan(&t.Id, &t.TechniqueId, &t.Name, &t.Description)
		if err != nil {
			return nil, err
		}

		ret = append(ret, t)
	}
	if err = rows.Err(); err != nil {
		return nil, err
	}

	return ret, nil
}

// get specific Technique
func (db *appdbimpl) GetMitreTechnique(id uint64) (MitreTechnique, error) {
	var ret MitreTechnique

	// Plain simple SELECT query
	rows, err := db.c.Query(`SELECT * FROM techniques WHERE id = $1`, id)
	if err != nil {
		return ret, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		err = rows.Scan(&ret.Id, &ret.TechniqueId, &ret.Type, &ret.Name, &ret.Description, &ret.Created, &ret.Modified)
		if err != nil {
			return ret, err
		}
	}
	if err = rows.Err(); err != nil {
		return ret, err
	}

	return ret, nil
}

// get specific Datasource
func (db *appdbimpl) GetMitreDatasource(id uint64) (MitreDatasource, error) {
	var ret MitreDatasource

	// Plain simple SELECT query
	rows, err := db.c.Query(`SELECT * FROM datasource_base WHERE id = $1`, id)
	if err != nil {
		return ret, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		err = rows.Scan(&ret.Id, &ret.Name, &ret.Description)
		if err != nil {
			return ret, err
		}
	}
	if err = rows.Err(); err != nil {
		return ret, err
	}

	return ret, nil
}

// get specific mitigation details
func (db *appdbimpl) GetMitreMitigation(id uint64) (MitreMitigation, error) {
	var ret MitreMitigation

	// Plain simple SELECT query
	rows, err := db.c.Query(`SELECT * FROM mitigations WHERE id = $1`, id)
	if err != nil {
		return ret, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		err = rows.Scan(&ret.Id, &ret.TechniqueId, &ret.Name, &ret.Description)
		if err != nil {
			return ret, err
		}
	}
	if err = rows.Err(); err != nil {
		return ret, err
	}

	return ret, nil
}

func (db *appdbimpl) ListMitreTactics() ([]MitreTactic, error) {
	var ret []MitreTactic

	// Plain simple SELECT query
	rows, err := db.c.Query(`SELECT DISTINCT ON (tactic) id, tactic FROM kill_chain_phases ORDER BY tactic, id`)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		var t MitreTactic
		err = rows.Scan(&t.Id, &t.Tactic)
		if err != nil {
			return nil, err
		}

		ret = append(ret, t)
	}
	if err = rows.Err(); err != nil {
		return nil, err
	}

	return ret, nil
}

// get specific mitigation details
func (db *appdbimpl) GetMitreTactic(id uint64) (MitreTactic, error) {
	var ret MitreTactic

	// Plain simple SELECT query
	rows, err := db.c.Query(`SELECT id, tactic FROM kill_chain_phases WHERE id = $1`, id)
	if err != nil {
		return ret, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		err = rows.Scan(&ret.Id, &ret.Tactic)
		if err != nil {
			return ret, err
		}
	}
	if err = rows.Err(); err != nil {
		return ret, err
	}

	return ret, nil
}

// ListMitreSubtechniques(frontendTechniques[idx].Id)
func (db *appdbimpl) ListMitreSubtechniques(techniqueId uint64) ([]MitreTechnique, error) {
	var ret []MitreTechnique

	// Plain simple SELECT query
	rows, err := db.c.Query(`SELECT t2.*
	FROM sub_techniques st
	INNER JOIN techniques t ON st.mitre_attack_id = t.id
	JOIN techniques t2 ON t2.name = st.name
	WHERE t.id = $1
	ORDER BY t2.technique_id;`, techniqueId)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		var t MitreTechnique
		err = rows.Scan(&t.Id, &t.TechniqueId, &t.Type, &t.Name, &t.Description, &t.Created, &t.Modified)
		if err != nil {
			return nil, err
		}

		ret = append(ret, t)
	}
	if err = rows.Err(); err != nil {
		return nil, err
	}

	return ret, nil
}

// ListeAllMitreTechniques()
func (db *appdbimpl) ListAllMitreTechniques() ([]MitreTechnique, error) {
	var ret []MitreTechnique

	// Plain simple SELECT query
	rows, err := db.c.Query(`SELECT * FROM techniques t WHERE t.type NOT LIKE 'CAPEC' ORDER BY t.technique_id`)
	if err != nil {
		return nil, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		var t MitreTechnique
		err = rows.Scan(&t.Id, &t.TechniqueId, &t.Type, &t.Name, &t.Description, &t.Created, &t.Modified)
		if err != nil {
			return nil, err
		}

		ret = append(ret, t)
	}
	if err = rows.Err(); err != nil {
		return nil, err
	}

	return ret, nil
}

// GetOptimalDetection(tecniqueId uint64) (string, error)
func (db *appdbimpl) GetOptimalDetection(techniqueId uint64) ([]MitreDatasource, error) {

	var ret []MitreDatasource

	// Plain simple SELECT query
	rows, err := db.c.Query(`SELECT db.id, db.name, db.description from data_sources ds JOIN datasource_base AS db ON db.id = ds.datasource_id where ds.mitre_attack_id = $1 ORDER BY db.name`, techniqueId)

	if err != nil {
		return ret, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		var t MitreDatasource
		err = rows.Scan(&t.Id, &t.Name, &t.Description)
		if err != nil {
			return ret, err
		}

		ret = append(ret, t)
	}
	if err = rows.Err(); err != nil {
		return ret, err
	}

	return ret, nil
}

func (db *appdbimpl) GetOptimalMitigation(techniqueId uint64) ([]MitreMitigation, error) {

	var ret []MitreMitigation

	// Plain simple SELECT query
	rows, err := db.c.Query(`SELECT db.id, db.technique_id, db.name from mitigations db where db.technique_id = $1 ORDER BY db.name`, techniqueId)
	if err != nil {
		return ret, err
	}
	defer func() { _ = rows.Close() }()

	// Here we read the resultset and we build the list to be returned
	for rows.Next() {
		var t MitreMitigation
		err = rows.Scan(&t.Id, &t.TechniqueId, &t.Name)
		if err != nil {
			return ret, err
		}

		ret = append(ret, t)
	}
	if err = rows.Err(); err != nil {
		return ret, err
	}

	return ret, nil
}
