/*
Package database is the middleware between the app database and the code. All data (de)serialization (save/load) from a
persistent database are handled here. Database specific logic should never escape this package.

To use this package you need to apply migrations to the database if needed/wanted, connect to it (using the database
data source name from config), and then initialize an instance of AppDatabase from the DB connection.

For example, this code adds a parameter in `webapi` executable for the database data source name (add it to the
main.WebAPIConfiguration structure):

	DB struct {
		Filename string `conf:""`
	}

This is an example on how to migrate the DB and connect to it:

	// Start Database
	logger.Println("initializing database support")
	db, err := sql.Open("sqlite3", "./foo.db")
	if err != nil {
		logger.WithError(err).Error("error opening SQLite DB")
		return fmt.Errorf("opening SQLite: %w", err)
	}
	defer func() {
		logger.Debug("database stopping")
		_ = db.Close()
	}()

Then you can initialize the AppDatabase and pass it to the api package.
*/

package database

import (
	"database/sql"
	"errors"
	"fmt"
	"golang.org/x/crypto/bcrypt"
	"time"
)

var ErrUserDoesNotExist = errors.New("users does not exist")
var ErrTeamDoesNotExist = errors.New("team does not exist")
var ErrTeamMemberDoesNotExist = errors.New("member not in the team")
var ErrExercitationDoesNotExist = errors.New("exercitation does not exist")
var ErrTeamNotInExercitation = errors.New("team not in exercitation")

// User struct represent a users in every API call between this package and the outside world.
// Note that the internal representation of users in the database might be different.
type User struct {
	Id        uint64
	FirstName string
	LastName  string
	Nickname  string
	Email     string
	Password  string
	Role     string
}

type Exercitation struct {
	Id          uint64
	Name        string
	Start 	 string // timestamp
	End 	 string // timestamp
	Teams	[]Team
}

type IdealPathElement struct {
    Tecnica       string 
    Tattica       string 
    Target        string 
    Detection     string 
    Mitigation    string 
    ExercitationID uint64 
}

type Report struct {
	Id                 uint64 // internal Id
	TeamId 		   uint64	// team that issued the report
	MitreTacticId      uint64 // presumed tactic if blue report
	ExercitationId     uint64
	IssuedBy           uint64
	IssuedWhen         string // timestamp
	Target				string
	AttackOutcome		uint64	// 0 = ongoing, 1 = success, 2 = fail, vuoto in caso di blue report
	Comments           string
	Type 				bool // false = red, true = blue
}

// tecniche associate a red report
type ReportTechnique struct {
	IdReport         uint64
	IdMitreTechnique    uint64
	IsSubtechnique		bool
	Type				bool // false = red, true = blue
}

// detection e mitigation sono associate per forza a ReportTechnique quando blue
type ReportDetection struct {
	Id 		   uint64
	IdReport uint64
	IdMitreDatasource    uint64
}

type ReportMitigation struct {
	Id 		   uint64
	IdReport uint64
	IdReportDetection uint64
	IdMitreMitigation 		uint64
}


type Team struct {
	Id             uint64
	Name           string
	Role           string
	ExercitationId uint64
}

type TeamMember struct {
	TeamId uint64
	UserId uint64
}

///////////
// Mitre //
///////////
type MitreTactic struct {
	Id          uint64
	Tactic        string
}

type MitreTechnique struct {
	Id          uint64
	TechniqueId string
	Type		string
	Name        string
	Description string
	Created    	string
	Modified   	string
}

type MitreDatasource struct {
	Id          uint64
	//MitreTechniqueId uint64
	Name        string
	Description string
}

type MitreMitigation struct {
	Id          uint64
	TechniqueId string
	Name        string
	Description string
}



// AppDatabase
// ***************
// AppDatabase is the high level interface for the DB
type AppDatabase interface {
	// Routes about login
	CheckUserCredentials(email string, password string) (bool, error)
	SaveSession(sessionID string, userID uint64, expirationTime time.Time) error
	GetUserIDFromSession(token string) (uint64, error) 
	GetUserByEmail(email string) (User, error)
	GetOngoingExercitation() (Exercitation, error)
	GetUserRoleInExcercitation(userID uint64, exercitationID uint64) (string, error)
	GetUserFromToken(token string) (User, error)

	// Routes about users
	ListUsers() ([]User, error)
	GetUser(id uint64) (User, error)
	CreateUser(User) (User, error)
	DeleteUser(id uint64) error
	GetUserIDFromEmail(email string) (uint64, error)

	// Routes about team
	ListTeams() ([]Team, error)
	GetTeam(id uint64) (Team, error)
	CreateTeam(Team) (Team, error)
	DeleteTeam(id uint64) error
	GetTeamFromUserIdAndExercitationId(userId uint64, exercitationId uint64) (Team, error)
	GetAdminTeam() (Team, error)
	GetRoleFromUserId(id uint64) (string, error)
	
	// Routes about team members
	ListTeamMembers(id uint64) ([]TeamMember, error)
	CreateTeamMember(teamID uint64, userID uint64) (TeamMember, error)
	DeleteTeamMember(teamID uint64, userID uint64) error
	GetTeamRoleFromUserId(id uint64) (string, error)


	// routes about exercitations
	ListExercitations() ([]Exercitation, error)
	GetExercitation(id uint64) (Exercitation, error)
	CreateExercitation(e Exercitation) (Exercitation, error)
	DeleteExercitation(id uint64) error
	UpdateExercitation(e Exercitation) (Exercitation, error)

	ListTeamsOfExercitation(exercitationID uint64) ([]Team, error)
	GetTeamsFromExercitation(id uint64) ([]Team, error)
	AssignTeamToExercitation(teamID uint64, exercitationID uint64) error
	RemoveTeamFromExercitation(teamID uint64, exercitationID uint64) error
	AddIdealPath(exercitationID uint64, elements []IdealPathElement) error
    GetIdealPath(exercitationID uint64) ([]IdealPathElement, error)


	// routes about reports
	ListReports(exercitationId uint64) ([]Report, error)	
	ListRedTeamReports(exercitationId uint64) ([]Report, error)
	ListBlueTeamReports(exercitationId uint64) ([]Report, error)
	GetReport(reportId uint64) (Report, error)
	GetTechniquesFromExercitationId(exercitationID uint64) ([]ReportTechnique, error)
	GetTechniquesFromExercitationAndReportId(exercitationID uint64, reportID uint64) ([]ReportTechnique, error)
	CreateReport(report Report) (Report, error)
	GetAssociatedDetectionsAndMitigationsIds(exercitation_id uint64, technique_id uint64) ([]uint64, []uint64, error)
	GetReportMitigationById(id uint64) (ReportMitigation, error)
	GetReportDetectionById(id uint64) (ReportDetection, error)
	CreateReportTechnique(id uint64, reportTechnique ReportTechnique) (ReportTechnique, error)
	CreateReportDetection(id uint64, reportDetection ReportDetection) (ReportDetection, error)
	CreateReportMitigation(id uint64, reportMitigation ReportMitigation) (ReportMitigation, error)

	// Ping checks whether the database is available or not (in that case, an error will be returned)
	Ping() error

	// search team by name
	SearchTeams(name string, page int, size int, sort string, order_by string) (int, []Team, error)
	SearchUsers(name string, page int, size int, sort string, order_by string) (int, []User, error)

	// MITRE PART
	ListMitreTechniques() ([]MitreTechnique, error)
	ListAllMitreTechniques() ([]MitreTechnique, error)
	ListMitreTactics() ([]MitreTactic, error)
	ListMitreDatasources() ([]MitreDatasource, error)
	ListMitreMitigations() ([]MitreMitigation, error)
	ListMitreSubtechniques(techniqueId uint64) ([]MitreTechnique, error)
	
	GetMitreTechnique(id uint64) (MitreTechnique, error)
	GetMitreTactic(id uint64) (MitreTactic, error)
	GetMitreDatasource(id uint64) (MitreDatasource, error)
	GetMitreMitigation(id uint64) (MitreMitigation, error)
	GetMitreTechniqueByName(techniqueName string) (MitreTechnique, error)
	GetOptimalDetection(techniqueId uint64) ([]MitreDatasource, error)
	GetOptimalMitigation(techniqueId uint64) ([]MitreMitigation, error)
}

type appdbimpl struct {
	c *sql.DB
}

// New returns a new instance of AppDatabase based on the SQLite connection `db`.
// `db` is required - an error will be returned if `db` is `nil`.
func New(db *sql.DB) (AppDatabase, error) {
	if db == nil {
		return nil, errors.New("database is required when building a AppDatabase")
	}

	// users
	// *******
	sqlStmt := `CREATE TABLE IF NOT EXISTS users (
		id SERIAL PRIMARY KEY,
		first_name TEXT NOT NULL CHECK(first_name != ''),
		last_name TEXT NOT NULL CHECK(last_name != ''),
		nickname TEXT,
		email TEXT UNIQUE NOT NULL CHECK(email != ''),
		password TEXT NOT NULL CHECK(password != ''),
		role TEXT NOT NULL CHECK(role != '') DEFAULT 'user'
	);`
	_, err := db.Exec(sqlStmt)
	if err != nil {
		return nil, fmt.Errorf("error creating database structure: %w", err)
	}

	// sessions
	// ********
	_, err = db.Exec("CREATE TABLE IF NOT EXISTS sessions (session_id VARCHAR PRIMARY KEY, userID INTEGER REFERENCES users(id), expiration TIMESTAMP)")
    if err != nil {
        // Errore durante l'esecuzione della query SQL
		return nil, fmt.Errorf("error creating database structure: %w", err)
	}


		// exercitation
		// ************
		sqlStmt = `
			CREATE TABLE IF NOT EXISTS exercitations (
				id SERIAL PRIMARY KEY,
				name VARCHAR(100) NOT NULL CHECK(name != ''),
				start_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
				end_date TIMESTAMP CHECK(end_date > start_date)
			);`
		_, err = db.Exec(sqlStmt)
		if err != nil {
			return nil, fmt.Errorf("error creating database structure exe: %w", err)
		}
		// tabella dell'ideal path
	sqlStmt =`
	CREATE TABLE IF NOT EXISTS ideal_path (
		id SERIAL PRIMARY KEY,
		tecnica TEXT NOT NULL,
		tattica TEXT NOT NULL,
		target TEXT NOT NULL,
		detection TEXT NOT NULL,
		mitigation TEXT NOT NULL,
		exercitation_id INTEGER NOT NULL,
		FOREIGN KEY (exercitation_id) REFERENCES exercitations(id)
	);`
	_, err = db.Exec(sqlStmt)
	if err != nil {
		return nil, fmt.Errorf("error creating ideal_path table: %w", err)
	}


	// team
	// ****
	sqlStmt = `CREATE TABLE IF NOT EXISTS teams (
		id SERIAL NOT NULL PRIMARY KEY,	
		name TEXT NOT NULL CHECK(name != '' AND name != 'Red' AND name != 'Blue' AND name != 'White'),
		role TEXT NOT NULL CHECK(role != '' AND (role = 'Red' OR role = 'Blue' OR role = 'White'))
	);`
	_, err = db.Exec(sqlStmt)
	if err != nil {
		return nil, fmt.Errorf("error creating database structure: team %w", err)
	}

	// Report
	// ******
	sqlStmt = `CREATE TABLE IF NOT EXISTS reports (
		id SERIAL PRIMARY KEY,
		mitre_tactic_id INTEGER REFERENCES kill_chain_phases(id),
		exercitation_id INTEGER REFERENCES exercitations(id),
		team_id INTEGER REFERENCES teams(id),
		issued_by INTEGER REFERENCES users(id),
		issued_when VARCHAR(50) DEFAULT CURRENT_TIMESTAMP,
		target VARCHAR(100),
		attack_outcome INTEGER NOT NULL DEFAULT 0 CHECK(attack_outcome IN (0, 1, 2, 3)),
		comments TEXT,
		type BOOLEAN 
	);`
	_, err = db.Exec(sqlStmt)
	if err != nil {
		return nil, fmt.Errorf("error creating database structure report: %w", err)
	}


	// ReportTechnique
	// ***************
	sqlStmt = `
		CREATE TABLE IF NOT EXISTS report_techniques (
		id SERIAL PRIMARY KEY,
		id_report INTEGER REFERENCES reports(id),
		id_mitre_technique INTEGER REFERENCES techniques(id),
		is_subtechnique BOOLEAN,
		type BOOLEAN
		);`
	_, err = db.Exec(sqlStmt)
	if err != nil {
		return nil, fmt.Errorf("error creating database structure report_technique: %w", err)
	}

	// ReportDetection
	// ***************
	sqlStmt = `
		CREATE TABLE IF NOT EXISTS report_detections (
		id SERIAL PRIMARY KEY,
		id_report INTEGER REFERENCES reports(id),
		id_mitre_datasource INTEGER REFERENCES data_sources(id)
		);`
	_, err = db.Exec(sqlStmt)
	if err != nil {
		return nil, fmt.Errorf("error creating database structure report_detection: %w", err)
	}

	// ReportMitigation
	// ***************
	sqlStmt = `
	CREATE TABLE IF NOT EXISTS report_mitigations (
		id SERIAL PRIMARY KEY,
		id_report INTEGER REFERENCES reports(id),
		id_report_detection INTEGER,
		id_mitre_mitigation INTEGER REFERENCES mitigations(id)
		);
			`
	_, err = db.Exec(sqlStmt)
	if err != nil {
		return nil, fmt.Errorf("error creating database structure report_mitigation: %w", err)
	}

	// chatMessages
	// ***************
	sqlStmt = `
	CREATE TABLE chat_messages (
    id SERIAL PRIMARY KEY,          -- ID univoco per il messaggio
    exercise_id INT NOT NULL,       -- ID dell'esercitazione a cui il messaggio appartiene
    sender_id INT NOT NULL,         -- ID dell'utente che ha inviato il messaggio
    receiver_id INT NOT NULL,       -- ID dell'utente che ha ricevuto il messaggio
    message TEXT NOT NULL,          -- Contenuto del messaggio
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Data e ora del messaggio
    FOREIGN KEY (exercise_id) REFERENCES exercises(id), -- Assumendo che tu abbia una tabella 'exercises'
    FOREIGN KEY (sender_id) REFERENCES users(id),       -- Assumendo che tu abbia una tabella 'users'
    FOREIGN KEY (receiver_id) REFERENCES users(id)      -- Assumendo che tu abbia una tabella 'users'
	);
			`
	_, err = db.Exec(sqlStmt)
	if err != nil {
		return nil, fmt.Errorf("error creating database structure chat_messages: %w", err)
	}


	// UTILITY TABLE
	// *************
	// teams <-> member
	sqlStmt = `CREATE TABLE IF NOT EXISTS team_members (
		team_id INTEGER NOT NULL REFERENCES teams(id) CHECK(team_id > 0),
		user_id INTEGER NOT NULL REFERENCES users(id) CHECK(user_id > 0),
		UNIQUE(team_id, user_id)
	);`
	_, err = db.Exec(sqlStmt)
	if err != nil {
		return nil, fmt.Errorf("error creating database structure te members: %w", err)
	}

	
	// Exercitation <--> teams
	sqlStmt = `CREATE TABLE IF NOT EXISTS exercitation_teams (
		exercitation_id INTEGER NOT NULL REFERENCES exercitations(id) CHECK(exercitation_id > 0),
		team_id INTEGER NOT NULL REFERENCES teams(id) CHECK(team_id > 0),
		UNIQUE(exercitation_id, team_id)
	);`
	_, err = db.Exec(sqlStmt)
	if err != nil {
		return nil, fmt.Errorf("error creating database structure ex te: %w", err)
	}


	/********* INSERT DEFAULT DATA *********/
	// users
	// ****
	// insert default users
	// insert default users
	// check if users 1 exists 
	var user1 int
	err = db.QueryRow(`SELECT id FROM users WHERE id = 1;`).Scan(&user1)
	if errors.Is(err, sql.ErrNoRows) {
		// genera password hash della parola 'password'
		hash, err := bcrypt.GenerateFromPassword([]byte("password"), 10)
		if err != nil {
			return nil, fmt.Errorf("error generating password hash: %w", err)
		}
		
		_, err = db.Exec(`INSERT INTO users (first_name, last_name, nickname, email, password, role) VALUES ('Damiano', 'Gualandri', 'dgualandri', 'damiano@gualandri.it', '` + string(hash) +`', 'red');`)
		if err != nil {
			return nil, fmt.Errorf("error creating damiano user: %w", err)
		}
	}


	// check if users 2 exists
	var user2 int
	err = db.QueryRow(`SELECT id FROM users WHERE id = 2;`).Scan(&user2)
	if errors.Is(err, sql.ErrNoRows) {
		hash, err := bcrypt.GenerateFromPassword([]byte("password"), 10)
		if err != nil {
			return nil, fmt.Errorf("error generating password hash: %w", err)
		}
		// hash to string
		
		_, err = db.Exec(`INSERT INTO users (first_name, last_name, nickname, email, password, role) VALUES ('Michael', 'Jackson', 'mj', 'michael@jackson.com', '`+ string(hash) +`', 'blue');`)
		if err != nil {
			return nil, fmt.Errorf("error creating michael jackson user: %w", err)
		}
	}

	// check if users 3 exists
	var user3 int
	err = db.QueryRow(`SELECT id FROM users WHERE id = 3;`).Scan(&user3)
	if errors.Is(err, sql.ErrNoRows) {
		hash, err := bcrypt.GenerateFromPassword([]byte("password"), 10)
		if err != nil {
			return nil, fmt.Errorf("error generating password hash: %w", err)
		}
		// hash to string
		
		_, err = db.Exec(`INSERT INTO users (first_name, last_name, nickname, email, password, role) VALUES ('Angelo', 'Spognardi', 'aspognardi', 'angelo@spognardi.it', '`+ string(hash) +`', 'admin');`)
		if err != nil {
			return nil, fmt.Errorf("error creating angelo spognardi user: %w", err)
		}
	}



	// insert default exercitations
	var exercitation int
	err = db.QueryRow(`SELECT id FROM exercitations WHERE id = 1;`).Scan(&exercitation)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO exercitations (name, start_date, end_date) VALUES ('Exercitation 1', '2021-01-01 00:00:00', '2021-01-01 01:00:00');`)
		if err != nil {
			return nil, fmt.Errorf("error creating exercitation 1: %w", err)
		}
	}
	
	// insert default teams
	// check if team 1 exists
	var team1 int
	err = db.QueryRow(`SELECT id FROM teams WHERE id = 1;`).Scan(&team1)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO teams (name, role) VALUES ('Rossi', 'Red');`)
		if err != nil {
			return nil, fmt.Errorf("error creating red team: %w", err)
		}
	}

	// check if team 2 exists
	var team2 int
	err = db.QueryRow(`SELECT id FROM teams WHERE id = 2;`).Scan(&team2)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO teams (name, role) VALUES ('Blues', 'Blue');`)
		if err != nil {
			return nil, fmt.Errorf("error creating blue team: %w", err)
		}
	}

	var team3 int
	err = db.QueryRow(`SELECT id FROM teams WHERE id = 3;`).Scan(&team3)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO teams (name, role) VALUES ('White Team', 'White');`)
		if err != nil {
			return nil, fmt.Errorf("error creating green team: %w", err)
		}
	}


	// insert default team members
	var teamMember int
	err = db.QueryRow(`SELECT * FROM team_members WHERE team_id = 1 AND user_id = 1;`).Scan(&teamMember)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO team_members (team_id, user_id) VALUES (1, 1);`)
		if err != nil {
			return nil, fmt.Errorf("error creating red team member: %w", err)
		}
	}

	err = db.QueryRow(`SELECT * FROM team_members WHERE team_id = 2 AND user_id = 2;`).Scan(&teamMember)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO team_members (team_id, user_id) VALUES (2, 2);`)
		if err != nil {
			return nil, fmt.Errorf("error creating blue team member: %w", err)
		}
	}

	err = db.QueryRow(`SELECT * FROM team_members WHERE team_id = 3 AND user_id = 3;`).Scan(&teamMember)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO team_members (team_id, user_id) VALUES (3, 3);`)
		if err != nil {
			return nil, fmt.Errorf("error creating white team member: %w", err)
		}
	}

	// insert default exercitations <-> teams
	var exTeam int
	err = db.QueryRow(`SELECT * FROM exercitation_teams WHERE exercitation_id = 1 AND team_id = 1;`).Scan(&exTeam)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO exercitation_teams (exercitation_id, team_id) VALUES (1, 1);`)
		if err != nil {
			return nil, fmt.Errorf("error creating red team member: %w", err)
		}
	}

	err = db.QueryRow(`SELECT * FROM exercitation_teams WHERE exercitation_id = 1 AND team_id = 2;`).Scan(&exTeam)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO exercitation_teams (exercitation_id, team_id) VALUES (1, 2);`)
		if err != nil {
			return nil, fmt.Errorf("error creating blue team member: %w", err)
		}
	}

	// insert default data //
	// esercitazioni
	err = db.QueryRow(`SELECT id FROM exercitations WHERE id = 1;`).Scan(&exercitation)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO exercitations (name, start_date, end_date) VALUES ('exercitation1', '2022-01-01 00:00:00', '2022-01-02 00:00:00') ON CONFLICT DO NOTHING;`)
		if err != nil {
			return nil, fmt.Errorf("error creating exercitation 1: %w", err)
		}
	}

	err = db.QueryRow(`SELECT id FROM exercitations WHERE id = 2;`).Scan(&exercitation)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO exercitations (name, start_date, end_date) VALUES ('exercitation2', '2022-02-01 00:00:00', '2022-02-02 00:00:00')  ON CONFLICT DO NOTHING;`)
		if err != nil {
			return nil, fmt.Errorf("error creating exercitation 2: %w", err)
		}
	}

	err = db.QueryRow(`SELECT id FROM exercitations WHERE id = 3;`).Scan(&exercitation)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO exercitations (name, start_date, end_date) VALUES ('exercitation3', '2022-03-01 00:00:00', '2022-03-02 00:00:00') ON CONFLICT DO NOTHING;`)
		if err != nil {
			return nil, fmt.Errorf("error creating exercitation 3: %w", err)
		}
	}

	/* Query di inserimento per reports: */
	var report int
	err = db.QueryRow(`SELECT id FROM reports WHERE id = 1;`).Scan(&report)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO reports (mitre_tactic_id, exercitation_id, team_id, issued_by, issued_when, target, attack_outcome, comments, type) VALUES (1, 1, 1, 1, '2022-01-01 10:00:00', 'www.example.com', 1, 'test comment', false) ON CONFLICT DO NOTHING;`)
		if err != nil {
			return nil, fmt.Errorf("error creating report 1: %w", err)
		}
	}

	err = db.QueryRow(`SELECT id FROM reports WHERE id = 2;`).Scan(&report)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO reports (mitre_tactic_id, exercitation_id, team_id, issued_by, issued_when, target, attack_outcome, comments, type) VALUES (2, 1, 2, 2, '2022-02-01 10:00:00', 'www.example2.com', 0, 'another comment', true) ON CONFLICT DO NOTHING;`)
		if err != nil {
			return nil, fmt.Errorf("error creating report 2: %w", err)
		}
	}

	err = db.QueryRow(`SELECT id FROM reports WHERE id = 3;`).Scan(&report)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO reports (mitre_tactic_id, exercitation_id, team_id, issued_by, issued_when, target, attack_outcome, comments, type) VALUES (3, 2, 1, 3, '2022-03-01 10:00:00', 'www.example3.com', 2, 'more comments', false) ON CONFLICT DO NOTHING;`)
		if err != nil {
			return nil, fmt.Errorf("error creating report 3: %w", err)
		}
	}

	var reportTechnique int
	/* Query di inserimento per report_techniques: */
	err = db.QueryRow(`SELECT id FROM report_techniques WHERE id = 1;`).Scan(&reportTechnique)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO report_techniques (id_report, id_mitre_technique, is_subtechnique, type) VALUES (1, 1, false, true) ON CONFLICT DO NOTHING;`)
		if err != nil {
			return nil, fmt.Errorf("error creating report_technique 1: %w", err)
		}
	}

	err = db.QueryRow(`SELECT id FROM report_techniques WHERE id = 2;`).Scan(&reportTechnique)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO report_techniques (id_report, id_mitre_technique, is_subtechnique, type) VALUES (2, 2, false, false) ON CONFLICT DO NOTHING;`)
		if err != nil {
			return nil, fmt.Errorf("error creating report_technique 2: %w", err)
		}
	}

	err = db.QueryRow(`SELECT id FROM report_techniques WHERE id = 3;`).Scan(&reportTechnique)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO report_techniques (id_report, id_mitre_technique, is_subtechnique, type) VALUES (3, 3, true, true) ON CONFLICT DO NOTHING;`)
		if err != nil {
			return nil, fmt.Errorf("error creating report_technique 3: %w", err)
		}
	}

	err = db.QueryRow(`SELECT id FROM report_detections WHERE id = 1;`).Scan(&reportTechnique)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO report_detections (id_report, id_mitre_datasource) VALUES (1, 1) ON CONFLICT DO NOTHING;`)
		if err != nil {
			return nil, fmt.Errorf("error creating report_detection 1: %w", err)
		}
	}

	err = db.QueryRow(`SELECT id FROM report_detections WHERE id = 2;`).Scan(&reportTechnique)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO report_detections (id_report, id_mitre_datasource) VALUES (2, 2) ON CONFLICT DO NOTHING;`)
		if err != nil {
			return nil, fmt.Errorf("error creating report_detection 1: %w", err)
		}
	}

	err = db.QueryRow(`SELECT id FROM report_detections WHERE id = 3;`).Scan(&reportTechnique)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO report_detections (id_report, id_mitre_datasource) VALUES (3, 3) ON CONFLICT DO NOTHING;`)
		if err != nil {
			return nil, fmt.Errorf("error creating report_detection 1: %w", err)
		}
	}

	err = db.QueryRow(`SELECT id FROM report_mitigations WHERE id = 1;`).Scan(&reportTechnique)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO report_mitigations (id_report, id_report_detection, id_mitre_mitigation) VALUES (1, 1, 1) ON CONFLICT DO NOTHING;`)
		if err != nil {
			return nil, fmt.Errorf("error creating report_mitigation 1: %w", err)
		}
	}

	err = db.QueryRow(`SELECT id FROM report_mitigations WHERE id = 2;`).Scan(&reportTechnique)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO report_mitigations (id_report, id_report_detection, id_mitre_mitigation) VALUES (1, 2, 2) ON CONFLICT DO NOTHING;`)
		if err != nil {
			return nil, fmt.Errorf("error creating report_mitigation 2: %w", err)
		}
	}

	err = db.QueryRow(`SELECT id FROM report_mitigations WHERE id = 3;`).Scan(&reportTechnique)
	if errors.Is(err, sql.ErrNoRows) {
		_, err = db.Exec(`INSERT INTO report_mitigations (id_report, id_report_detection, id_mitre_mitigation) VALUES (2, 3, 3) ON CONFLICT DO NOTHING;`)
		if err != nil {
			return nil, fmt.Errorf("error creating report_mitigation 3: %w", err)
		}
	}

	return &appdbimpl{
		c: db,
	}, nil
}

func (db *appdbimpl) Ping() error {
	return db.c.Ping()
}

