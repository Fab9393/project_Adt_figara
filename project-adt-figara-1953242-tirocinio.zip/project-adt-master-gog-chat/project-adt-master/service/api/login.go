package api

import (
	"github.com/julienschmidt/httprouter"
	"net/http"
    "crypto/rand"
    "encoding/base64"
    "time"
    // "fmt"
    "github.com/dag7dev/project-adt/service/api/reqcontext"
)

const (
    sessionDuration = time.Hour * 24  // Durata della sessione: 24 ore
    sessionIDLength = 32              // Lunghezza dell'ID della sessione (in byte)
)

func (rt *_router) createSession(email string, ctx reqcontext.RequestContext) string {
    // Genera un ID univoco per la sessione
    sessionIDBytes := make([]byte, sessionIDLength)
    _, err := rand.Read(sessionIDBytes)
    if err != nil {
        ctx.Logger.Error("Errore durante la generazione dell'ID della sessione: %s", err)
        return ""
    }
    sessionID := base64.URLEncoding.EncodeToString(sessionIDBytes)

    // Calcola la data di scadenza della sessione
    expiration := time.Now().Add(sessionDuration)

    // Ottieni l'ID dell'utente dal database
    userID, err := rt.db.GetUserIDFromEmail(email)
    if err != nil {
        ctx.Logger.Error("Errore durante l'ottenimento dell'ID dell'utente: %s", err)
        return ""
    }

    // Salva l'ID della sessione e il nome utente associato nel database
    err = rt.db.SaveSession(sessionID, userID, expiration)
    if err != nil {
        // Errore nel salvataggio della sessione nel database
        ctx.Logger.Error("Errore durante il salvataggio della sessione nel database: %s", err)
        return ""
    }

    return sessionID
}


func (rt *_router) login(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
    // estrai email e password da formvalue e li salva in variabili
    email := r.FormValue("email")
    password := r.FormValue("password")
    
    // cripta la password con bcrypt prima di inviarla al datab
    ctx.Logger.Info("Tentato login con email: ", email)

    // Verifica le credenziali dell'utente con la funzione che si interfaccia con il database
    ok, err := rt.db.CheckUserCredentials(email, string(password))
    if err != nil {
        ctx.Logger.Error("Errore durante il controllo delle credenziali dell'utente: ", err)
    }
    if ok {
        // Autenticazione riuscita, crea una sessione per l'utente
        sessionID := rt.createSession(email, ctx)
        ctx.Logger.Info("Login riuscito per l'utente ", email, " con token ", sessionID)
            
        if(sessionID == "") {
            // Errore durante la creazione della sessione
            ctx.Logger.Error("Errore durante la creazione della sessione per l'utente ", email)
            w.WriteHeader(http.StatusInternalServerError)
            w.Write([]byte(`{"error": "Internal server error"}`))
        }

        // restituisce cookie e 200
        w.WriteHeader(http.StatusOK)
        w.Write([]byte(`{"token": "` + sessionID + `"}`))
    } else {
        // Autenticazione fallita, mostra un messaggio di errore all'utente
        ctx.Logger.Info("Login fallito per l'utente %s", email)
        w.WriteHeader(http.StatusUnauthorized)
        w.Write([]byte(`{"error": "Invalid credentials"}`))
    }
}
