package api

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"time"

	"github.com/dag7dev/project-adt/service/api/reqcontext"
	"github.com/dag7dev/project-adt/service/database"
	"github.com/julienschmidt/httprouter"
)

// Calculate the results
func (rt *_router) getResults(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Parse exercitation id from URL params
	exercitationId, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// Retrieve Exercitation object from database
	exercitationDb, err := rt.db.GetExercitation(exercitationId)
	if err != nil {
		http.Error(w, err.Error(), http.StatusNotFound)
		return
	}

	// Convert Exercitation object to API format
	var exercitationApi Exercitation
	exercitationApi.FromDatabase(exercitationDb)

	var dbReports []database.Report

	// if type is 'red' then get all red team reports, if type is 'blue' then get all blue team reports, else get all reports
	dbReports, err = rt.db.ListReports(exercitationId)

	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't list Reports")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	var frontendReports = make([]Report, len(dbReports))
	for idx := range dbReports {
		frontendReports[idx].FromDatabase(dbReports[idx])
	}

	// Attach the team to the report
	for idx := range frontendReports {
		team, err := rt.db.GetTeam(frontendReports[idx].TeamId)
		if err != nil {
			// Log the error and send a 500 to the user
			ctx.Logger.WithError(err).Error("can't get team" + strconv.FormatUint(frontendReports[idx].TeamId, 10))
			w.WriteHeader(http.StatusInternalServerError)
			return
		}

		// Convert the team to a frontend team
		frontendTeam := Team{}
		frontendTeam.FromDatabase(team)

		frontendReports[idx].Team = frontendTeam
	}

	// Attach the user to the report
	for idx := range frontendReports {
		user, err := rt.db.GetUser(frontendReports[idx].IssuedBy)
		if err != nil {
			// Log the error and send a 500 to the user
			ctx.Logger.WithError(err).Error("can't get user")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}

		// Convert the user to a frontend user
		frontendUser := User{}
		frontendUser.FromDatabase(user)

		frontendReports[idx].Author = frontendUser
	}

	// Attach the tactic to the report
	for idx := range frontendReports {
		tactic, err := rt.db.GetMitreTactic(frontendReports[idx].MitreTacticId)
		if err != nil {
			// Log the error and send a 500 to the user
			ctx.Logger.WithError(err).Error("can't get tactic")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}

		// Convert the tactic to a frontend tactic
		frontendTactic := MitreTactic{}
		frontendTactic.FromDatabase(tactic)

		frontendReports[idx].MitreTactic = frontendTactic
	}
	// Attach the techniques to the report
	for idx := range frontendReports {
		techniques, err := rt.db.GetTechniquesFromExercitationAndReportId(frontendReports[idx].ExercitationId, frontendReports[idx].Id)
		if err != nil {
			// Log the error and send a 500 to the user
			ctx.Logger.WithError(err).Error("can't get techniques")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}

		// Convert the techniques to a frontend techniques
		frontendTechniques := make([]ReportTechnique, len(techniques))
		for idx := range techniques {
			frontendTechniques[idx].FromDatabase(techniques[idx])
		}

		// foreach IdMitreTechnique in ReportTechniques
		// get technique from db
		for idx := range frontendTechniques {
			technique, err := rt.db.GetMitreTechnique(frontendTechniques[idx].IdMitreTechnique)
			if err != nil {
				// Log the error and send a 500 to the user
				ctx.Logger.WithError(err).Error("can't get technique")
				w.WriteHeader(http.StatusInternalServerError)
				return
			}

			// Convert the technique to a frontend technique
			frontendTechnique := MitreTechnique{}
			frontendTechnique.FromDatabase(technique)

			// Get the associated detection and mitigation for the technique
			detectionIds, mitigationIds, err := rt.db.GetAssociatedDetectionsAndMitigationsIds(exercitationId, frontendTechniques[idx].IdMitreTechnique)
			if err != nil {
				// Log the error and send a 500 to the user
				ctx.Logger.WithError(err).Error("can't get associated detections and mitigations")
				w.WriteHeader(http.StatusInternalServerError)
				return
			}

			if detectionIds[0] != 0 {
				detections := make([]ReportDetection, 1) // crea una lista con un solo elemento
				for i, id := range detectionIds[:1] {    // limita la range ad un solo elemento
					detection, err := rt.db.GetReportDetectionById(id)
					if err != nil {
						// Log the error and send a 500 to the user
						ctx.Logger.WithError(err).Error("can't get report detection")
						w.WriteHeader(http.StatusInternalServerError)
						return
					}
					// convert the detection to a frontend detection
					var frontendDetection ReportDetection
					frontendDetection.FromDatabase(detection)

					// add mitre_datasource if id_mitre_datasource is not 0
					if detection.IdMitreDatasource != 0 {
						mitreDatasource, err := rt.db.GetMitreDatasource(detection.IdMitreDatasource)
						if err != nil {
							// Log the error and send a 500 to the user
							ctx.Logger.WithError(err).Error("can't get mitre datasource")
							w.WriteHeader(http.StatusInternalServerError)
							return
						}

						// convert the mitre datasource to a frontend mitre datasource
						var frontendMitreDatasource MitreDatasource
						frontendMitreDatasource.FromDatabase(mitreDatasource)

						frontendDetection.MitreDatasource = frontendMitreDatasource
					}

					detections[i] = frontendDetection
				}
				frontendTechniques[idx].ReportDetections = detections
			}

			if  mitigationIds[0] != 0 {
				mitigation, err := rt.db.GetReportMitigationById(mitigationIds[0])
				if err != nil {
					// Log the error and send a 500 to the user
					ctx.Logger.WithError(err).Error("can't get report mitigation")
					w.WriteHeader(http.StatusInternalServerError)
					return
				}
				var frontendMitigation ReportMitigation
				frontendMitigation.FromDatabase(mitigation)

				// Add mitigation-specific fields
				if frontendMitigation.IdMitreMitigation != 0 {
					mitrem, err := rt.db.GetMitreMitigation(frontendMitigation.IdMitreMitigation)
					if err != nil {
						// Log the error and continue without the MitreMitigation field
						ctx.Logger.WithError(err).Error("can't get MitreMitigation")
					} else {
						// convert the mitigation to a frontend mitigation
						var frontendMitreMitigation MitreMitigation
						frontendMitreMitigation.FromDatabase(mitrem)

						frontendMitigation.MitreMitigation = frontendMitreMitigation
					}
				}

				// Add datasource-specific fields
				if frontendMitigation.IdReportDetection != 0 {
					detection, err := rt.db.GetReportDetectionById(frontendMitigation.IdReportDetection)
					if err != nil {
						// Log the error and continue without the MitreDatasource field
						ctx.Logger.WithError(err).Error("can't get report detection")
					} else {
						// get the mitre datasource
						mitreDatasource, err := rt.db.GetMitreDatasource(detection.IdMitreDatasource)
						if err != nil {
							// Log the error and continue without the MitreDatasource field
							ctx.Logger.WithError(err).Error("can't get mitre datasource")
						} else {
							// convert the mitre datasource to a frontend mitre datasource
							var frontendMitreDatasource MitreDatasource
							frontendMitreDatasource.FromDatabase(mitreDatasource)
							frontendMitigation.MitreDetection = frontendMitreDatasource
						}
					}
				}

				frontendTechniques[idx].ReportMitigations = []ReportMitigation{frontendMitigation}
			}
			frontendTechniques[idx].MitreTechnique = frontendTechnique
		}

		frontendReports[idx].ReportTechniques = frontendTechniques
	}

	// split frontendReports if red in redreports else in bluereports
	var redReports []Report
	var blueReports []Report

	fmt.Println(frontendReports)
	for _, report := range frontendReports {
		if report.Team.Role == "Red" {
			redReports = append(redReports, report)
		} else {
			blueReports = append(blueReports, report)
		}
	}

	// Attach RedReports and BlueReports to Exercitation object
	exercitationApi.RedReports = redReports
	exercitationApi.BlueReports = blueReports

	// Calculate the ideal path score for both Red and Blue teams
    //redScore := calculateIdealPathScore(exercitationApi.RedReports, exercitationApi.IdealPath, "Red")
    //blueScore := calculateIdealPathScore(exercitationApi.BlueReports, exercitationApi.IdealPath, "Blue")
	
	// Calculate results for Exercitation
	idealPaths, err := rt.db.GetIdealPath(exercitationId)
    if err != nil {
        // Handle the error
        http.Error(w, "Error getting ideal paths", http.StatusInternalServerError)
        return
    }

    // If at least one ideal path exists, set x to true
    x := len(idealPaths) > 0

	s2 := 0.0
	if x {
		s2 = rt.calculateS2WithIdealPaths(exercitationApi, 1.0, 1.0, exercitationId)
	} else {
		s2 = rt.calculateS2(exercitationApi, 1.0, 1.0)
	}
	s1 := calculateS1(exercitationApi, 1.0/4.0, 1.0/3.0)
	s4 := rt.calculateS4(exercitationApi)
	// Send results to client as JSON
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(struct {
		S1 float64 `json:"s1"`
		S2 float64 `json:"s2"`
		S4 float64 `json:"s4"`
	}{s1, s2, s4})

}

func calculateS1(e Exercitation, alpha0 float64, alpha1 float64) float64 {
	// Set weights
	alpha2 := 1.0 / 3.0
	uniqueIds := make(map[uint64]bool)
	nTacticRed := 0.0

	for _, redReport := range e.RedReports {
		if !uniqueIds[redReport.MitreTacticId] {
			uniqueIds[redReport.MitreTacticId] = true
			nTacticRed += 1.0
		}
	}

	// Calculate tactic score
	tacticScore := 0.0
	uniqueTactics := make(map[uint64]bool)
	for _, redReport := range e.RedReports {
		for _, blueReport := range e.BlueReports {
			if !uniqueTactics[redReport.MitreTacticId] {
				if redReport.MitreTacticId == blueReport.MitreTacticId {
					uniqueTactics[redReport.MitreTacticId] = true
					tacticScore += 1.0
				}
			}
		}
	}

	// Calculate number of techniques and subtechniques by red team
	nTechRed := 0.0
	nSubtechRed := 0.0
	for _, redReport := range e.RedReports {
		for _, redTechnique := range redReport.ReportTechniques {
			if redTechnique.IsSubtechnique {
				nSubtechRed += 1.0
			} else {
				nTechRed += 1.0
			}
		}
	}

	// Calculate technique score
	techniqueScore := 0.0
	subTechniqueScore := 0.0
	for _, blueReport := range e.BlueReports {
		for _, redReport := range e.RedReports {
			for _, blueTechnique := range blueReport.ReportTechniques {
				for _, redTechnique := range redReport.ReportTechniques {
					if blueTechnique.IdMitreTechnique == redTechnique.IdMitreTechnique {
						if redTechnique.IsSubtechnique {
							subTechniqueScore += 1.0
						} else {
							techniqueScore += 1.0
						}
					}
				}
			}
		}
	}

	
	var partialS1 float64
	var partialS2 float64
	var partialS3 float64
	
	if((alpha0 * tacticScore) == 0.0){
		partialS1 = 0.0
	}else{
		partialS1 = (alpha0 * tacticScore) / nTacticRed
	}


	if((alpha1 * techniqueScore) == 0.0){
		partialS2 = 0.0
	}else{
		partialS2 = (alpha1 * techniqueScore) / nTechRed
	}

	if((alpha2 * subTechniqueScore) == 0.0){
		partialS3 = 0.0
	}else{
		partialS3 = (alpha2 * subTechniqueScore) / nSubtechRed
	}

	// Calculate S1 score
	S1 := (partialS1 + partialS2 + partialS3)

	return S1
}

func (rt *_router) calculateS2(e Exercitation, alpha1, alpha2 float64) float64 {
	// prendo i report blu
	a3 := alpha2 / (alpha1 + alpha2)
	a4 := 1 / (1 + alpha1/alpha2)

	ptsDetections := 0.0
	ptsMitigations := 0.0

	// controllo la detection
	for _, blueReport := range e.BlueReports {
		for _, blueTechnique := range blueReport.ReportTechniques {
			for _, blueDetection := range blueTechnique.ReportDetections {
				if blueDetection.IdMitreDatasource != 0 {
					// se è ottimale, ossia è nella lista delle possibili detection
					ids, err := rt.db.GetOptimalDetection(blueTechnique.IdMitreTechnique)
					if err != nil {
						fmt.Println(err)
					}

					for _, id := range ids {
						if id.Name == blueDetection.MitreDatasource.Name {
							ptsDetections++
							break
						}
					}

				}
			}
		}
	}

	// controllo la mitigation
	for _, blueReport := range e.BlueReports {
		for _, blueTechnique := range blueReport.ReportTechniques {
			for _, blueDetection := range blueTechnique.ReportMitigations {
				if blueDetection.IdMitreMitigation != 0 {
					// se è ottimale, ossia è nella lista delle possibili detection
					ids, err := rt.db.GetOptimalMitigation(blueTechnique.IdMitreTechnique)
					if err != nil {
						fmt.Println(err)
					}

					for _, id := range ids {
						if id.Name == blueDetection.MitreMitigation.Name {
							ptsMitigations++
							break
						}
					}

				}
			}
		}
	}

	return a3*ptsDetections + a4*ptsMitigations
}

func (rt *_router) calculateS4(e Exercitation) float64 {
	// Create a map to store the red reports by technique ID
	redReportsByTechnique := make(map[uint64][]Report)

	// Group the red reports by technique ID
	for _, redReport := range e.RedReports {
		for _, technique := range redReport.ReportTechniques {
			redReportsByTechnique[technique.IdMitreTechnique] = append(redReportsByTechnique[technique.IdMitreTechnique], redReport)
		}
	}

	// Calculate the S4 score
	var score float64
	for _, blueReport := range e.BlueReports {
		for _, blueTechnique := range blueReport.ReportTechniques {
			// Check if there are any red reports for the same technique
			redReports := redReportsByTechnique[blueTechnique.IdMitreTechnique]
			for _, redReport := range redReports {
				// Check if the red report was issued within the last 30 minutes of the blue report
				// parse the issuedWhen string for both red and blue
				blueIssuedWhen, err := time.Parse(time.RFC3339, blueReport.IssuedWhen)
				if err != nil {
					fmt.Println(err)
				}

				redIssuedWhen, err := time.Parse(time.RFC3339, redReport.IssuedWhen)
				if err != nil {
					fmt.Println(err)
				}

				elapsed := blueIssuedWhen.Sub(redIssuedWhen)
				if elapsed.Minutes() <= 30 {
					// Assign a score based on the elapsed time
					switch {
					case elapsed.Minutes() <= 10:
						score += 1.0
					case elapsed.Minutes() <= 30:
						score += 0.5
					}
					// Break out of the loop since we found a matching red report
					break
				}
			}
		}
	}

	return score
}

func (rt *_router) calculateS2WithIdealPaths(e Exercitation, alpha1, alpha2 float64, exercitationId uint64) float64 {
	idealPaths,_ := rt.db.GetIdealPath(exercitationId)
    a3 := alpha2 / (alpha1 + alpha2)
    a4 := 1 / (1 + alpha1/alpha2)

    ptsDetections := 0.0
    ptsMitigations := 0.0

    // Creare slice per contenere le detection e le mitigation dagli ideal paths
    idealDetections := make([]string, 0)
    idealMitigations := make([]string, 0)

    // Aggiungere le detection e le mitigation dagli ideal paths alle slice
    for _, idealPath := range idealPaths {
        idealDetections = append(idealDetections, idealPath.Detection)
        idealMitigations = append(idealMitigations, idealPath.Mitigation)
    }

    // Controllo delle detection
    for _, blueReport := range e.BlueReports {
        for _, blueTechnique := range blueReport.ReportTechniques {
            for _, blueDetection := range blueTechnique.ReportDetections {
                for _, idealDetection := range idealDetections {
                    if blueDetection.MitreDatasource.Name == idealDetection {
                        ptsDetections++
                        break
                    }
                }
            }
        }
    }

    // Controllo delle mitigation
    for _, blueReport := range e.BlueReports {
        for _, blueTechnique := range blueReport.ReportTechniques {
            for _, blueMitigation := range blueTechnique.ReportMitigations {
                for _, idealMitigation := range idealMitigations {
                    if blueMitigation.MitreMitigation.Name == idealMitigation {
                        ptsMitigations++
                        break
                    }
                }
            }
        }
    }

    return a3*ptsDetections + a4*ptsMitigations
}
