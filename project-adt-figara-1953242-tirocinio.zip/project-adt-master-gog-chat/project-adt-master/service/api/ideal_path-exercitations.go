package api

import (
    "encoding/json"
    "net/http"
    "strconv"

    "github.com/dag7dev/project-adt/service/api/reqcontext"
    "github.com/dag7dev/project-adt/service/database"
    "github.com/julienschmidt/httprouter"
)

// listIdealPathOfExercitation gestisce la richiesta per ottenere l'elenco degli elementi del percorso ideale di un esercizio.
// getIdealPathsForExercitation gestisce la richiesta per recuperare gli idealPath associati a un'esercitazione.
func (rt *_router) getIdealPathsForExercitation(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
    // Parse the exercitation ID from the URL
    exercitationID, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
    if err != nil {
        ctx.Logger.WithError(err).Error("invalid exercitation ID")
        w.WriteHeader(http.StatusBadRequest)
        return
    }

    // Retrieve the Ideal Paths for the exercitation
    idealPaths, err := rt.db.GetIdealPath(exercitationID)
    if err != nil {
        ctx.Logger.WithError(err).Error("failed to retrieve Ideal Paths for exercitation")
        w.WriteHeader(http.StatusInternalServerError)
        return
    }

    // Marshal the idealPaths slice into JSON
    jsonResponse, err := json.Marshal(idealPaths)
    if err != nil {
        ctx.Logger.WithError(err).Error("failed to marshal Ideal Paths into JSON")
        w.WriteHeader(http.StatusInternalServerError)
        return
    }

    // Set the content type header and write the JSON response
    w.Header().Set("Content-Type", "application/json")
    w.WriteHeader(http.StatusOK)
    w.Write(jsonResponse)
}


// addIdealPathToExercitation gestisce la richiesta per aggiungere gli elementi del percorso ideale a un esercizio.
func (rt *_router) addIdealPathToExercitation(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
    // Parse the exercitation ID from the URL
    exercitationID, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
    if err != nil {
        ctx.Logger.WithError(err).Error("invalid exercitation ID")
        w.WriteHeader(http.StatusBadRequest)
        return
    }

    // Decode the request body to retrieve the Ideal Path elements
    var elements []database.IdealPathElement
    if err := json.NewDecoder(r.Body).Decode(&elements); err != nil {
        ctx.Logger.WithError(err).Error("failed to decode request body")
        w.WriteHeader(http.StatusBadRequest)
        return
    }

    // Add the Ideal Path elements to the exercitation
    if err := rt.db.AddIdealPath(exercitationID, elements); err != nil {
        ctx.Logger.WithError(err).Error("failed to add Ideal Path elements to exercitation")
        w.WriteHeader(http.StatusInternalServerError)
        return
    }

    // Send a success response
    w.WriteHeader(http.StatusOK)
}

