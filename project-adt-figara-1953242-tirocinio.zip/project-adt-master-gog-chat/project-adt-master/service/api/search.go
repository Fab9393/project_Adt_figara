package api

import (
	"encoding/json"
	"math"
	"net/http"
	"strconv"
	"strings"

	"github.com/dag7dev/project-adt/service/api/reqcontext"
	"github.com/dag7dev/project-adt/service/database"
	"github.com/julienschmidt/httprouter"
)
// Given a query language team name, return first 15 teams that match.
func (rt *_router) search(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
    // Get parameters from the query string.
    kind := r.URL.Query().Get("kind")
    page, _ := strconv.Atoi(r.URL.Query().Get("page"))
    size, _ := strconv.Atoi(r.URL.Query().Get("size"))
    sort := r.URL.Query().Get("sort")
    order_by := r.URL.Query().Get("order_by")
    name := r.URL.Query().Get("name")

    // Set default values.
    if page == 0 {
        page = 1
    }
    if size == 0 {
        size = 15
    }
    if sort == "" {
        sort = "id"
    }
    if order_by == "" {
        order_by = "asc"
    }

    // Validate parameters.
    if kind == ""  {
        w.WriteHeader(http.StatusBadRequest)
        return
    }

    if name == "" {
        name = "a"
    }

    // Query the database based on the given kind.
    var dbresults interface{}
    var total int
    switch strings.ToLower(kind) {
    case "teams":
        total, dbresults, _ = rt.db.SearchTeams(name, page, size, sort, order_by)
    case "users":
        total, dbresults, _ = rt.db.SearchUsers(name, page, size, sort, order_by)
    default:
        w.WriteHeader(http.StatusBadRequest)
        return
    }

    // Calculate the number of pages.
    totalPages := int(math.Ceil(float64(total) / float64(size)))

    // Convert database results to API results.
    var results interface{}
    switch strings.ToLower(kind) {
    case "teams":
        var teams []Team
        for _, team := range dbresults.([]database.Team) {
            var x Team
            x.FromDatabase(team)
            teams = append(teams, x)
        }
        results = teams
    case "users":
        var users []User
        for _, user := range dbresults.([]database.User) {
            var x User
            x.FromDatabase(user)
            users = append(users, x)
        }
        results = users
    }

    // Send the response.
    metadata := struct {
        Page  int `json:"current"`
        Total int `json:"total"`
        Size  int `json:"size"`
    }{
        Page:  page,
        Total: totalPages,
        Size:  size,
    }
    w.Header().Set("Content-Type", "application/json")
    _ = json.NewEncoder(w).Encode(struct {
        Metadata interface{} `json:"metadata"`
        Results  interface{} `json:"results"`
    }{
        Metadata: metadata,
        Results:  results,
    })
}
