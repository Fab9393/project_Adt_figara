package api

import (
	"encoding/json"
	"net/http"
	"time"
	"github.com/dag7dev/project-adt/service/api/reqcontext"
	"github.com/dag7dev/project-adt/service/database"
	"github.com/julienschmidt/httprouter"
)

// getMessagesByExerciseID gestisce la richiesta GET per recuperare i messaggi di una esercitazione.
func (rt *_router) getMessagesByExerciseID(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	exerciseID, err := strconv.ParseUint(ps.ByName("exercise_id"), 10, 64)
	if err != nil {
		ctx.Logger.WithError(err).Error("invalid exercise ID")
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	messages, err := rt.db.GetMessagesByExerciseID(exerciseID)
	if err != nil {
		ctx.Logger.WithError(err).Error("can't get messages")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	if err := json.NewEncoder(w).Encode(messages); err != nil {
		ctx.Logger.WithError(err).Error("failed to encode messages")
		w.WriteHeader(http.StatusInternalServerError)
	}
}

// postMessage gestisce la richiesta POST per inserire un nuovo messaggio.
func (rt *_router) postMessage(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	var msg struct {
		ExerciseID uint64 `json:"exercise_id"`
		SenderID   uint64 `json:"sender_id"`
		ReceiverID uint64 `json:"receiver_id"`
		Message    string `json:"message"`
	}

	if err := json.NewDecoder(r.Body).Decode(&msg); err != nil {
		ctx.Logger.WithError(err).Error("invalid request body")
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	timestamp := time.Now()

	err := rt.db.InsertMessage(msg.ExerciseID, msg.SenderID, msg.ReceiverID, msg.Message, timestamp)
	if err != nil {
		ctx.Logger.WithError(err).Error("can't insert message")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
}
