package api

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/dag7dev/project-adt/service/api/reqcontext"
	"github.com/dag7dev/project-adt/service/database"
	"github.com/julienschmidt/httprouter"
)

func (rt *_router) getOngoingExercitation(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {

	// Parse the query string exercitation id.
	var err error
	var dbexercitation database.Exercitation
	var exercitation Exercitation

	// Request an unfiltered list of exercitations from the DB
	dbexercitation, err = rt.db.GetOngoingExercitation()

	if err != nil {
		// Log the error and send a 500 to the user
		//ctx.Logger.WithError(err).Error("can't get ongoing exercitation")
		w.WriteHeader(http.StatusNotFound)
		return
	}

	// Before sending the list to the client we need to convert it to json
	exercitation.FromDatabase(dbexercitation)

	// Send the list to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(exercitation)
}

// list all the exercitations
func (rt *_router) listExercitations(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {

	// Parse the query string exercitation id.
	var err error
	var dbexercitations []database.Exercitation

	// Request an unfiltered list of exercitations from the DB
	dbexercitations, err = rt.db.ListExercitations()

	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't list exercitations")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Before sending the list to the client we need to convert it to json
	var frontendExs = make([]Exercitation, len(dbexercitations))
	for idx := range dbexercitations {
		frontendExs[idx].FromDatabase(dbexercitations[idx])
	}

	// Send the list to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(frontendExs)
}

func (rt *_router) createExercitation(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Read the new content for the exercitation from the request body.
	var exercitation Exercitation

	// Decode the body of the request into the exercitation structure.
	err := json.NewDecoder(r.Body).Decode(&exercitation)
	if err != nil {
		// The body was not a parseable JSON, reject it
		w.WriteHeader(http.StatusBadRequest)
		return
	} else if !exercitation.IsValid() {
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	dbexercitation, err := rt.db.CreateExercitation(exercitation.ToDatabase())
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't create the exercitation")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	exercitation.FromDatabase(dbexercitation)

	// Send the output to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(exercitation)
}

func (rt *_router) getExercitation(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {

	// Parse the query string exercitation id.
	var err error
	var exercitation database.Exercitation
	id, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		// The ID was not a valid number, reject it
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	// Get the exercitation from the database.
	exercitation, err = rt.db.GetExercitation(id)
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't get the exercitation")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	ctx.Logger.WithField("exercitation", exercitation).Info("exercitation found")
	// convert the database exercitation to the frontend one
	var frontendEx = Exercitation{}
	frontendEx.FromDatabase(exercitation)

	// Get red reports and blue reports for each exercitation and add them to red_reports and blue_reports
	redReports, err := rt.db.ListRedTeamReports(id)
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't get red reports")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	blueReports, err := rt.db.ListBlueTeamReports(id)
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't get blue reports")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	frontendEx.RedReports = make([]Report, len(redReports))
	for idx := range redReports {
		frontendEx.RedReports[idx].FromDatabase(redReports[idx])
		techniques, err := rt.db.GetTechniquesFromExercitationAndReportId(exercitation.Id, redReports[idx].Id)
		if err != nil {
			// Log the error and send a 500 to the user
			ctx.Logger.WithError(err).Error("can't get techniques")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		frontendEx.RedReports[idx].ReportTechniques = make([]ReportTechnique, len(techniques))
		for techIdx := range techniques {
			frontendEx.RedReports[idx].ReportTechniques[techIdx].FromDatabase(techniques[techIdx])
		}
	}

	frontendEx.BlueReports = make([]Report, len(blueReports))
	for idx := range blueReports {
		frontendEx.BlueReports[idx].FromDatabase(blueReports[idx])
		techniques, err := rt.db.GetTechniquesFromExercitationAndReportId(exercitation.Id, blueReports[idx].Id)
		if err != nil {
			// Log the error and send a 500 to the user
			ctx.Logger.WithError(err).Error("can't get techniques")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		frontendEx.BlueReports[idx].ReportTechniques = make([]ReportTechnique, len(techniques))
		for techIdx := range techniques {
			frontendEx.BlueReports[idx].ReportTechniques[techIdx].FromDatabase(techniques[techIdx])
		}
	}

	// Send the output to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(frontendEx)
}

func (rt *_router) updateExercitation(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Read the new content for the exercitation from the request body.
	var exercitation Exercitation
	err := json.NewDecoder(r.Body).Decode(&exercitation)
	if err != nil {
		// The body was not a parseable JSON, reject it
		w.WriteHeader(http.StatusBadRequest)
		return
	} else if !exercitation.IsValid() {
		// The body was not a valid exercitation, reject it
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	// Parse the query string exercitation id.
	var id uint64
	id, err = strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		// The ID was not a valid number, reject it
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	// Force the ID to the one in the query string.
	exercitation.Id = id

	// Update the team in the database.
	e, err := rt.db.UpdateExercitation(exercitation.ToDatabase())
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't update the exercitation")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Send the output to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(e)
}

func (rt *_router) deleteExercitation(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Parse the query string exercitation id.
	var err error
	var id uint64
	id, err = strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		// The ID was not a valid number, reject it
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	// Delete the team from the database.
	err = rt.db.DeleteExercitation(id)
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't delete the exercitation")
		w.WriteHeader(http.StatusNotFound)
		return
	} 

	// Send a 204 to the user.
	w.WriteHeader(http.StatusNoContent)
}

func (rt *_router) getTeamsFromExercitation(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Parse the query string exercitation id.
	var err error
	var id uint64
	id, err = strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		// The ID was not a valid number, reject it
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	// Get the teams from the database.
	teams, err := rt.db.GetTeamsFromExercitation(id)
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't get the teams")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Send the output to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(teams)
}

/*
func (rt *_router) addIdealPath(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
    // Leggi l'ID dell'esercitazione dalla richiesta
    id, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
    if err != nil {
        // ID non valido, restituisci errore
        w.WriteHeader(http.StatusBadRequest)
        return
    }

    // Leggi i dati degli elementi dall'array nel corpo della richiesta
    var elements []IdealPathElement
    err = json.NewDecoder(r.Body).Decode(&elements)
    if err != nil {
        // Il corpo della richiesta non è un JSON parsabile, restituisci errore
        w.WriteHeader(http.StatusBadRequest)
        return
    }

    // Recupera l'esercitazione dal database utilizzando l'ID
    exercitation, err := rt.db.GetExercitation(id)
    if err != nil {
        // Impossibile trovare l'esercitazione nel database, restituisci errore
        w.WriteHeader(http.StatusNotFound)
        return
    }

    // Aggiungi gli elementi all'ideal path dell'esercitazione
    for _, element := range elements {
        exercitation.AddIdealPath(element)
    }

    // Aggiorna l'esercitazione nel database con il nuovo ideal path
    updatedExercitation, err := rt.db.UpdateExercitation(exercitation)
    if err != nil {
        // Impossibile aggiornare l'esercitazione nel database, restituisci errore
        w.WriteHeader(http.StatusInternalServerError)
        return
    }

    // Restituisci l'esercitazione aggiornata come risposta
    w.Header().Set("Content-Type", "application/json")
    _ = json.NewEncoder(w).Encode(updatedExercitation)
}
*/
