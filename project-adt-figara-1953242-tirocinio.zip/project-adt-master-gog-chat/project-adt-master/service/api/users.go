package api

import (
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"golang.org/x/crypto/bcrypt"
	"fmt"
	"log"
	"github.com/dag7dev/project-adt/service/api/reqcontext"
	"github.com/dag7dev/project-adt/service/database"
	"github.com/julienschmidt/httprouter"
)

func (rt *_router) getMyRoleFromToken(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Get the User ID from cookie token
	var err error
	var user database.User
	var role string

	// Get the token from the cookie
	token, err := r.Cookie("token")
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't get the token")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Get the user from the token
	user, err = rt.db.GetUserFromToken(token.Value)
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't get the user")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	if user.Role != "admin" {
		// Get the ongoing exercitation
		ongoingEx, err := rt.db.GetOngoingExercitation()
		if err != nil {
			// Log the error and send a 500 to the user
			ctx.Logger.WithError(err).Error("can't get the ongoing exercitation")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}

		// Get the role from the user
		role, err = rt.db.GetUserRoleInExcercitation(user.Id, ongoingEx.Id)
		if err != nil {
			// Log the error and send a 500 to the user
			ctx.Logger.WithError(err).Error("can't get the role")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
	} else {
		role = "admin"
	}
	// Send the output to the user.
	w.Header().Set("Content-Type", "application/json")
	// _ = json.NewEncoder(w).Encode(role)
	// JSON encode an object with the role
	_ = json.NewEncoder(w).Encode(struct {
		Role string `json:"role"`
	}{
		Role: role,
	})
}

func (rt *_router) getUserFromToken(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Get the User ID from cookie token
	var err error
	var user database.User

	// Get the token from the cookie
	token, err := r.Cookie("token")
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't get the token")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Get the user from the token
	user, err = rt.db.GetUserFromToken(token.Value)
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't get the user")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Convert the user to the public format
	var pf User
	pf.FromDatabase(user)

	// Send the output to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(pf)
}

func (rt *_router) createUser(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Read the new content for the user from the request body.
	var user User
	err := json.NewDecoder(r.Body).Decode(&user)
	if err != nil {
		// The body was not a parseable JSON, reject it
		w.WriteHeader(http.StatusBadRequest)
		return
	} else if !user.IsValid() {
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	fmt.Println(user.Password)
	// bcrypt the password
	hashed_pwd, err := bcrypt.GenerateFromPassword([]byte(user.Password), 10)
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't bcrypt the password")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	fmt.Println(string(hashed_pwd))
	user.Password = string(hashed_pwd)

	// Create the user: new instance of the user with the
	// same information, plus the ID.
	dbuser, err := rt.db.CreateUser(user.ToDatabase())
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't create the user")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Here we can re-use `user` as FromDatabase is overwriting every variabile in the structure.
	user.FromDatabase(dbuser)

	// Send the output to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(user)
}

func (rt *_router) getUser(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {

	// Parse the query string exercitation id.
	var err error
	var user database.User
	id, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		// The ID was not a valid number, reject it
		ctx.Logger.WithError(err).Error("can't list user - bad uint")
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	// Request an unfiltered list of user from the DB
	user, err = rt.db.GetUser(id)

	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't list user")
		w.WriteHeader(http.StatusNotFound)
		return
	}

	// Parse real object from db
	var pf User
	pf.FromDatabase(user)

	// Send the user to the user
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(pf)
}

func (rt *_router) deleteUser(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Get the User ID from URL.
	id, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		// The ID was not a valid number, reject it
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	err = rt.db.DeleteUser(id)
	if errors.Is(err, database.ErrUserDoesNotExist) {
		// The user (indicated by id) does not exist
		w.WriteHeader(http.StatusNotFound)
		return
	} else if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).WithField("id", id).Error("can't delete the user")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusNoContent)
}

func (rt *_router) listUsers(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {

	// Parse the query string exercitation id.
	var err error
	var users []database.User

	// Request an unfiltered list of users from the DB
	users, err = rt.db.ListUsers()

	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't list users")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Before sending the list to the client we need to convert it to json
	var frontendUsers = make([]User, len(users))
	for idx := range users {
		frontendUsers[idx].FromDatabase(users[idx])
	}

	// Send the list to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(frontendUsers)
}

func (rt *_router) getTeamRoleFromUserId(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
    // Get the User ID from URL.
    id, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
    if err != nil {
        // The ID was not a valid number, reject it
        w.WriteHeader(http.StatusBadRequest)
        return
    }

    role, err := rt.db.GetTeamRoleFromUserId(id)
    if err != nil {
        // Log the error and send a 500 to the user
        log.Println("can't get the team role", "id", id, "error", err)
        w.WriteHeader(http.StatusInternalServerError)
        return
    }

    // Send the team role to the user.
    w.Header().Set("Content-Type", "application/json")
    _ = json.NewEncoder(w).Encode(struct {
        Role string `json:"role"`
    }{
        Role: role,
    })
}
