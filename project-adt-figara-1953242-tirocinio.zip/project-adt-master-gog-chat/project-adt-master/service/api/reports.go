package api

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/dag7dev/project-adt/service/api/reqcontext"
	"github.com/dag7dev/project-adt/service/database"
	"github.com/julienschmidt/httprouter"
)

func (rt *_router) listReports(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// get parameter from url 'type'
	reportType := r.URL.Query().Get("type")

	// get parameter from post body 'exercitationId'
	id := ps.ByName("id")

	// Convert the id to an uint64
	exId, err := strconv.ParseUint(id, 10, 64)

	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't convert id to int")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	var dbReports []database.Report

	// if type is 'red' then get all red team reports, if type is 'blue' then get all blue team reports, else get all reports
	if reportType == "red" {
		dbReports, err = rt.db.ListRedTeamReports(exId)
	} else if reportType == "blue" {
		dbReports, err = rt.db.ListBlueTeamReports(exId)
	} else {
		dbReports, err = rt.db.ListReports(exId)
	}

	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't list Reports")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	var frontendReports = make([]Report, len(dbReports))
	for idx := range dbReports {
		frontendReports[idx].FromDatabase(dbReports[idx])
	}

	fmt.Println(frontendReports)
	// Attach the team to the report
	for idx := range frontendReports {
		team, err := rt.db.GetTeam(frontendReports[idx].TeamId)
		if err != nil {
			// Log the error and send a 500 to the user
			ctx.Logger.WithError(err).Error("can't get team" + strconv.FormatUint(frontendReports[idx].TeamId, 10))
			w.WriteHeader(http.StatusInternalServerError)
			return
		}

		// Convert the team to a frontend team
		frontendTeam := Team{}
		frontendTeam.FromDatabase(team)

		frontendReports[idx].Team = frontendTeam
	}

	// Attach the user to the report
	for idx := range frontendReports {
		user, err := rt.db.GetUser(frontendReports[idx].IssuedBy)
		if err != nil {
			// Log the error and send a 500 to the user
			ctx.Logger.WithError(err).Error("can't get user")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}

		// Convert the user to a frontend user
		frontendUser := User{}
		frontendUser.FromDatabase(user)

		frontendReports[idx].Author = frontendUser
	}

	// Attach the tactic to the report
	for idx := range frontendReports {
		tactic, err := rt.db.GetMitreTactic(frontendReports[idx].MitreTacticId)
		if err != nil {
			// Log the error and send a 500 to the user
			ctx.Logger.WithError(err).Error("can't get tactic")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}

		// Convert the tactic to a frontend tactic
		frontendTactic := MitreTactic{}
		frontendTactic.FromDatabase(tactic)

		frontendReports[idx].MitreTactic = frontendTactic
	}
	// Attach the techniques to the report
	for idx := range frontendReports {
		techniques, err := rt.db.GetTechniquesFromExercitationAndReportId(frontendReports[idx].ExercitationId, frontendReports[idx].Id)
		if err != nil {
			// Log the error and send a 500 to the user
			ctx.Logger.WithError(err).Error("can't get techniques")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}

		// Convert the techniques to a frontend techniques
		frontendTechniques := make([]ReportTechnique, len(techniques))
		for idx := range techniques {
			frontendTechniques[idx].FromDatabase(techniques[idx])
		}

		// foreach IdMitreTechnique in ReportTechniques
		// get technique from db
		for idx := range frontendTechniques {
			technique, err := rt.db.GetMitreTechnique(frontendTechniques[idx].IdMitreTechnique)
			if err != nil {
				// Log the error and send a 500 to the user
				ctx.Logger.WithError(err).Error("can't get technique")
				w.WriteHeader(http.StatusInternalServerError)
				return
			}

			// Convert the technique to a frontend technique
			frontendTechnique := MitreTechnique{}
			frontendTechnique.FromDatabase(technique)

			if reportType == "blue" {
				ctx.Logger.Info("sono entrato qui!!!!!!!!!!!!!!!")
				// Get the associated detection and mitigation for the technique
				detectionIds, mitigationIds, err := rt.db.GetAssociatedDetectionsAndMitigationsIds(exId, frontendTechniques[idx].IdMitreTechnique)
				if err != nil {
					// Log the error and send a 500 to the user
					ctx.Logger.WithError(err).Error("can't get associated detections and mitigations")
					w.WriteHeader(http.StatusInternalServerError)
					return
				}

				
				if detectionIds[0] != 0 {
					detections := make([]ReportDetection, 1) // crea una lista con un solo elemento
					for i, id := range detectionIds[:1] {    // limita la range ad un solo elemento
						detection, err := rt.db.GetReportDetectionById(id)
						if err != nil {
							// Log the error and send a 500 to the user
							ctx.Logger.WithError(err).Error("can't get report detection")
							w.WriteHeader(http.StatusInternalServerError)
							return
						}
						// convert the detection to a frontend detection
						var frontendDetection ReportDetection
						frontendDetection.FromDatabase(detection)

						// add mitre_datasource if id_mitre_datasource is not 0
						if detection.IdMitreDatasource != 0 {
							mitreDatasource, err := rt.db.GetMitreDatasource(detection.IdMitreDatasource)
							if err != nil {
								// Log the error and send a 500 to the user
								ctx.Logger.WithError(err).Error("can't get mitre datasource")
								w.WriteHeader(http.StatusInternalServerError)
								return
							}

							// convert the mitre datasource to a frontend mitre datasource
							var frontendMitreDatasource MitreDatasource
							frontendMitreDatasource.FromDatabase(mitreDatasource)

							frontendDetection.MitreDatasource = frontendMitreDatasource
						}

						detections[i] = frontendDetection
					}
					frontendTechniques[idx].ReportDetections = detections
				}

				if mitigationIds[0] != 0 {
					mitigation, err := rt.db.GetReportMitigationById(mitigationIds[0])
					if err != nil {
						// Log the error and send a 500 to the user
						ctx.Logger.WithError(err).Error("can't get report mitigation")
						w.WriteHeader(http.StatusInternalServerError)
						return
					}
					var frontendMitigation ReportMitigation
					frontendMitigation.FromDatabase(mitigation)

					// Add mitigation-specific fields
					if frontendMitigation.IdMitreMitigation != 0 {
						mitrem, err := rt.db.GetMitreMitigation(frontendMitigation.IdMitreMitigation)
						if err != nil {
							// Log the error and continue without the MitreMitigation field
							ctx.Logger.WithError(err).Error("can't get MitreMitigation")
						} else {
							// convert the mitigation to a frontend mitigation
							var frontendMitreMitigation MitreMitigation
							frontendMitreMitigation.FromDatabase(mitrem)

							frontendMitigation.MitreMitigation = frontendMitreMitigation
						}
					}

					// Add datasource-specific fields
					if frontendMitigation.IdReportDetection != 0 {
						detection, err := rt.db.GetReportDetectionById(frontendMitigation.IdReportDetection)
						if err != nil {
							// Log the error and continue without the MitreDatasource field
							ctx.Logger.WithError(err).Error("can't get report detection")
						} else {
							// get the mitre datasource
							mitreDatasource, err := rt.db.GetMitreDatasource(detection.IdMitreDatasource)
							if err != nil {
								// Log the error and continue without the MitreDatasource field
								ctx.Logger.WithError(err).Error("can't get mitre datasource")
							} else {
								// convert the mitre datasource to a frontend mitre datasource
								var frontendMitreDatasource MitreDatasource
								frontendMitreDatasource.FromDatabase(mitreDatasource)
								frontendMitigation.MitreDetection = frontendMitreDatasource
							}
						}
					}

					frontendTechniques[idx].ReportMitigations = []ReportMitigation{frontendMitigation}
				}
			}
			frontendTechniques[idx].MitreTechnique = frontendTechnique
		}

		frontendReports[idx].ReportTechniques = frontendTechniques
	}

	// Attach the parent technique if technique is a sub-technique
	for idx := range frontendReports {
		for idx2 := range frontendReports[idx].ReportTechniques {
			if frontendReports[idx].ReportTechniques[idx2].IsSubtechnique {
				// get first five characters of technique name
				techniqueName := frontendReports[idx].ReportTechniques[idx2].MitreTechnique.TechniqueId
				techniqueName = strings.Split(techniqueName, ".")[0]

				// get parent technique from db
				parentTechnique, err := rt.db.GetMitreTechniqueByName(techniqueName)
				if err != nil {
					// Log the error and send a 500 to the user
					ctx.Logger.WithError(err).Error("can't get parent technique")
					w.WriteHeader(http.StatusInternalServerError)
					return
				}

				// Convert the parent technique to a frontend technique
				frontendParentTechnique := MitreTechnique{}
				frontendParentTechnique.FromDatabase(parentTechnique)
				ctx.Logger.Info(fmt.Sprintf("parent technique: %v", frontendParentTechnique))
				frontendReports[idx].ReportTechniques[idx2].ParentTechnique = frontendParentTechnique
			}
		}
	}
	// Send the list to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(frontendReports)
}

func (rt *_router) createReport(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Get session token from cookie
	cookie, err := r.Cookie("token")
	if err != nil {
		ctx.Logger.WithError(err).Error("unauthorized")
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	// Get user id from session token
	userId, err := rt.db.GetUserIDFromSession(cookie.Value)
	if err != nil {
		ctx.Logger.WithError(err).Error("unauthorized")
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	// Get user from user id
	user, err := rt.db.GetUser(userId)
	if err != nil {
		ctx.Logger.WithError(err).Error("Error getting the user")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Get ongoing exercitation
	exercitation, err := rt.db.GetOngoingExercitation()
	if err != nil {
		ctx.Logger.WithError(err).Error("Error getting ongoing exercitation")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	var team database.Team
	user_role, err := rt.db.GetRoleFromUserId(userId)
	if err != nil {
		ctx.Logger.WithError(err).Error("Error getting user role")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	if user_role == "admin" {
		// Admins can create reports for any team
		team, err = rt.db.GetAdminTeam()
		if err != nil {
			ctx.Logger.WithError(err).Error("Error getting team")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
	} else {
		// Get team from user id and exercitation id
		team, err = rt.db.GetTeamFromUserIdAndExercitationId(user.Id, exercitation.Id)
		if err != nil {
			// print user id and exercitation id
			ctx.Logger.WithError(err).Error("user id: ", user.Id, " exercitation id: ", exercitation.Id)
			ctx.Logger.WithError(err).Error("Error getting team")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
	}

	frontendTeam := Team{}
	frontendTeam.FromDatabase(team)

	// Parse request body
	var form struct {
		MitreTacticId  uint64 `json:"mitre_tactic_id"`
		ExercitationId uint64 `json:"exercitation_id"`
		Target         string `json:"target"`
		Comments       string `json:"comments"`
		Techniques     []struct {
			Id          uint64 `json:"id"`
			Description string `json:"description"`
		} `json:"techniques"`
		TecDetMit []struct {
			Technique  MitreTechnique  `json:"technique"`
			Detection  MitreDatasource `json:"detection"`
			Mitigation MitreMitigation `json:"mitigation"`
		}
	}
	if err := json.NewDecoder(r.Body).Decode(&form); err != nil {
		ctx.Logger.WithError(err).Error("Error parsing request body")
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	// Validate request body
	if form.ExercitationId != exercitation.Id {
		ctx.Logger.WithError(err).Error("Exercitation id mismatch")
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	if form.MitreTacticId == 0 {
		ctx.Logger.WithError(err).Error("Mitre tactic id is required")
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	if form.Target == "" {
		ctx.Logger.WithError(err).Error("Target is required")
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	// Get mitre tactic from mitre tactic id
	mitreTactic, err := rt.db.GetMitreTactic(form.MitreTacticId)
	if err != nil {
		ctx.Logger.WithError(err).Error("Error getting mitre tactic")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	// Convert mitre tactic to frontend format
	frontendMitreTactic := MitreTactic{}
	frontendMitreTactic.FromDatabase(mitreTactic)

	// Create report
	report := database.Report{
		TeamId:         team.Id,
		IssuedBy:       user.Id,
		IssuedWhen:     time.Now().Format(time.RFC3339),
		MitreTacticId:  form.MitreTacticId,
		ExercitationId: form.ExercitationId,
		Target:         form.Target,
		Comments:       form.Comments,
	}

	if team.Role == "Red" {
		report.Type = false
		report.AttackOutcome = 1
	} else {
		// blue team
		report.Type = true
		report.AttackOutcome = 0
	}

	// Insert report
	rep, err := rt.db.CreateReport(report)
	if err != nil {
		ctx.Logger.WithError(err).Error("Error inserting report")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Get report techniques from request techniques
	// check if in body there is tecdetmit
	if len(form.TecDetMit) > 0 {
		for _, td := range form.TecDetMit {
			// declare a is_subtechnique variable
			var is_subtechnique bool

			// check if the technique is a subtechnique by checking if name contains a dot
			if strings.Contains(td.Technique.Name, ".") {
				is_subtechnique = true
			} else {
				is_subtechnique = false
			}

			// Insert report technique
			if _, err := rt.db.CreateReportTechnique(rep.Id, database.ReportTechnique{
				IdReport:         rep.Id,
				IdMitreTechnique: td.Technique.Id,
				IsSubtechnique:   is_subtechnique,
				Type:             true, // blue
			}); err != nil {
				ctx.Logger.WithError(err).Error("Error inserting report technique")
				w.WriteHeader(http.StatusInternalServerError)
				return
			}

			// declare a variable for the report detection
			var r database.ReportDetection

			// Insert report detection if td.Detection.Id is defined
			if td.Detection.Id != 0 {
				if r, err = rt.db.CreateReportDetection(rep.Id, database.ReportDetection{
					IdReport:          rep.Id,
					IdMitreDatasource: td.Detection.Id,
				}); err != nil {
					ctx.Logger.WithError(err).Error("Error inserting report detection")
					w.WriteHeader(http.StatusInternalServerError)
					return
				}
			}

			// Insert report mitigation
			if td.Mitigation.Id != 0 {
				_, err := rt.db.GetMitreTechnique(td.Mitigation.Id)
				if err != nil {
					ctx.Logger.WithError(err).Error("Error getting mitre technique mitigation")
					w.WriteHeader(http.StatusInternalServerError)
					return
				}
				if r.Id != 0 {
					if _, err = rt.db.CreateReportMitigation(rep.Id, database.ReportMitigation{
						IdReport:          rep.Id,
						IdReportDetection: r.Id,
						IdMitreMitigation: td.Mitigation.Id,
					}); err != nil {
						ctx.Logger.WithError(err).Error("Error inserting report mitigation")
						w.WriteHeader(http.StatusInternalServerError)
						return
					}
				} else {
					if _, err = rt.db.CreateReportMitigation(rep.Id, database.ReportMitigation{
						IdReport:          rep.Id,
						IdReportDetection: 0,
						IdMitreMitigation: td.Mitigation.Id,
					}); err != nil {
						ctx.Logger.WithError(err).Error("Error inserting report mitigation")
						w.WriteHeader(http.StatusInternalServerError)
						return
					}
				}
			}

		}
	} else {
		for _, t := range form.Techniques {

			// Get Mitre Technique
			reptech, err := rt.db.GetMitreTechnique(t.Id)
			if err != nil {
				ctx.Logger.WithError(err).Error("Error getting mitre technique")
				w.WriteHeader(http.StatusInternalServerError)
				return
			}
			// declare a is_subtechnique variable
			var is_subtechnique bool

			// check if the technique is a subtechnique by checking if name contains a dot
			if strings.Contains(reptech.Name, ".") {
				is_subtechnique = true
			} else {
				is_subtechnique = false
			}

			// Insert report technique
			if _, err := rt.db.CreateReportTechnique(rep.Id, database.ReportTechnique{
				IdReport:         t.Id,
				IdMitreTechnique: reptech.Id,
				IsSubtechnique:   is_subtechnique,
				Type:             false, // red
			}); err != nil {
				ctx.Logger.WithError(err).Error("Error inserting report technique")
				w.WriteHeader(http.StatusInternalServerError)
				return
			}
		}
	}

	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode("ok")
}
