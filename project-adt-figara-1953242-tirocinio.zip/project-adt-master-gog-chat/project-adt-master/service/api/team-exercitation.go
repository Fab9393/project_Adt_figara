package api

import (
	"encoding/json"
	"errors"
	"net/http"
	"strconv"

	"github.com/dag7dev/project-adt/service/api/reqcontext"
	"github.com/dag7dev/project-adt/service/database"
	"github.com/julienschmidt/httprouter"
)

func (rt *_router) listTeamsOfExercitation(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {

	// Parse the query string exercitation id
	exercitationID, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		ctx.Logger.WithError(err).Error("exercitation does not exist")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	var teams []database.Team

	// Request an unfiltered list of teams from the DB
	teams, err = rt.db.ListTeamsOfExercitation(exercitationID)

	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't list teams")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Before sending the list to the client we need to convert it to json
	var frontendTeams = make([]Team, len(teams))
	for idx := range teams {
		frontendTeams[idx].FromDatabase(teams[idx])
	}

	// Send the list to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(frontendTeams)
}

// assign team to exercitation by url of exercitation in input and team in json
func (rt *_router) assignTeamToExercitation(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Read exercitation id from url
	exercitationID, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		ctx.Logger.WithError(err).Error("exercitation does not exist")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	teamID, err := strconv.ParseUint(ps.ByName("teamId"), 10, 64)
	if err != nil {
		ctx.Logger.WithError(err).Error("exercitation does not exist")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	_, err = rt.db.GetTeam(teamID)
	if err != nil {
		ctx.Logger.WithError(err).Error("team does not exist")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Assign team to exercitation
	err = rt.db.AssignTeamToExercitation(teamID, exercitationID)
	if err != nil {
		ctx.Logger.WithError(err).Error("cant assign team to exercitation")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
}

func (rt *_router) removeTeamFromExercitation(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Read exercitation id from url
	exercitationID, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		ctx.Logger.WithError(err).Error("exercitation does not exist")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Get team id from url
	teamID, err := strconv.ParseUint(ps.ByName("teamId"), 10, 64)
	if err != nil {
		ctx.Logger.WithError(err).Error("team does not exist")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Remove team from exercitation
	err = rt.db.RemoveTeamFromExercitation(teamID, exercitationID)
	if errors.Is(err, database.ErrTeamNotInExercitation) {
		ctx.Logger.WithError(err).Error("team is not in this exercitation")
		w.WriteHeader(http.StatusBadRequest)
		return
	} else if err != nil {
		ctx.Logger.WithError(err).Error("cant remove team from exercitation")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusNoContent)
}
