
package api

import (
	"net/http"
	"github.com/julienschmidt/httprouter"
)



//@TODO: requireAuth middleware should redirect to login page
//@TODO: add v1 to the baseurl

// Handler returns an instance of httprouter.Router that handle APIs registered here
func (rt *_router) Handler() http.Handler {

	//chat_messages rotues
	rt.router.GET("/messages/:exercise_id", rt.getMessagesByExerciseID)
	rt.router.POST("/messages", rt.postMessage)

	// Register routes
	rt.router.POST("/login", rt.wrap(rt.login))

	// users routes
	// ------------
	rt.router.GET("/users", rt.wrap(rt.listUsers))
	rt.router.GET("/users/:id", rt.wrap(rt.getUser))
	rt.router.POST("/users", rt.wrap(rt.createUser))
	rt.router.DELETE("/users/:id", rt.wrap(rt.deleteUser))
	
	rt.router.GET("/my/role", rt.wrap(rt.getMyRoleFromToken))
	rt.router.GET("/my/", rt.wrap(rt.getUserFromToken))

	// teams
	// -----
	rt.router.GET("/teams", rt.wrap(rt.listTeams))
	rt.router.POST("/teams", rt.wrap(rt.createTeam))
	rt.router.GET("/teams/:id", rt.wrap(rt.getTeam))
	rt.router.DELETE("/teams/:id", rt.wrap(rt.deleteTeam))

	// (team members)
	// --------------
	rt.router.GET("/teams/:id/members", rt.wrap(rt.listTeamMembers))            // given a team id get all members of the team
	rt.router.POST("/teams/:id/members/:userId", rt.wrap(rt.createTeamMember))  // given a team id create a new TeamMember
	rt.router.DELETE("/teams/:id/members/:idMem", rt.wrap(rt.deleteTeamMember)) // given a team id and a user id delete the user from the team
	rt.router.GET("/api/user/:id/teamrole", rt.getTeamRoleFromUserId)





	// exercitations
	// -------------
	rt.router.GET("/exercitations", rt.wrap(rt.listExercitations))	 
	rt.router.GET("/ongoing", rt.wrap(rt.getOngoingExercitation))
	rt.router.POST("/exercitations", rt.wrap(rt.createExercitation))
	rt.router.DELETE("/exercitations/:id", rt.wrap(rt.deleteExercitation))

	rt.router.GET("/exercitations/:id", rt.wrap(rt.getExercitation))
	rt.router.GET("/exercitations/:id/reports", rt.wrap(rt.listReports))
	rt.router.POST("/exercitations/:id/reports", rt.wrap(rt.createReport))	
	rt.router.GET("/exercitations/:id/results", rt.wrap(rt.getResults))

	//ideal-path <--> exercitations
	// Configura le rotte per gestire le richieste relative agli idealPaths
	rt.router.GET("/ideal-path/:id", rt.wrap(rt.getIdealPathsForExercitation))
	rt.router.POST("/exercitations/:id/idealpath", rt.wrap(rt.addIdealPathToExercitation))


	// team <--> exercitation
	rt.router.GET("/exercitations/:id/teams", rt.wrap(rt.listTeamsOfExercitation))
	rt.router.POST("/exercitations/:id/teams/:teamId", rt.wrap(rt.assignTeamToExercitation))
	rt.router.DELETE("/exercitations/:id/teams/:teamId", rt.wrap(rt.removeTeamFromExercitation))

	// Special routes
	rt.router.GET("/liveness", rt.liveness)
	//rt.router.GET("/google". rt.authGoogle)

	// Search routes
	rt.router.GET("/search", rt.wrap(rt.search))

	// Mitre routes
	rt.router.GET("/mitre/tactics", rt.wrap(rt.listMitreTactics))
	rt.router.GET("/mitre/techniques", rt.wrap(rt.listMitreTechniques))
	rt.router.GET("/mitre/datasources", rt.wrap(rt.listMitreDatasources))
	rt.router.GET("/mitre/mitigations", rt.wrap(rt.listMitreMitigations))

	// rt.router.GET("/mitre/techniques/:id", rt.wrap(rt.getMitreTechnique))
	rt.router.GET("/mitre/techniques/all", rt.wrap(rt.getAllMitreTechniques))

	return rt.router 
}

func requireAuth(h httprouter.Handle) httprouter.Handle {
	return func(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
        // Check if user is authenticated
        authenticated := false
		
        // Check if the user has a valid session
        session, err := r.Cookie("token")
        if err == nil && session.Value != "" {
            // Check if the session is valid
            authenticated = true
        }

        if !authenticated {
            // User is not authenticated
            http.Redirect(w, r, "/login", http.StatusTemporaryRedirect)
            return
        }

        // User is authenticated, call the next middleware function
		h(w, r, ps)
    }
}
