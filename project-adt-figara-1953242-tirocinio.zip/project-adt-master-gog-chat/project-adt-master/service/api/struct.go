package api

import (
	"strings"

	"github.com/dag7dev/project-adt/service/database"
)

const (
	UserStatusGood   string = "good"
	UserStatusFaulty string = "faulty"
)

// struct represent an object user in every data exchange with the external world via REST API. JSON tags have been
// added to the struct to conform to the OpenAPI specifications regarding JSON key names.
// Note: there is a similar struct in the database package.
type User struct {
	Id        uint64 `json:"id"`
	FirstName string `json:"first_name"`
	LastName  string `json:"last_name"`
	Nickname  string `json:"nickname"`
	Email     string `json:"email"`
	Password  string `json:"password,omitempty"`
	Role      string `json:"role,omitempty"`
}

type Exercitation struct {
	Id          uint64       `json:"id"`
	Name        string       `json:"name"`
	Start        string       `json:"start_date"`
	End        string       `json:"end_date"`
	Teams       []Team       `json:"teams"`
	RedReports	[]Report       `json:"red_reports,omitempty"`
	BlueReports 	[]Report       `json:"blue_reports,omitempty"`
}

type Report struct {
	Id                 uint64 `json:"id"` // internal Id
	TeamId             uint64 `json:"team_id"`
	Team					Team `json:"team,omitempty"`
	IssuedBy				uint64 `json:"issued_by,omitempty"`
	IssuedWhen         string `json:"issued_when"` // timestamp
	ExercitationId		uint64 `json:"exercitation_id,omitempty"`
	Target				string `json:"target"`
	MitreTacticId		uint64 `json:"mitre_tactic_id,omitempty"`
	MitreTactic 					MitreTactic `json:"tactic,omitempty"`
	Author				User `json:"author,omitempty"`
	ReportTechniques		[]ReportTechnique `json:"techniques,omitempty"`
	AttackOutcome		uint64	`json:"attack_outcome,omitempty"`	// 1 = ongoing, 2 = success, 3 = fail, 0 in caso di blue report
	Comments           string `json:"comments"`
	Type 				bool `json:"type"` // false = red, true = blue
}

// tecniche associate a report
type ReportTechnique struct {
	IdReport         uint64 	`json:"id_report"`
	IdMitreTechnique uint64 	`json:"id_mitre_technique"`
	MitreTechnique	 MitreTechnique `json:"mitre_technique"`
	IsSubtechnique	 bool 	`json:"is_subtechnique"`
	ParentTechnique	 MitreTechnique `json:"parent_technique,omitempty"`
	Type				bool 	`json:"type"` // false = red, true = blue

	ReportDetections		[]ReportDetection `json:"detections,omitempty"`
	ReportMitigations		[]ReportMitigation `json:"mitigations,omitempty"`
}

// detection e mitigation sono associate per forza a ReportTechnique quando blue
type ReportDetection struct {
	Id 					uint64 	`json:"id"`
	IdReport 				uint64 	`json:"id_report"`
	IdMitreDatasource    	uint64 	`json:"id_mitre_datasource"`

	MitreDatasource		MitreDatasource `json:"mitre_datasource"`
}

type ReportMitigation struct {
	Id 					uint64 	`json:"id,omitempty"`
	IdReport 				uint64 	`json:"id_report"`
	IdReportDetection 		uint64 	`json:"id_report_detection"`
	IdMitreMitigation 		uint64 	`json:"id_mitre_mitigation"`

	MitreDetection		MitreDatasource `json:"mitre_datasource"`
	MitreMitigation		MitreMitigation `json:"mitre_mitigation"`
}


type Team struct {
	Id      uint64 `json:"id"`
	Name    string `json:"name"`
	Role    string `json:"role"`
	Members []User `json:"members,omitempty"`
}

type TeamMember struct {
	TeamId uint64 `json:"team_id"`
	UserId uint64 `json:"user_id"`
}


/* FROM MITRE DB */
type MitreTactic struct {
	Id          uint64		`json:"id"`
	Tactic        string	`json:"tactic"`
}

type MitreTechnique struct {
	Id          uint64 			`json:"id"`
	TechniqueId string 			`json:"technique_id"`
	Type	string 				`json:"type"`
	Name        string 			`json:"name"`
	Description string 			`json:"description"`
	Created    string 			`json:"created"`
	Modified   string 			`json:"modified"`
	MitreTactics []MitreTactic 	`json:"tactics,omitempty"`
	MitreSubtechniques []MitreTechnique 	`json:"subtechniques,omitempty"`
}

type MitreDatasource struct {
	Id 		uint64 	`json:"id"`
	MitreTechniqueId 		uint64 `json:"mitre_technique_id"`
	Name        string `json:"name"`
	Description string `json:"description"`
}

type MitreMitigation struct {
	Id          uint64 `json:"id"`
	TechniqueId string `json:"technique_id"`
	Name        string `json:"name"`
	Description string `json:"description"`
}


// Function to convert MitreTactic from database to API
func (t *MitreTactic) FromDatabase(dbMitreTactic database.MitreTactic) {
	t.Id = dbMitreTactic.Id
	t.Tactic = dbMitreTactic.Tactic
}

// Function to convert MitreTactic from API to database
func (t *MitreTactic) ToDatabase() database.MitreTactic {
	return database.MitreTactic{
		Id:     t.Id,
		Tactic: t.Tactic,
	}
}

// Function to convert MitreTechnique from database to API
func (t *MitreTechnique) FromDatabase(dbMitreTechnique database.MitreTechnique) {
	t.Id = dbMitreTechnique.Id
	t.TechniqueId = dbMitreTechnique.TechniqueId
	t.Type = dbMitreTechnique.Type
	t.Name = dbMitreTechnique.Name
	t.Description = dbMitreTechnique.Description
	t.Created = dbMitreTechnique.Created
	t.Modified = dbMitreTechnique.Modified
}

// Function to convert MitreTechnique from API to database
func (t *MitreTechnique) ToDatabase() database.MitreTechnique {
	return database.MitreTechnique{
		Id:          t.Id,
		TechniqueId: t.TechniqueId,
		Type:        t.Type,
		Name:        t.Name,
		Description: t.Description,
		Created:     t.Created,
		Modified:    t.Modified,
	}
}

// Function to convert MitreDatasource from database to API
func (d *MitreDatasource) FromDatabase(dbMitreDatasource database.MitreDatasource) {
	d.Id = dbMitreDatasource.Id
	//d.MitreTechniqueId = dbMitreDatasource.MitreTechniqueId
	d.Name = dbMitreDatasource.Name
	d.Description = dbMitreDatasource.Description
}

// Function to convert MitreDatasource from API to database
func (d *MitreDatasource) ToDatabase() database.MitreDatasource {
	return database.MitreDatasource{
		Id:                d.Id,
		//MitreTechniqueId:  d.MitreTechniqueId,
		Name:              d.Name,
		Description:       d.Description,
	}
}

// Function to convert MitreMitigation from database to API
func (m *MitreMitigation) FromDatabase(dbMitreMitigation database.MitreMitigation) {
	m.Id = dbMitreMitigation.Id
	m.TechniqueId = dbMitreMitigation.TechniqueId
	m.Name = dbMitreMitigation.Name
	m.Description = dbMitreMitigation.Description
}

// Function to convert MitreMitigation from API to database
func (m *MitreMitigation) ToDatabase() database.MitreMitigation {
	return database.MitreMitigation{
		Id:          m.Id,
		TechniqueId: m.TechniqueId,
		Name:        m.Name,
		Description: m.Description,
	}
}

// FromDatabase populates the struct with data from the database, overwriting all values.
// You might think this is code duplication, which is correct. However, it's "good" code duplication because it allows
// us to uncouple the database and API packages.
// Suppose we were using the "database.User" struct inside the API package; in that case, we were forced to conform
// either the API specifications to the database package or the other way around. However, very often, the database
// structure is different from the structure of the REST API.
// Also, in this way the database package is freely usable by other packages without the assumption that structs from
// the database should somehow be JSON-serializable (or, in general, serializable).

// fromdatabase and todatabase for report


func (p *User) FromDatabase(user database.User) {
	p.Id = user.Id
	p.FirstName = user.FirstName
	p.LastName = user.LastName
	p.Nickname = user.Nickname
	p.Email = user.Email
	p.Role = user.Role
}

func (t *Team) FromDatabase(team database.Team) {
	t.Id = team.Id
	t.Name = team.Name
	t.Role = team.Role
}

func (tm *TeamMember) FromDatabase(teamMember database.TeamMember) {
	tm.TeamId = teamMember.TeamId
	tm.UserId = teamMember.UserId
}

func (e *Exercitation) FromDatabase(exercitation database.Exercitation) {
	e.Id = exercitation.Id
	e.Name = exercitation.Name
	e.Start = exercitation.Start
	e.End = exercitation.End

	e.Teams = make([]Team, 0)
	for _, team := range exercitation.Teams {
		t := Team{}
		t.FromDatabase(team)
		e.Teams = append(e.Teams, t)
	}
}


// ToDatabase returns the user in a database-compatible representation
func (p *User) ToDatabase() database.User {
	return database.User{
		Id:        p.Id,
		FirstName: p.FirstName,
		LastName:  p.LastName,
		Nickname:  p.Nickname,
		Email:     p.Email,
		Password:  p.Password,
		Role:      p.Role,

	}
}

func (t *Team) ToDatabase() database.Team {
	return database.Team{
		Id:   t.Id,
		Name: strings.Title(t.Name),
		Role: strings.Title(t.Role),
	}
}

func (tm *TeamMember) ToDatabase() database.TeamMember {
	return database.TeamMember{
		TeamId: tm.TeamId,
		UserId: tm.UserId,
	}
}

func (e *Exercitation) ToDatabase() database.Exercitation {
	return database.Exercitation{
		Id:        e.Id,
		Name:      e.Name,
		Start:     e.Start,
		End:       e.End,
	}
}

func (r *Report) FromDatabase(dbreport database.Report) {
	r.Id = dbreport.Id
	r.TeamId = dbreport.TeamId
	r.MitreTacticId = dbreport.MitreTacticId
	r.ExercitationId = dbreport.ExercitationId
	r.IssuedBy = dbreport.IssuedBy
	r.IssuedWhen = dbreport.IssuedWhen
	r.Target = dbreport.Target
	r.AttackOutcome = dbreport.AttackOutcome
	r.Comments = dbreport.Comments
	r.Type = dbreport.Type
}

func (r *Report) ToDatabase() database.Report {
	return database.Report{
		Id:                 r.Id,
		TeamId:             r.TeamId,
		MitreTacticId:      r.MitreTacticId,
		ExercitationId:     r.ExercitationId,
		IssuedBy:           r.IssuedBy,
		IssuedWhen:         r.IssuedWhen,
		Target:             r.Target,
		AttackOutcome:      r.AttackOutcome,
		Comments:           r.Comments,
		Type:               r.Type,
	}
}


func (rt *ReportTechnique) FromDatabase(dbreporttechnique database.ReportTechnique) {
	rt.IdReport = dbreporttechnique.IdReport
	rt.IdMitreTechnique = dbreporttechnique.IdMitreTechnique
	rt.IsSubtechnique = dbreporttechnique.IsSubtechnique
	rt.Type = dbreporttechnique.Type
}

func (rt *ReportTechnique) ToDatabase() database.ReportTechnique {
	return database.ReportTechnique {
		IdReport:         rt.IdReport,
		IdMitreTechnique: rt.IdMitreTechnique,
		IsSubtechnique:   rt.IsSubtechnique,
		Type:             rt.Type,
	}

}

func (rd *ReportDetection) FromDatabase(dbrd database.ReportDetection) {
	rd.Id = dbrd.Id
	rd.IdReport = dbrd.IdReport
	rd.IdMitreDatasource = dbrd.IdMitreDatasource
}

func (rd *ReportDetection) ToDatabase() database.ReportDetection {
	return database.ReportDetection{
		Id:                 rd.Id,
		IdReport:           rd.IdReport,
		IdMitreDatasource:  rd.IdMitreDatasource,
	}
}

func (rm *ReportMitigation) FromDatabase(dbrm database.ReportMitigation) {
	rm.Id = dbrm.Id
	rm.IdReport = dbrm.IdReport
	rm.IdReportDetection = dbrm.IdReportDetection
	rm.IdMitreMitigation = dbrm.IdMitreMitigation

}

func (rm *ReportMitigation) ToDatabase() database.ReportMitigation {
	return database.ReportMitigation{
		Id:                  rm.Id,
		IdReport:            rm.IdReport,
		IdReportDetection:   rm.IdReportDetection,
		IdMitreMitigation:   rm.IdMitreMitigation,
	}
}


// IsValid checks the validity of the content. In particular, coordinates should be in their range of validity, and the
// status should be either UserStatusGood or UserStatusFaulty. Note that the ID is not checked, as users
// read from requests have zero IDs as the user won't send us the ID in that way.
func (p *User) IsValid() bool {
	return true
	// @TODO: change this
}

func (t *Team) IsValid() bool {
	return true
	// @TODO: change this
}

func (tm *TeamMember) IsValid() bool {
	return true
}

func (e *Exercitation) IsValid() bool {
	return true
}
