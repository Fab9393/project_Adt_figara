package api

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/dag7dev/project-adt/service/api/reqcontext"
	"github.com/julienschmidt/httprouter"
)

func (rt *_router) listTeamMembers(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Get team id from URL
	teamID, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		ctx.Logger.WithError(err).Error("team does not exist")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Get team members from database
	tms, err := rt.db.ListTeamMembers(teamID)
	if err != nil {
		ctx.Logger.WithError(err).Error("cant list team members")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	
	// Before sending the list to the client we need to convert it to json
	var frontendTeamMembers = make([]TeamMember, len(tms))
	for idx := range tms {
		frontendTeamMembers[idx].FromDatabase(tms[idx])
	}

	// Write response
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	_ = json.NewEncoder(w).Encode(frontendTeamMembers)
}

func (rt *_router) createTeamMember(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Get team id from URL
	teamID, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		ctx.Logger.WithError(err).Error("Failed to parse id")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	_, err = rt.db.GetTeam(teamID)
	if err != nil {
		ctx.Logger.WithError(err).Error("team does not exist")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Get user id from url
	userID, err := strconv.ParseUint(ps.ByName("userId"), 10, 64)
	if err != nil {
		ctx.Logger.WithError(err).Error("Failed to parse userId")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	// Check if user exists
	_, err = rt.db.GetUser(userID)
	if err != nil {
		ctx.Logger.WithError(err).Error("user does not exist")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Add team member to database
	tms, err := rt.db.CreateTeamMember(teamID, userID)
	if err != nil {
		ctx.Logger.WithError(err).Error("cant add team member")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	var teamMembers TeamMember
	teamMembers.FromDatabase(tms)

	// Write response
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	_ = json.NewEncoder(w).Encode(teamMembers)
}

func (rt *_router) deleteTeamMember(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Get team id from URL
	teamID, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		ctx.Logger.WithError(err).Error("Failed to parse id")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	_, err = rt.db.GetTeam(teamID)
	if err != nil {
		ctx.Logger.WithError(err).Error("team does not exist")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Get user id from URL
	userID, err := strconv.ParseUint(ps.ByName("idMem"), 10, 64)
	if err != nil {
		ctx.Logger.WithError(err).Error("Failed to parse userId")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}
	
	_, err = rt.db.GetUser(userID)
	if err != nil {
		ctx.Logger.WithError(err).Error("user does not exist")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Delete team member from database
	err = rt.db.DeleteTeamMember(teamID, userID)
	if err != nil {
		ctx.Logger.WithError(err).Error("cant delete team member")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Write response
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
}
