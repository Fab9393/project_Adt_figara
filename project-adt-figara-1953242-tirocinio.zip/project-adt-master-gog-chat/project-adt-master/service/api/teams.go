package api

import (
	"encoding/json"
	"errors"
	"net/http"
	"strconv"

	"github.com/dag7dev/project-adt/service/api/reqcontext"
	"github.com/dag7dev/project-adt/service/database"
	"github.com/julienschmidt/httprouter"
)

// create a new team
func (rt *_router) createTeam(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// Read the new content for the team from the request body.
	var team Team
	err := json.NewDecoder(r.Body).Decode(&team)
	if err != nil {
		// The body was not a parseable JSON, reject it
		w.WriteHeader(http.StatusBadRequest)
		return
	} else if !team.IsValid() {
		// Here we validated the team structure content, and we
		// discovered that the team data are not valid.
		// Note: the IsValid() function skips the ID check (see below).
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	// Create the team: new instance of the team with the
	// same information, plus the ID.
	dbteam, err := rt.db.CreateTeam(team.ToDatabase())
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't create the team")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Here we can re-use `team` as FromDatabase is overwriting every variabile in the structure.
	team.FromDatabase(dbteam)

	// Send the output to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(team)
}

// get a team
func (rt *_router) getTeam(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {

	// Parse the query string exercitation id.
	var err error
	var team database.Team
	id, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		// The ID was not a valid number, reject it
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	// Request an unfiltered list of teams from the DB
	team, err = rt.db.GetTeam(id)

	if err != nil {
		// Team not found.
		ctx.Logger.WithError(err).Error("can't list team")
		w.WriteHeader(http.StatusNotFound)
		return
	}

	// Parse real object from db
	var full_team Team
	full_team.FromDatabase(team)

	// query the database and get all team members related to that team
	var dbteammembers []database.TeamMember
	dbteammembers, err = rt.db.ListTeamMembers(id)
	if err != nil {
		// In this case, we have an error on our side. Log the error (so we can be notified) and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't list team members")
		w.WriteHeader(http.StatusNotFound)
		return
	}

	for _, member := range dbteammembers {
		ctx.Logger.Info("member: ", member.UserId)

		// query the database and get all team members related to that team
		var dbuser database.User
		dbuser, err = rt.db.GetUser(member.UserId)
		if err != nil {
			// In this case, we have an error on our side. Log the error (so we can be notified) and send a 500 to the user
			ctx.Logger.WithError(err).Error("can't list team members")
			w.WriteHeader(http.StatusNotFound)
			return
		}

		// Parse real object from db
		var full_user User
		full_user.FromDatabase(dbuser)

		full_team.Members = append(full_team.Members, full_user)
	}

	// send the team to the user
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(full_team)
}

// delete a team
func (rt *_router) deleteTeam(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	// The Profile ID in the path is a 64-bit unsigned integer. Let's parse it.
	id, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		// The ID was not a valid number, reject it
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	err = rt.db.DeleteTeam(id)
	if errors.Is(err, database.ErrTeamDoesNotExist) {
		// The profile (indicated by `id`) does not exist, reject the action indicating an error on the client side.
		w.WriteHeader(http.StatusNotFound)
		return
	} else if err != nil {
		// Log the error and send a 500 to the user
		// Note (2): we are adding the error and an additional field (`id`) to the log entry, so that we will receive
		// the identifier of the profile that triggered the error.
		ctx.Logger.WithError(err).WithField("id", id).Error("can't delete this team")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusNoContent)
}

// get all teams
func (rt *_router) listTeams(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {

	var err error
	var teams []database.Team

	// Request an unfiltered list of teams from the DB
	teams, err = rt.db.ListTeams()

	if err != nil {
		// In this case, we have an error on our side. Log the error (so we can be notified) and send a 500 to the user
		// Note: we are using the "logger" inside the "ctx" (context) because the scope of this issue is the request.
		ctx.Logger.WithError(err).Error("can't list teams")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Before sending the list to the client we need to convert it to json
	var frontendTeams = make([]Team, len(teams))
	for idx := range teams {
		frontendTeams[idx].FromDatabase(teams[idx])
	}

	// Send the list to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(frontendTeams)
}
