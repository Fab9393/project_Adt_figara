package api

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/dag7dev/project-adt/service/api/reqcontext"
	"github.com/dag7dev/project-adt/service/database"
	"github.com/julienschmidt/httprouter"
)

func (rt *_router) listMitreTechniques(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	var err error
	var dbtechniques []database.MitreTechnique

	// Request an unfiltered list of Datasources from the DB
	dbtechniques, err = rt.db.ListMitreTechniques()

	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't list Techniques")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Before sending the list to the client we need to convert it to json
	var frontendTechniques = make([]MitreTechnique, len(dbtechniques))
	for idx := range dbtechniques {
		frontendTechniques[idx].FromDatabase(dbtechniques[idx])
	}

	// Foreach technique add the subtechniques
	for idx := range frontendTechniques {
		var dbSubtechniques []database.MitreTechnique
		dbSubtechniques, err = rt.db.ListMitreSubtechniques(frontendTechniques[idx].Id)
		if err != nil {
			// Log the error and send a 500 to the user
			ctx.Logger.WithError(err).Error("can't list Subtechniques")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}

		var frontendSubtechniques = make([]MitreTechnique, len(dbSubtechniques))
		for idx := range dbSubtechniques {
			frontendSubtechniques[idx].FromDatabase(dbSubtechniques[idx])
		}
		frontendTechniques[idx].MitreSubtechniques = frontendSubtechniques
	}

	// Send the list to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(frontendTechniques)
}

func (rt *_router) listMitreDatasources(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	var err error
	var dbDatasources []database.MitreDatasource

	// Request an unfiltered list of Datasources from the DB
	dbDatasources, err = rt.db.ListMitreDatasources()

	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't list Datasources")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Before sending the list to the client we need to convert it to json
	var frontendTechniques = make([]MitreDatasource, len(dbDatasources))
	for idx := range dbDatasources {
		frontendTechniques[idx].FromDatabase(dbDatasources[idx])
	}

	// Send the list to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(frontendTechniques)
}

// list  mitigations
func (rt *_router) listMitreMitigations(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	var err error
	var dbmitigations []database.MitreMitigation

	// Request an unfiltered list of Datasources from the DB
	dbmitigations, err = rt.db.ListMitreMitigations()

	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't list Mitigations")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Before sending the list to the client we need to convert it to json
	var frontendMitigations = make([]MitreMitigation, len(dbmitigations))
	for idx := range dbmitigations {
		frontendMitigations[idx].FromDatabase(dbmitigations[idx])
	}

	// Send the list to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(frontendMitigations)
}

// list tactics
func (rt *_router) listMitreTactics(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	var err error
	var dbtactics []database.MitreTactic

	// Request an unfiltered list of Datasources from the DB
	dbtactics, err = rt.db.ListMitreTactics()

	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't list Tactics")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Before sending the list to the client we need to convert it to json
	var frontendTactics = make([]MitreTactic, len(dbtactics))
	for idx := range dbtactics {
		frontendTactics[idx].FromDatabase(dbtactics[idx])
	}

	// Send the list to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(frontendTactics)
}


// get mitre technique
func (rt *_router) getMitreTechnique(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	var err error
	var dbtechnique database.MitreTechnique

	// get id from url and parse into an uint64
	id, err := strconv.ParseUint(ps.ByName("id"), 10, 64)
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't parse id")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Request an unfiltered list of Datasources from the DB
	dbtechnique, err = rt.db.GetMitreTechnique(id)

	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't get Technique")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Before sending the list to the client we need to convert it to json
	var frontendTechnique MitreTechnique
	frontendTechnique.FromDatabase(dbtechnique)

	var dbSubtechniques []database.MitreTechnique
	dbSubtechniques, err = rt.db.ListMitreSubtechniques(frontendTechnique.Id)
	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't list Subtechniques")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	var frontendSubtechniques = make([]MitreTechnique, len(dbSubtechniques))
	for idx := range dbSubtechniques {
		frontendSubtechniques[idx].FromDatabase(dbSubtechniques[idx])
	}
	frontendTechnique.MitreSubtechniques = frontendSubtechniques


	// Send the list to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(frontendTechnique)
}


func (rt *_router) getAllMitreTechniques(w http.ResponseWriter, r *http.Request, ps httprouter.Params, ctx reqcontext.RequestContext) {
	var err error
	var dbtechniques []database.MitreTechnique

	// Request an unfiltered list of Datasources from the DB
	dbtechniques, err = rt.db.ListAllMitreTechniques()

	if err != nil {
		// Log the error and send a 500 to the user
		ctx.Logger.WithError(err).Error("can't list Techniques")
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	// Before sending the list to the client we need to convert it to json
	var frontendTechniques = make([]MitreTechnique, len(dbtechniques))
	for idx := range dbtechniques {
		frontendTechniques[idx].FromDatabase(dbtechniques[idx])
	}

	// Foreach technique add the subtechniques
	for idx := range frontendTechniques {
		var dbSubtechniques []database.MitreTechnique
		dbSubtechniques, err = rt.db.ListMitreSubtechniques(frontendTechniques[idx].Id)
		if err != nil {
			// Log the error and send a 500 to the user
			ctx.Logger.WithError(err).Error("can't list Subtechniques")
			w.WriteHeader(http.StatusInternalServerError)
			return
		}

		var frontendSubtechniques = make([]MitreTechnique, len(dbSubtechniques))
		for idx := range dbSubtechniques {
			frontendSubtechniques[idx].FromDatabase(dbSubtechniques[idx])
		}
		frontendTechniques[idx].MitreSubtechniques = frontendSubtechniques
	}

	// Send the list to the user.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(frontendTechniques)
}