const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const keys = require('./keys');

const pool = new Pool({
  user: 'postgres',
  host: 'db',
  database: 'project-adt',
  password: 'postgres',
  port: 5432,
});

passport.use(
  new GoogleStrategy({
    callbackURL: 'http://localhost:3002/auth/google/redirect',
    clientID: keys.google.clientID,
    clientSecret: keys.google.clientSecret,
  }, async (accessToken, refreshToken, profile, done) => {
    try {
      console.log('GoogleStrategy: profilo ricevuto:', profile);
      const email = profile.emails[0].value;
      
      let userResult = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
      let user = userResult.rows[0];

      if (!user) {
        console.log('Utente non trovato, creazione di un nuovo utente');
        const newUser = {
          firstName: profile.name.givenName,
          lastName: profile.name.familyName,
          nickname: profile.displayName,
          email: email,
          password: 'password',
          role: 'blue',
        };

        let insertUserResult = await pool.query(
          'INSERT INTO users (first_name, last_name, nickname, email, password, role) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
          [newUser.firstName, newUser.lastName, newUser.nickname, newUser.email, newUser.password, newUser.role]
        );
        user = insertUserResult.rows[0];

        let insertTeamMemberResult = await pool.query(
          'INSERT INTO team_members (team_id, user_id) VALUES ($1, $2)',
          [2, user.id]
        );
      }

      console.log('Utente trovato o creato:', user);

      // Genera un token JWT
      const token = jwt.sign({ id: user.id, name: user.nickname }, 'your_jwt_secret_key', { expiresIn: '1d' });
      console.log('Token JWT generato:', token);
      profile.token = token;

      done(null, profile);
    } catch (err) {
      console.error('Errore nella gestione dell\'utente Google:', err);
      done(err, null);
    }
  })
);

passport.serializeUser((user, done) => {
  console.log('Serializzazione utente:', user);
  done(null, user);
});

passport.deserializeUser((obj, done) => {
  console.log('Deserializzazione utente:', obj);
  done(null, obj);
});
