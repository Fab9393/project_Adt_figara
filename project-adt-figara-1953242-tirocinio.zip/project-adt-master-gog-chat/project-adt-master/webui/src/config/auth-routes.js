const router = require('express').Router();
const passport = require('passport');
const jwt = require('jsonwebtoken');

// Rotta per l'autenticazione con Google
router.get('/auth/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

// Rotta di callback per Google
router.get('/auth/google/redirect', passport.authenticate('google'), (req, res) => {
  // Crea token JWT con flag isGoogleAuth
  const token = jwt.sign(
    { id: req.user.id, name: req.user.displayName, role: 'user', isGoogleAuth: true },
    'your_jwt_secret_key',
    { expiresIn: '24h' }
  );

  // Imposta il cookie del token
  res.cookie('token', token, { httpOnly: false, secure: false, sameSite: 'none' });

  // Reindirizza all'app principale
  res.redirect('http://localhost:5173/home'); // URL dell'app principale
});

// Rotta per ottenere i dati dell'utente autenticato
router.get('/my', (req, res) => {
  const token = req.cookies.token;
  if (!token) {
    return res.status(401).json({ message: 'Accesso negato' });
  }
  try {
    const verified = jwt.verify(token, 'your_jwt_secret_key');
    res.json(verified);
  } catch (err) {
    res.status(400).json({ message: 'Token non valido' });
  }
});

// Rotta per ottenere il ruolo dell'utente autenticato
router.get('/my/role', (req, res) => {
  const token = req.cookies.token;
  if (!token) {
    return res.status(401).json({ message: 'Accesso negato' });
  }
  try {
    const verified = jwt.verify(token, 'your_jwt_secret_key');
    res.json({ role: verified.role });
  } catch (err) {
    res.status(400).json({ message: 'Token non valido' });
  }
});

module.exports = router;
