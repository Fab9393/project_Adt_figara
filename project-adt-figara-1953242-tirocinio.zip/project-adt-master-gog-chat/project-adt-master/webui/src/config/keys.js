// add to .gitignore
module.exports = {
    google: {
        clientID: '857281246700-a8mhuaqijus0d97rr61sc7gungijmutq.apps.googleusercontent.com',
        clientSecret: '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'
    }
}