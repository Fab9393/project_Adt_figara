import {
	createRouter,
	createWebHistory
} from 'vue-router'

// views in view folder
import HomeView from '../views/HomeView.vue'
import ExercitationView from '../views/view/ExercitationView.vue'
import NewExercitationView from '../views/new/NewExercitationView.vue'
import UserView from '../views/view/UserView.vue'
import NewUserView from '../views/new/NewUserView.vue'
import TeamView from '../views/view/TeamView.vue'
import NewTeamView from '../views/new/NewTeamView.vue'
import EmptyRouterView from '../views/EmptyRouterView.vue'
import AttackView from '../views/view/AttackView.vue'
import NewAttackView from '../views/new/NewAttackView.vue'
import LoginView from '../views/LoginView.vue'
import ResultsView from '../views/view/ResultsView.vue'
import PastExercitations from '../views/view/PastExercitations.vue'; 
import DefenseView from '../views/view/DefenseView.vue'
import NewDefenseView from '../views/new/NewDefenseView.vue'

const router = createRouter({
	history: createWebHistory(
		import.meta.env.BASE_URL),
	routes: [{
			path: '/',
			name: 'login',
			component: LoginView
		},
		{
			path: '/home',
			name: 'home',
			component: HomeView
		},
		{
            path: '/exercitations/:id/idealpath',
            name: 'idealpath',
            component: EmptyRouterView 
        },
		{
			path: '/past-exercitations',
			name: 'past-exercitations',
			component: PastExercitations
		},

		{
			path: '/ideal-path/:id',
			name: 'viewIdealPath',
			component: PastExercitations
		},

		{
			path: '/api/user/:id/teamrole',
			name: 'teamRole',
			component: UserView
		},

		
		{
			path: '/exercitations',
			name: 'exercitations',
			component: EmptyRouterView,
			children: [{
					name: 'exercitation',
					path: '',
					component: ExercitationView
				},
				{
					path: 'new',
					name: 'new-exercitations',
					component: NewExercitationView
				},

				// attacks
				{
					path: ':id/attacks',
					name: '',
					component: AttackView
				},
				{
					path: ':id/attacks/new',
					name: 'new-attacks',
					component: NewAttackView
				},

				// Defenses
				{
					path: ':id/defenses',
					name: '',
					component: DefenseView
				},
				{
					path: ':id/defenses/new',
					name: 'new-defenses',
					component: NewDefenseView
				},

				// Results
				{
					path: ':id/results',
					name: 'results',
					component: ResultsView
				}
			]
		},
		{
			path: '/users',
			name: 'users',
			component: EmptyRouterView,
			children: [{
					name: 'user',
					path: '',
					component: UserView
				},
				{
					path: 'new',
					name: 'new-users',
					component: NewUserView
				}
			]
		},
		{
			path: '/teams',
			name: 'teams',
			component: EmptyRouterView,
			children: [{
					name: 'teams',
					path: '',
					component: TeamView
				},
				{
					path: 'new',
					name: 'new-teams',
					component: NewTeamView,
				}
			]
		},
		{
			path: '/attacks',
			name: 'attacks',
			component: EmptyRouterView,
			children: [{
				name: 'attacks',
				path: '',
				component: EmptyRouterView
			}]
		},

		{
			path: '/auth/google',
			name: 'authGoogle',
			beforeEnter() {
				window.location.href = 'http://localhost:3002/auth/google';
			}
		}
	]
})


export default router