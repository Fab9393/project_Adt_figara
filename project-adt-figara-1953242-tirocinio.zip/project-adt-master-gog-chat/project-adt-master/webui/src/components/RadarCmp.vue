<template>
  <div>
    <Radar :data="data"></Radar>
  </div>
</template>
  
<script>
import {
  Chart as ChartJS,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
} from "chart.js";
import { Radar } from "vue-chartjs";

ChartJS.register(
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend
);

export default {
  props: {
    s1: {
      type: Number,
      default: 0,
      required: true,
    },
    s2: {
      type: Number,
      default: 0,
      required: true,
    },
    s3: {
      type: Number,
      default: 0,
      required: true,
    },
    s4: {
      type: Number,
      default: 0,
      required: true,
    },
  },
  data() {
    return {
      data: {
        labels: ["Correttezza", "Difesa", "Punti Bonus Mitigation", "Tempo"],
        datasets: [
          {
            label: "Punteggi Project ADT",
            backgroundColor: "rgba(255,99,132,0.2)",
            borderColor: "rgba(255,99,132,1)",
            pointBackgroundColor: "rgba(255,99,132,1)",
            pointBorderColor: "#fff",
            pointHoverBackgroundColor: "#fff",
            pointHoverBorderColor: "rgba(255,99,132,1)",
            data: [this.s1, this.s2, this.s3, this.s4],
          },
        ],
      },
    };
  },
  watch: {
    s1: function (newVal, oldVal) {
      // do something with newVal and oldVal
      console.log(newVal)
    },
    s2: function (newVal, oldVal) {
      // do something with newVal and oldVal
    },
    s3: function (newVal, oldVal) {
      // do something with newVal and oldVal
      console.log(newVal)
    },
    s4: function (newVal, oldVal) {
      // do something with newVal and oldVal
    }
  },
  components: { Radar },
};
</script>
  