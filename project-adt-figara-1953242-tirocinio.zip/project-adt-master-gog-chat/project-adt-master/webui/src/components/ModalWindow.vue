<template>
    <div class="modal modal-overlay modal-active">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    
                    <h4 class="modal-title">
                        {{ name }}
                    </h4>
                </div>
                <div class="modal-body">
                    <slot></slot>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" @click="$emit('close')">Chiudi</button>
                    <button class="btn btn-primary" v-if="showSaveButton"  @click="$emit('save')">Salva</button>
                </div>
            </div>
        </div>
    </div>
</template>

<style>
    .modal-active {
        display: block !important;
    }

</style>

<script>
    export default {
        props: {
            name: {
                type: String,
                required: true
            },
            showSaveButton: {
                type: Boolean,
                default: true
            }
        }
    }
</script>