<template>
    <!-- create a router link from pageName from parent -->

    <div :pageName="'pageName'"> 
    <router-link :to="{ name: 'new-' + this.pageName, props: pageName }" custom >
    </router-link>

    <div v-if="(isAdmin && pageName ==='exercitations' || pageName==='teams') || (!isAdmin && pageName!=='exercitations' && pageName!=='teams')">
        <div @click="navigate" class="btn btn-sm btn-outline-primary" @keypress.enter="navigate" role="link">Create new</div>
    </div>

</div>

</template>

<script>
export default {
    data() {
        return {
            // set pageName to pageName prop, just the value
            isAdmin: false
        }
    },
    // receive pageName from parent component
    props: ['pageName'],
    created() {
        console.log("sto caricando..." + this.pageName)
        
        this.$axios.get('/my/')
            .then(response => {
                if(response.data.role === 'admin') {
                    this.isAdmin = true
                }
            })
            .catch(error => {
                console.log(error)
                this.errored = true
            })
            .finally(() => this.loading = false)
        
            console.log(this.pageName)
    
    },
    methods: {
        // navigate to the new page
        navigate() {
            this.$router.push({ name: 'new-' + this.pageName, params: { pageName: this.pageName } })
        }
    }
}
</script>