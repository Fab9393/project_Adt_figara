<template>
  <div class="container">
    <div v-if="loading">Loading...</div>
    <div v-else>
      <vue-tree style="width: 1000px; height: 600px" :dataset="richMediaData" :config="treeConfig">
        <template v-slot:node="{ node, collapsed }">
          <div class="rich-media-node" :style="{
            border: collapsed ? '2px solid grey' : '',
            backgroundColor: node.color !== undefined ? node.color : 'f7c616',
          }">
            <span style="padding: 4px 0; font-weight: bold">{{
              node.mitre_id
            }}</span>
            {{ node.name }}
            <span v-if="node.mitre_name">{{ node.mitre_name }}</span>
            <span>{{ node.at }}</span>
          </div>
        </template>
      </vue-tree>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    exercitationId: {
      type: Number,
      default: null,
    },
    exercitation: {
      type: Object,
      default: () => ({}),
    },
    reports: {
      type: Array,
      default: () => [],
    },
    showDate: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      loading: true, // add loading state
      richMediaData: null,
      treeConfig: {
        nodeWidth: 200,
        nodeHeight: 100,
        levelHeight: 300,
      },
    };
  },

  methods: {
    makeChildDet(childDet, detection, mitigation) {
      if (detection.length != 0 && mitigation.length != 0) {
        // smarmella
        childDet.push({
          name: detection.mitre_datasource.name,
          color: "green",
          children: [{
            name: mitigation.mitre_mitigation.name,
            color: "blue"
          }]
        }
        )
      }
      else {
        if (detection.length != 0) {
          childDet.push(
            {
              name: detection.mitre_datasource.name,
              color: "green",
              children: []
            }
          )
        }
        if (mitigation.length != 0) {
          childDet.push(
            {
              name: mitigation.mitre_mitigation.name,
              color: "blue"
            }
          )
        }
      }
    }
  },

  async mounted() {
    const tacticNodes = [];

    this.reports.forEach((r) => {

      // aggiungi la tactic
      // cerca in tactic nodes se esiste un elemento con id r.mitre_tactic_id
      // se non esiste aggiungi la tactic
      var ta = tacticNodes.find((t) => t.id === r.mitre_tactic_id);
      if (ta === undefined) {
        // lo aggiungo
        tacticNodes.push({
          id: r.mitre_tactic_id,
          name: r.tactic.tactic,
          children: [],
          color: "black",
        })
      }

      // ora lo trova per forza
      ta = tacticNodes.find((t) => t.id === r.mitre_tactic_id);

      // scorro le techniques
      r.techniques.forEach((t) => {
        var padre = ta.children.find((el) => el.id === t.parent_technique.id)
        var detection = []
        var mitigation = []
        if (t.detections) {
          detection = t.detections[0]
        }

        var mitigation = []
        if (t.mitigations) {
          mitigation = t.mitigations[0]
        }

        // se is_subtechnique
        if (t.is_subtechnique) {
          // se il padre non c'è
          if (padre === undefined) {
            this.makeChildDet(childDet, detection, mitigation)

            // aggiungi il nodo come padre
            ta.children.push({
              id: t.parent_technique.id,
              name: t.parent_technique.name,
              color: "red",
              children: [
                {
                  id: t.id_mitre_technique,
                  name: t.mitre_technique.name,
                  color: "red",
                  children: childDet
                }
              ]
            })
          }
          else {
            // se c'è
            var childDet = []
            this.makeChildDet(childDet, detection, mitigation)

            padre.children.push({
              // aggiungi il nodo come sottonodo al padre
              id: t.id_mitre_technique,
              name: t.mitre_technique.name,
              color: "orange  ",
              children: childDet
            })
          }
        }
        else {
          // se non è una sottotecnica
          // sto aggiungendo un padre

          // determino se figlio della detection o no
          var childDet = []
          this.makeChildDet(childDet, detection, mitigation)

          if (ta.children.find((ttt) => ttt.id === t.id_mitre_technique) === undefined) {
            ta.children.push({
              id: t.id_mitre_technique,
              name: t.mitre_technique.name,
              color: "red",
              children: childDet
            })

          }
        }
      })

      var index = tacticNodes.indexOf(ta)
      if (index !== -1) {
        tacticNodes[index] = ta;
      }
    })

    // aggiungo le tactic
    const tacticList = Object.values(tacticNodes);

    // Informazioni sull'esercitazione
    const mitreNode = {
      mitre_id: this.exercitation.name,
      mitre_name: `Iniziata: ${new Date(this.exercitation.start_date).toLocaleString("CET", {
        timeZone: "UTC",
        weekday: "long",
        year: "numeric",
        month: "numeric",
        day: "numeric",
        hour: "numeric",
        minute: "numeric",
      })}
    Termina il: ${new Date(this.exercitation.end_date).toLocaleString("it-IT", {
        timeZone: "UTC",
        year: "numeric",
        month: "numeric",
        day: "numeric",
        hour: "numeric",
        minute: "numeric",
      })}`,
      color: "black",
      children: tacticList,
    };

    this.richMediaData = mitreNode;
    this.loading = false;
  }
};
</script>
<style scoped lang="less">
.container {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.rich-media-node {
  width: auto;
  padding: 10px;
  margin: 15px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  color: white;
  background-color: #f7c616;
  border-radius: 4px;
}
</style>
