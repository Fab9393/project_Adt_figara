<template>
	<v-timeline align="start" side="end" direction="vertical">
		<v-timeline-item v-for="(item, index) in sortedItems" :key="index" :timestamp="item.timestamp"
			:dot-color="item.color">
			<!-- v-alert with white text -->
			<v-alert :color="item.type" class="text-start" style="max-width: 300px;">
				<div style="">
					<br />
					<p>
						<b v-if="item.det_description">Presunto attacco: </b>
						<b v-else>Attacchi: </b>
						<span v-html="item.title" :title="item.description"></span>
					</p>

					<p v-if="item.det_description" style="padding-top: 20px">
						<b>Detection: </b>
						<span v-html="item.det_title" :title="item.det_description"></span>
					</p>
					<p v-if="item.mit_description" style="padding-top: 20px">
						<b>Mitigation: </b>
						<span v-html="item.mit_title" :title="item.mit_description"></span>
					</p>
					<hr>
					<p><b>Target: </b>{{ item.target }}</p>
					<p style="padding-top: 20px" v-if="item.comments != ''"><b>Commento: </b>{{ item.comments }}</p>
					<p style="padding-top: 20px"><b>Data: </b>{{ new Date(item.timestamp).toLocaleString() }}</p>

				</div>
			</v-alert>

		</v-timeline-item>
	</v-timeline>
</template>
<script>
import {
	VTimeline, VTimelineItem
}
	from "vuetify/components";
export default {
	components: {
		VTimeline, VTimelineItem,
	},
	data() {
		return {
			items: [],
			allegedAttacks: {},
		};
	},
	props: {
		exercitationId: {
			type: Number,
			required: true,
		},
		role: {
			type: String,
			required: true,
		},
	},
	computed: {
		sortedItems() {
			let filteredItems = [];
			if (this.role === "red") {
				filteredItems = this.items.filter((item) => item.color === "error");
			} else if (this.role === "blue") {
				filteredItems = this.items.filter((item) => item.color === "info" || item.color === "#008080");
			} else {
				filteredItems = this.items;
			}
			return filteredItems.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
		},
	},
	created() {
		if (this.role === 'red' || this.role === 'admin') {
			this.getItemsFromAPI('red');
		}
		if (this.role === 'blue' || this.role === 'admin') {
			this.getItemsFromAPI('blue');
		}
	},
	methods: {
		getItemsFromAPI(type) {
			const url = `/exercitations/${this.exercitationId}/reports?type=${type}`
			this.$axios.get(url).then((response) => {
				const items = response.data;

				items.forEach((item) => {

					var title = ''
					var description = ''

					var det_description = ''
					var det_title = ''
					var mit_description = ''
					var mit_title = ''

					// for t in techniques
					item.techniques.forEach((t) => {
						title += t.mitre_technique.name + '<br>'
						description += t.mitre_technique.description + '\n\n'

						if (t.detections) {

							det_description += t.detections[0].mitre_datasource.description + '\n\n'
							det_title += t.detections[0].mitre_datasource.name + ' '
						}

						if (t.mitigations) {
							mit_description += t.mitigations[0].mitre_mitigation.description + '\n\n'
							mit_title += t.mitigations[0].mitre_mitigation.name + ' '
						}
					})

					const target = item.target || ''
					const comments = item.comments || ''
					const timestamp = item.issued_when;
					let color = '';
					switch (item.team.role) {
						case 'Red':
							color = 'error';
							break;
						case 'Blue':
							color = 'info';
							break;
						case 'White':
							color = 'info';
							break;
					}
					this.items.push({
						type, target, title, description, timestamp, comments, color, det_description, det_title, mit_description, mit_title
					});
				});
			}).catch((error) => {
				console.log(error);
			});
		},
	},
};
</script>
