<template>
    <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 mb-5 shadow">

        <button class="navbar-toggler d-md-none collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <a class="navbar-brand me-0 px-3 fs-6" href="/">Project ADT</a>

        <div class="navbar-nav" v-if="isLogged" @logout="logout">
            <div class="nav-item text-nowrap">
                <a class="nav-link" v-if="isLogged">Ciao, <b>{{ name }}</b></a>
            </div>
        </div>


        <!-- pulsante esci -->
        <div class="navbar-nav" v-if="isLogged" @logout="logout">
            <div class="nav-item text-nowrap">
                <a class="nav-link px-3" v-if="isLogged" @click="logout" href="/">Esci</a>
            </div>
        </div>
    </header>
</template>

<script>
// call logout function of the parent component if the user clicks on the logout link
export default {
    name: "BannerBar",
    props: ['name'],
    data() {
        return {
            isLogged: false,
        }
    },
    methods: {
        logout() {
            this.$emit("logout");
        },
    },
    // se il cookie token è settato, allora l'utente è loggato
    mounted() {
        if (document.cookie.split(';').some((item) => item.trim().startsWith('token='))) {
            this.isLogged = true;
        }
    },
};
</script>
