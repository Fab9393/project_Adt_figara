<template>

<div class="container-fluid">
  <div class="d-md-block collapse" id="sidebarMenu">

    <div class="row">

    <!-- navbar -->
    <nav v-if="isLogged" class="col-md-4 col-lg-2 d-md-block bg-light sidebar" id="accordionNavbar">
        <div class="sidebar-sticky">

    <div class="sidebar-header">
      <img src="../assets/logo.png" class="img-fluid" alt="Responsive image" />
    </div>
    <ul class="sidebar-menu">
      <li class="nav-item">
        <!-- if !isLogged -->
        <RouterLink to="/" class="nav-link" v-if="!isLogged">
          <svg class="feather">
            <use href="/feather-sprite-v4.29.0.svg#home" />
          </svg>
          Home
        </RouterLink>

        <!-- if isLogged -->
        <RouterLink to="/home" class="nav-link" v-if="isLogged">
          <svg class="feather">
            <use href="/feather-sprite-v4.29.0.svg#home" />
          </svg>
          Home
        </RouterLink>
      </li>

      <li class="nav-item">
        <RouterLink to="/exercitations" class="nav-link" v-if="role == 'admin'">
          <svg class="feather">
            <use href="/feather-sprite-v4.29.0.svg#flag" />
          </svg>
          Esercitazioni
        </RouterLink>
      </li>

      <!-- link Esercitazioni Passate -->
            <li class="nav-item">
        <router-link to="/past-exercitations" class="nav-link" v-if="role != 'admin'">
          <svg class="feather">
              <use href="/feather-sprite-v4.29.0.svg#archive" />
          </svg>
          Esercitazioni Passate
      </router-link>

      </li>

      <li class="nav-item">
        <RouterLink to="/teams" class="nav-link" v-if="role == 'admin'" >
          <svg class="feather">
            <use href="/feather-sprite-v4.29.0.svg#users" />
          </svg>
          Team
        </RouterLink>
      </li>

      <div v-if="onGoingVar != 0">
      <li class="nav-item"  v-if="role === 'red' || role==='admin'">
        <!-- <RouterLink to="/" class="nav-link"> -->
        <RouterLink :to="`/exercitations/${onGoingVar}/attacks`" class="nav-link">
          <svg class="feather">
            <use href="/feather-sprite-v4.29.0.svg#alert-triangle" />
          </svg>
          Attacchi
        </RouterLink>
      </li>
      <li class="nav-item" v-if="role === 'blue' || role==='admin'">
        <RouterLink :to="`/exercitations/${onGoingVar}/defenses`" class="nav-link">
          <svg class="feather">
            <use href="/feather-sprite-v4.29.0.svg#activity" />
          </svg>
          Difese
        </RouterLink>
      </li>
      </div>
    </ul>

    <h6
      class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted text-uppercase"
    >
      <span>Impostazioni utente</span>
    </h6>

    <ul class="nav flex-column" v-if="role==='admin'">
      <li class="nav-item">
        <RouterLink to="/users" class="nav-link">
          <svg class="feather">
            <use href="/feather-sprite-v4.29.0.svg#user" />
          </svg>
          Utenti
        </RouterLink>
      </li>
    </ul>

    <ul class="nav flex-column">
      <li class="nav-item">
        <RouterLink to="/settings" class="nav-link">
          <svg class="feather">
            <use href="/feather-sprite-v4.29.0.svg#settings" />
          </svg>
          Impostazioni Utente
        </RouterLink>
      </li>
    </ul>

    <!-- <ul class="nav flex-column" v-if="role !== ''">
      <li class="nav-item">
        <RouterLink to="/" class="nav-link" @click="logout">
          <svg class="feather">
            <use href="/feather-sprite-v4.29.0.svg#log-out" />
          </svg>
          Esci
        </RouterLink>
      </li>
    </ul> -->
    </div>
  </nav>
</div>
      </div>
</div>
</template>

<script>
// cancella il cookie di sessione se si fa click su logout
export default {
  name: "SideLeftBar",
  props: {
    role: String,
    ongoing: Number,
  },
  data() {
    return {
      isLogged: false,
      errormsg: "",
      
      // set ongoingvar to ongoing prop, just the value
      onGoingVar: this.ongoing,
    };
  },
  methods: {
    logout() {
      // cancella il cookie di sessione "token"
      document.cookie = "token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; secure; SameSite=Lax";
      this.$emit('logout')
      this.isLogged = false;
    },
    getCookieValue(name) {
      const cookieValue = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)');
      return cookieValue ? cookieValue.pop() : '';
    }
  },
  mounted() {

    
    // if token is present, get role
    if (this.getCookieValue("token") !== "") {
      this.$emit('logout')
      this.isLogged = true;
    }
  },

  /* watch for changes on ongoing variable */
  watch: {
    ongoing: function (newVal, oldVal) {
      if(newVal !== oldVal){
        this.onGoingVar = newVal;
        
      }
    },
  },
}
</script>
