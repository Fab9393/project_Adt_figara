export const data = {
    labels: [
      'Correttezza',
      'Difesa',
      'Puntini Bonus',
      'Tempo',
      'koko'
    ],
    datasets: [
      {
        label: 'Punteggi Project ADT',
        backgroundColor: 'rgba(255,99,132,0.2)',
        borderColor: 'rgba(255,99,132,1)',
        pointBackgroundColor: 'rgba(255,99,132,1)',
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: 'rgba(255,99,132,1)',
        data: [70,50,100,30]
      }
    ],
  }
  
  export const options = {
    responsive: true,
    maintainAspectRatio: false
  }

  
  