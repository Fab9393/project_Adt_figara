
<template>
    <div>
        <div
            class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Gestione Team</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <div class="btn-group me-2">
                    <NewThingsButton pageName="teams" />
                </div>
            </div>
        </div>
        <!-- show Team data -->
        <h3>Team</h3>
        <table class="table table-striped table-bordered table-hover">
            <thead class="thead-dark">
                <th scope="col">ID</th>
                <th scope="col">Nome</th>
                <th scope="col">Ruolo</th>
                <th scope="col">Azioni</th>
            </thead>
            <tbody>
                <tr v-for="team in teams" v-bind:key="team.id" :id="'row' + '-' + team.id">
                    <th scope="row">{{ team.id }}</th>
                    <td>{{ team.name }}</td>
                    <td>
                        <p v-if="team.role == 'Red'" class="text-danger">{{ team.role }}</p>
                        <p v-else-if="team.role == 'Blue'" class="text-primary">{{ team.role }}</p>
                    </td>
                    <td>
                        <a href="#" class="link" id="mostra-dettagli" @click="showModal = true; getTeam(team.id)">Mostra
                            dettagli</a>
                        <Transition>
                            <ModalWindow v-if="showModal" @close="showModal = false" :showSaveButton="false"
                                name="Dettagli squadra">
                                <table>
                                    <tr>
                                        <td>Nome:</td>
                                        <td class="team-name">{{ selectedTeam.name }}</td>
                                    </tr>
                                    <tr>
                                        <td>Ruolo:</td>
                                        <td class="team-role text-danger" v-if="selectedTeam.role == 'Red'">{{
                                            selectedTeam.role }}</td>
                                        <td class="team-role text-primary" v-else-if="selectedTeam.role == 'Blue'">{{
                                            selectedTeam.role }}</td>
                                    </tr>
                                </table>


                                <!-- visualizza i membri -->
                                <h4>Membri</h4>
                                <table class="table table-striped table-bordered table-hover">
                                    <thead class="thead-dark">
                                        <th scope="col">ID</th>
                                        <th scope="col">Nome</th>
                                        <th scope="col">Cognome</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Nickname</th>
                                    </thead>
                                    <tbody>
                                        <tr v-for="member in selectedTeam.members" v-bind:key="member.id"
                                            :id="'row' + '-' + member.id">
                                            <th scope="row">{{ member.id }}</th>
                                            <td>{{ member.first_name }}</td>
                                            <td>{{ member.last_name }}</td>
                                            <td>{{ member.email }}</td>
                                            <td>{{ member.nickname }}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </ModalWindow>
                        </Transition>
                        <span>&nbsp;</span>
                        <a style="padding-left:10px" href="#" class="link" @click="deleteTeam(team.id)">Elimina?</a> <!--
                            <svg class="feather">
                                <use href="/feather-sprite-v4.29.0.svg#trash-2" />
                            </svg>-->
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
import { RouterLink } from 'vue-router';
import ModalWindow from "@/components/ModalWindow.vue";
import NewThingsButton from '../../components/NewThingsButton.vue';

export default {
    data() {
        return {
            selectedTeam: {},
            teams: [],
            showModal: false,
        };
    },
    props: ['pageName'],
    return: {
        pageName: "teams"
    },
    components: { RouterLink, NewThingsButton, ModalWindow },
    mounted() {
        this.$axios
            .get('/teams')
            .then(response => {
                this.teams = response.data
            })
            .catch(error => {
                console.log(error)
                this.errored = true
            })
            .finally(() => this.loading = false)
    },
    methods: {
        getTeam(id) {
            this.$axios
                .get('/teams/' + id)
                .then(response => {
                    this.selectedTeam = response.data
                })
                .catch(error => {
                    console.log(error)
                    this.errored = true
                })
                .finally(() => this.loading = false)
        },
        deleteTeam(id) {
            this.$axios
                .delete('/teams/' + id)
                .then(response => {
                    console.log(response)
                    if (response.status == 204) {
                        alert('Team eliminato con successo')
                    }
                    this.$router.go()
                })
                .catch(error => {
                    console.log(error)
                    this.errored = true
                })
                .finally(() => this.loading = false)
        },
    },
}
</script>

<style scoped>
.team-name {
    font-size: 24px;
    font-weight: bold;
}

.team-role {
    font-size: 18px;
    font-style: italic;
}

table {
    border-collapse: collapse;
}

td {
    padding: 5px;
}
</style>