
<template>
    <div>
        <div
            class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Gestione Attacchi</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <div class="btn-group me-2">
                    <NewThingsButton pageName="attacks" />
                </div>
            </div>

        </div>
        <!-- Show exercitation data -->
        <h3>Ultimi attacchi</h3>
        <table class="table table-striped table-bordered table-hover" v-if="atks.length > 0">
            <thead class="thead-dark">
                <th scope="col">Tattica</th>
                <th scope="col">Inserito da</th>
                <th scope="col">Data inserimento</th>
                <th scope="col">Target</th>
                <th scope="col">Esito</th>
                <th scope="col">Commenti</th>
                <th scope="col">Tecniche</th>
                <th scope="col">Elimina?</th>
            </thead>
            <tbody>
                <tr v-for="atk in atks" v-bind:key="atk.id">
                    <td scope="row">{{ atk.tactic.tactic }}</td>
                    <td scope="row">{{ atk.author.first_name }} {{ atk.author.last_name }}</td>
                    <td scope="row">{{ new Date(atk.issued_when).toLocaleString("it-IT", {
                        timezone: 'UTC', year: 'numeric',
                        month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric'
                    }) }}</td>
                    <td scope="row">{{ atk.target }}</td>
                    <td scope="row">
                        <!-- // 1 = ongoing, 2 = success, 3 = fail, 0 in caso di blue report -->
                        <!-- conditional render -->
                        <span v-if="atk.attack_outcome == 1" class="badge bg-warning text-dark">In corso</span>
                        <span v-else-if="atk.attack_outcome == 2" class="badge bg-success">Riuscito</span>
                        <span v-else-if="atk.attack_outcome == 3" class="badge bg-danger">Fallito</span>
                        <span v-else>{{ atk.attack_outcome }}</span>
                    </td>
                    <td scope="row">{{ atk.comments }}</td>
                    <td>
                        <!-- foreach technique draw an empty row and only column with data -->
                <tr v-for="tech in atk.techniques" v-bind:key="tech.id">
                    <!-- data column -->
                    <td scope="row"><span v-html="tech.mitre_technique.name"
                            :title="tech.mitre_technique.description"></span></td>
                </tr>
                </td>
                <td scope="col">
                    <!-- delete button with trash box feather icon -->
                    <button @click="" class="btn">
                        <svg class="feather">
                            <use href="/feather-sprite-v4.29.0.svg#trash-2" />
                        </svg>
                    </button>
                </td>
                </tr>
            </tbody>
        </table>
        <div v-else>
            <p>Nessun attacco inserito</p>
        </div>

    </div>
</template>
<script>
import { RouterLink } from 'vue-router';
import NewThingsButton from '../../components/NewThingsButton.vue';

export default {
    data() {
        return {
            atks: [],
            intervalId: null,
        };
    },
    props: ['pageName'],
    return: {
        pageName: "attacks"
    },
    methods: {
        fetchAttacks() {
            this.$axios
                .get('/exercitations/' + this.$route.params.id + '/reports?type=red')
                .then(response => {
                    // Remove Citation: blocks from descriptions
                    response.data.forEach(el => {
                        el.techniques.forEach(atk => {
                            atk.mitre_technique.description = atk.mitre_technique.description.replace(/\(Citation:[^)]*\)/g, '').trim();
                            atk.mitre_technique.description = atk.mitre_technique.description.replace(/\[(.*?)\]\(.*?\)/g, '$1').trim();

                            // rimuovi i tag <code> e preserva solo il contenuto
                            atk.mitre_technique.description = atk.mitre_technique.description.replace(/<code>(.*?)<\/code>/g, '$1').trim();
                        })
                    });
                    this.atks = response.data;
                })
                .catch(error => {
                    console.log(error);
                    this.errored = true;
                })
                .finally(() => this.loading = false)

        }
    },
    components: { RouterLink, NewThingsButton },
    mounted() {
        this.fetchAttacks();
        this.intervalId = setInterval(this.fetchAttacks, 5000);
    },
    beforeUnmount() {
        clearInterval(this.intervalId);
    },
    // watch for changes in atks
    watch: {
        atks: function (val, oldVal) {
        }
    }
}
</script>
