<template>
    <div>
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Gestione Utenti</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <div class="btn-group me-2">
                    <NewThingsButton pageName="users" />
                </div>
            </div>
        </div>
        <!-- Show exercitation data -->
        <h3>Utenti</h3>
        <table class="table table-striped table-bordered table-hover">
            <thead class="thead-dark">
                <th scope="col">ID</th>
                <th scope="col">Nome</th>
                <th scope="col">Cognome</th>
                <th scope="col">Nickname</th>
                <th scope="col">Email</th>
                <th scope="col">Team</th>
                <th scope="col">Elimina?</th>
            </thead>
            <tbody>
                <tr v-for="user in users" :key="user.id" :id="'row-' + user.id">
                    <th scope="row">{{ user.id }}</th>
                    <td>{{ user.first_name }}</td>
                    <td>{{ user.last_name }}</td>
                    <td>{{ user.nickname }}</td>
                    <td>{{ user.email }}</td>
                    <td>{{ user.team }}</td> <!-- Utilizzo il campo 'team' invece di 'user.Team' -->
                    <td>
                        <!-- check if current user id is == to user.id-->
                        <div v-if="user.id !== 3">
                            <button @click="deleteUser(user.id)" class="btn">
                                <svg class="feather">
                                    <use href="/feather-sprite-v4.29.0.svg#trash-2" />
                                </svg>
                            </button>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
import { RouterLink } from 'vue-router';
import NewThingsButton from '../../components/NewThingsButton.vue';

export default {
    data() {
        return {
            users: [],
            loading: false,
            errored: false
        };
    },
    props: ['pageName'],
    components: { RouterLink, NewThingsButton },
    mounted() {
    this.loading = true;
    this.$axios
        .get('/users')
        .then(response => {
            console.log('Users data from server:', response.data); // Stampiamo i dati ottenuti dal server
            Promise.all(response.data.map(async user => {
                user.team = await this.getUserRole(user.id);
            })).then(() => {
                this.users = response.data;
                this.loading = false;
            });
        })
        .catch(error => {
            console.error('Error fetching users:', error);
            this.errored = true;
            this.loading = false;
        });
},
    methods: {
        deleteUser(id) {
            this.$axios
                .delete('/users/' + id)
                .then(response => {
                    console.log(response)
                    if (response.status == 204) {
                        alert('Utenza eliminata con successo')
                    }
                    this.$router.go()
                })
                .catch(error => {
                    console.error('Error deleting user:', error);
                    this.errored = true;
                })
                .finally(() => this.loading = false)
        },
        getUserRole(userId) {
            return new Promise((resolve, reject) => {
                this.$axios.get(`/api/user/${userId}/teamrole`)
                    .then(response => {
                        resolve(response.data.role);
                    })
                    .catch(error => {
                        console.error('Error fetching user role:', error);
                        reject(error);
                    });
            });
        }
    }
}
</script>

