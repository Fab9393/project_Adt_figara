<template>
  <div>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
      <h1 class="h2">Risultati</h1>
    </div>
    <div v-if="exercitationResults">
      <!-- tabella con 4 colonne e n righe tante quante sono le mitigation con una checkbox a lato. Nell'ultima riga ci sono i punteggi finali-->
      <table class="table table-striped table-sm">
        <thead>
          <tr>
            <th scope="col">Punteggio Comprensione</th>
            <th scope="col">Punteggio Difesa</th>
            <th scope="col">Punteggio Realizzazione</th>
            <th scope="col">Punteggio Velocità di risposta</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{{ parseFloat(exercitationResults.s1).toFixed(2) }}</td>
            <td>{{ parseFloat(exercitationResults.s2).toFixed(2) }}</td>
            <td>{{ parseFloat(counter / mitigations.length).toFixed(2) }}</td>
            <td>{{ parseFloat(exercitationResults.s4).toFixed(2) }}</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-if="mitigations.length > 0">
      <h2>Mitigations</h2>
      <p>Selezionare le mitigations che sono state effettivamente implementate:</p>
      <div class="form-check" v-for="(mitigation, index) in mitigations" :key="index">
        <input type="checkbox" :id="'mitigation_' + index" @change="updateCounter(index)" class="form-check-input" />
        <label class="form-check-label" :for="'mitigation_' + index">{{ mitigation.name }}</label>
      </div>
    </div>

    <!-- div 400x400 -->
    <div style="width: 400px; height: 400px; margin: 0 auto;">
      <RadarCmp :s1="s1" :s2="s2" :s3="s3" :s4="s4" :key="`${s1}-${s2}-${s3}-${s4}`"
        v-if="exercitationResults && s1 !== '' && s2 !== '' && s3 !== '' && s4 !== ''"></RadarCmp>
    </div>

  </div>
</template>
<script>

import RadarCmp from "@/components/RadarCmp.vue";
import { RouterLink } from "vue-router";
export default {
  data() {
    return {
      s1: '',
      s2: '',
      s3: '',
      s4: '',
      exercitationResults: [],
      exercitationData: {},
      mitigations: [], // Popolare con le mitigations dal JSON
      counter: 0,
    };
  },
  props: ["pageName"],
  return: {
    pageName: "results",
  },
  methods: {
    updateCounter(index) {
      const mitigation = this.mitigations[index];
      if (mitigation.selected) {
        this.counter--;
      } else {
        this.counter++;
      }
      this.s3 = this.counter / this.mitigations.length
      mitigation.selected = !mitigation.selected;
    },
  },



  components: { RouterLink, RadarCmp },
  async mounted() {
    this.$axios
      .get("/exercitations/" + this.$route.params.id + "/results")
      .then((response) => {
        this.exercitationResults = response.data;
        this.s1 = this.exercitationResults.s1;
        this.s2 = this.exercitationResults.s2;
        if (this.mitigations && this.mitigations.length > 0) {
          this.s3 = this.counter / this.mitigations.length
        }
        else {
          this.s3 = 0
        }
        this.s4 = this.exercitationResults.s4;
        console.log(this.s1)
        console.log(this.s2)
        console.log(this.s3)
        console.log(this.s4)
      })
      .then(() => {
        this.$axios
          .get("/exercitations/" + this.$route.params.id + "/reports?type=blue")
          .then((response) => {
            this.exercitationData = response.data;
          })
          .then(() => {
            // foreach mitigation in this.exercitationData[i].techniques
            // this.mitigations.push(mitigation.name)

            this.exercitationData.forEach((element) => {
              element.techniques.forEach((technique) => {
                if (technique.mitigations) {
                  technique.mitigations.forEach((mitigation) => {
                    this.mitigations.push(mitigation.mitre_mitigation);
                  })

                }
              });
            });
          });
      })
      .catch((error) => {
        console.log(error);
      });
  },
};
</script>
