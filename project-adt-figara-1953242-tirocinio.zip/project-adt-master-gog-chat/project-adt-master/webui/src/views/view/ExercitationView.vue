
<template>
    <div>
        <div
            class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Gestione Esercitazioni</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <div class="btn-group me-2">
                    <NewThingsButton pageName="exercitations" />
                </div>
            </div>

        </div>
        <!-- Show exercitation data -->
        <h3>Ultime esercitazioni</h3>
        <table class="table table-striped table-bordered table-hover">
            <thead class="thead-dark">
                <th scope="col">ID</th>
                <th scope="col">Nome</th>
                <th scope="col">Inizio</th>
                <th scope="col">Fine</th>
                <th scope="col">Squadre</th>
                <th scope="col">Azioni</th>
            </thead>
            <tbody>
                <tr v-for="ex in exercitations" v-bind:key="ex.id">
                    <th scope="row">{{ ex.id }}</th>
                    <td>{{ ex.name }}</td>
                    <td>{{ new Date(ex.start_date).toLocaleString('it-IT', { timeZone: 'UTC' }) }}</td>
                    <td>{{ new Date(ex.end_date).toLocaleString('it-IT', { timeZone: 'UTC' }) }}</td>
                    <td>
                        <span v-for="team in ex.teams" :key="team.id">
                            <p v-if="team.role == 'Red'" class="text-danger">{{ team.name }}</p>
                            <p v-else-if="team.role == 'Blue'" class="text-primary">{{ team.name }}</p>
                        </span>
                    </td>
                        
                    <td>
                        <!-- tre link uno sopra l'altro -->
                        <div class="btn-group-vertical">
                            <router-link :to="'exercitations/' + ex.id + '/attacks'">
                                <a>Attacchi</a>
                            </router-link>
                        
                            <router-link :to="'exercitations/' + ex.id + '/defenses'">
                                <a>Difese</a>
                            </router-link>

                            <router-link :to="'exercitations/' + ex.id + '/results'">
                                <a>Risultati</a>
                            </router-link>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>

    </div>
</template>

<script>
import { RouterLink } from 'vue-router';
import NewThingsButton from '../../components/NewThingsButton.vue';

export default {
    data() {
        return {
            exercitations: [],
        };
    },
    props: ['pageName'],
    return: {
        pageName: "exercitations"
    },
    components: { RouterLink, NewThingsButton },
    mounted() {
        this.$axios
            .get('/exercitations')
            .then(response => (this.exercitations = response['data']))
            .catch(error => {
                console.log(error)
                this.errored = true
            })
            .finally(() => this.loading = false)
    }
}
</script>