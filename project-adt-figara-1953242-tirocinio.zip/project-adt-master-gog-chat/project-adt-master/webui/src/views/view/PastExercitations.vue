<template>
  <div>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
      <h1 class="h2">Panoramica Esercitazioni Passate</h1>
    </div>

    <!-- Show exercitation data -->
    <h3>Esercitazioni Passate</h3>
    <table class="table table-striped table-bordered table-hover">
      <thead class="thead-dark">
        <th scope="col">ID</th>
        <th scope="col">Nome Esercitazione</th>
        <th scope="col">Data Inizio</th>
        <th scope="col">Data Fine</th>
        <th scope="col">Path Ideale</th>
        <th v-if="isAdmin" scope="col">Storico Chat</th> <!-- Colonna visibile solo per admin -->
      </thead>
      <tbody>
        <tr v-for="ex in pastExercitations.filter(ex => new Date(ex.end_date) <= new Date())" :key="ex.id">
          <td>{{ ex.id }}</td>
          <td>{{ ex.name }}</td>
          <td>{{ formatDateTime(ex.start_date) }}</td>
          <td>{{ formatDateTime(ex.end_date) }}</td>
          <td>
            <router-link v-if="ex.hasIdealPath" :to="'/ideal-path/' + ex.id">
              <button v-if="ex.hasIdealPath" @click="openModal(ex)">Soluzione</button>
            </router-link>
          </td>
          <td v-if="isAdmin">
            <button @click="openChatHistoryModal(ex)">Storico Chat</button> <!-- Pulsante per storico chat -->
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Modal Ideal Path -->
    <div class="modal" v-if="showModal && idealPaths.length > 0">
      <div class="modal-content">
        <span class="close" @click="closeModal">×</span>
        <h2>Ideal Paths</h2>
        <table class="table table-striped table-bordered">
          <thead class="thead-dark">
            <tr>
              <th>Attacco</th>
              <th>Tecnica</th>
              <th>Target</th>
              <th>Detection</th>
              <th>Mitigation</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(path, index) in idealPaths" :key="index">
              <td>{{ path.Tattica }}</td>
              <td>{{ path.Tecnica }}</td>
              <td>{{ path.Target }}</td>
              <td>{{ path.Detection }}</td>
              <td>{{ path.Mitigation }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Modal Chat History -->
    <div class="modal" v-if="showChatModal && chatMessages.length > 0">
      <div class="modal-content">
        <span class="close" @click="closeChatModal">×</span>
        <h2>Storico Chat</h2>
        <table class="table table-striped table-bordered">
          <thead class="thead-dark">
            <tr>
              <th>Mittente</th>
              <th>Destinatario</th>
              <th>Data/Ora</th>
              <th>Contenuto</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="msg in chatMessages" :key="msg.id">
              <td>{{ msg.from_user_id }}</td>
              <td>{{ msg.to_user_id }}</td>
              <td>{{ formatDateTime(msg.timestamp) }}</td>
              <td>{{ msg.content }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
import { RouterLink } from 'vue-router';

export default {
  data() {
    return {
      pastExercitations: [],
      idealPaths: [],
      chatMessages: [],
      showModal: false,
      showChatModal: false,
      isAdmin: false // Variabile per il ruolo dell'utente
    };
  },
  components: { RouterLink },
  methods: {
    formatDateTime(dateTime) {
      return new Date(dateTime).toLocaleString('it-IT', { timeZone: 'UTC' });
    },
    loadPastExercitations() {
      const currentDate = new Date().toISOString(); // Get current date
      this.$axios
        .get('/exercitations')
        .then(response => {
          // Filter past exercitations with end date greater than current date
          this.pastExercitations = response.data.filter(ex => new Date(ex.start_date) <= new Date(currentDate));

          // For each exercitation, check if there are associated idealPaths
          this.pastExercitations.forEach(ex => {
            this.$axios.get(`/ideal-path/${ex.id}`) // <- Qui usi il backtick per interpolare l'ID
              .then(response => {
                // Check if there are ideal paths for this exercitation
                ex.hasIdealPath = response.data.length > 0;
              })
              .catch(error => {
                console.error('Error retrieving idealPaths:', error);
              });
          });
        })
        .catch(error => {
          console.error('Error retrieving past exercitations:', error);
        });
    },
    openModal(ex) {
      this.$axios.get(`/ideal-path/${ex.id}`)
        .then(response => {
          this.idealPaths = response.data;
          this.showModal = true;
        })
        .catch(error => {
          console.error('Error retrieving idealPaths:', error);
        });
    },
    closeModal() {
      this.showModal = false;
      this.idealPaths = [];
    },
    openChatHistoryModal(ex) {
      this.$axios.get(`/api/chat-messages/${ex.id}`)
        .then(response => {
          this.chatMessages = response.data;
          this.showChatModal = true;
        })
        .catch(error => {
          console.error('Error retrieving chat messages:', error);
        });
    },
    closeChatModal() {
      this.showChatModal = false;
      this.chatMessages = [];
    },
    checkUserRole() {
      this.$axios.get('/api/user-role')
        .then(response => {
          this.isAdmin = response.data.role === 'admin';
        })
        .catch(error => {
          console.error('Error retrieving user role:', error);
        });
    }
  },
  mounted() {
    this.loadPastExercitations();
    this.checkUserRole(); // Controlla il ruolo dell'utente al montaggio del componente
  }
}
</script>

<style>
/* CSS per la modale */
.modal {
  display: block; /* Nascondi la modale per default */
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0, 0, 0, 0.5); /* Fondo semi-trasparente */
}

.modal-content {
  background-color: #fefefe;
  margin: 10% 0;
  padding: 20px;
  border: 1px solid #888;
  width: 80%; /* Larghezza iniziale della modal */
  max-width: 2000px; /* Larghezza massima della modal */
  position: absolute; /* Posiziona la modal relativamente al suo contenitore */
  right: 20px; /* Sposta la modal 20px dal bordo destro del suo contenitore */
  top: 20px;
}



.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}
</style>

