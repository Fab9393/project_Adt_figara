<template>
  <div class="container">
    <div class="alert alert-danger" v-if="errorMessage">
      {{ errorMessage }}
    </div>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
      <h2>Login</h2>
    </div>

    <form @submit.prevent="submitForm">
      <div class="form-group mb-3">
        <label for="email">Email</label>
        <input type="email" class="form-control" id="email" v-model="email" />
      </div>

      <div class="form-group mb-3">
        <label for="password">Password</label>
        <input type="password" class="form-control" id="password" v-model="password" />
      </div>

      <div class="form-group mb-3">
        <button class="btn btn-primary">Login</button>
      </div>

      <div class="form-group mb-3">
        <a class="google-btn" href="/auth/google">Google+</a>
      </div>

      <!-- link alla registrazione -->
      <div class="form-group mb-3">
        <router-link to="/users/new">Non hai un account? Registrati</router-link>
      </div>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      email: '',
      password: '',
      errorMessage: ''
    }
  },
  methods: {
    async submitForm() {
      try {
        var formData = new FormData();
        formData.append('email', this.email);
        formData.append('password', this.password);
        const response = await this.$axios.post('/login', formData).then(response => {
          if (response.status === 200) {
            var date = new Date()
            date.setTime(date.getTime() + 24 * 60 * 60 * 1000);
            document.cookie = `token=${response.data.token}; expires=${date.toUTCString()}; secure=true; sameSite=strict`;
            window.location.replace('/home')
          }
          else {
            this.errorMessage = 'Connessione fallita. Verifica che il server sia up e riprova.';
          }
        })
      }
      catch (error) {
        // errore 401 non autorizzato
        if (error.response.status === 401) {
          this.errorMessage = 'Credenziali errate. Riprova.';
        }
        else {
          this.errorMessage = 'Connessione fallita. Verifica che il server sia up e riprova.';

        }

      }
    }
  },
  mounted() {
    if (document.cookie.split(';').some((item) => item.trim().startsWith('token='))) {
      this.$axios.get('/my/role').then(response => {
        if (response.status === 200) {
          window.location.replace('localhost:5173/home')
        }
      })
    } else if (window.location.search.includes('auth=google')) {
      // Verifica il token nel cookie per gli utenti autenticati tramite Google
      if (document.cookie.split(';').some((item) => item.trim().startsWith('token='))) {
        this.$axios.get('/my/role').then(response => {
          if (response.status === 200) {
            window.location.replace('/home');
          }
        });
      } else {
        this.errorMessage = 'Autenticazione Google fallita. Riprova.';
      }
    }
  },
}
</script>
