<template>
  <div>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
      <h1 class="h2">Nuovo attacco</h1>
    </div>
    <div>
      <form v-on:submit.prevent="submitForm">
        <div class="form-group row">
          <!-- tactic input field -->
          <label for="tactic" class="col-sm-2 col-form-label">Tattica
            <label style="color: red;">*</label>
          </label>
          <div class="col-sm-10">
            <input type="text" class="form-control mb-sm-3" id="mitreTacticId" v-model="form.mitre_tactic_id"
              placeholder="Cerca una tattica dal db mitre..." @input="getSuggestions('tactic')"
              v-if="!selectedTacticName" />
            <div class="suggestions" v-if="tacticSuggestions.length > 0">
              <ul>
                <li v-for="(t, index) in tacticSuggestions" :key="index" @click="setSelectedTactic(t)">
                  {{ t.tactic }}
                </li>
              </ul>
            </div>
            <div v-else>
              <p style="padding-top:8px"><strong>{{ selectedTacticName }}</strong></p>
            </div>
          </div>


          <label for="mitreTechniqueId" class="col-sm-2 col-form-label">Tecnica
            <label style="color: red;">*</label>
          </label>
          <div class="col-sm-10">
            <input type="text" class="form-control mb-sm-3" id="mitreTechniqueId" v-model="mitre_technique_id"
              placeholder="Cerca un attacco nel db mitre..." @input="getSuggestions('technique')"
              />
            <div class="suggestions" v-if="suggestions.length > 0">
              <ul>
                <li v-for="(suggestion, index) in suggestions" :key="index" @click="setSelectedTechnique(suggestion)">
                  {{ suggestion.name }}
                </li>
              </ul>
            </div>
            <div v-for="t in this.form.techniques" :key="t">
              <p style="padding-top:8px"><strong>{{ t.name }}</strong></p>
              <div v-html="t.description"></div>

              <v-divider></v-divider>
              
            </div>
          </div>          
          <label for="target" class="col-sm-2 col-form-label">Target 
            <label style="color: red;">*</label>
          </label>
          <div class="col-sm-10">
            <input type="text" class="form-control mb-sm-3" id="target" v-model="form.target"
              placeholder="Inserisci il target..." required>
          </div>
        </div>

        <div class="form-group row">
          <label for="comments" class="col-sm-2 col-form-label">Commenti<label style="color: red;">*</label></label>
          <div class="col-sm-10">
            <textarea class="form-control mb-sm-3" id="comments" v-model="form.comments"
              placeholder="Inserisci i commenti..." rows="10"></textarea>
          </div>
        </div>
        <div class="form-group d-flex mr-2 justify-content-end flex-row">
          <!-- Cancel button go back to the previous view in vuejs-->
          <!-- button will onclick prevent on the previous route -->
          <button @click.prevent="$router.push('/exercitations/' + this.form.exercitation_id + '/attacks')"
            class="btn btn-secondary" style="margin-right:10px">
            Annulla
          </button>
          <button value="Submit" @click="sendAttack()" class="btn btn-primary" ref="btnSalva">
            Salva
          </button>
        </div>
      </form>
    </div>
  </div>
</template>
<script>
import { marked } from 'marked'
export default {
  data() {
    return {
      form: {
        mitre_tactic_id: '',
        exercitation_id: this.$route.params.id,
        target: '',
        comments: '',
        techniques: [],
      },
      mitre_technique_id: '',

      subSuggestions: [],
      mitre_subtechnique_id: '',

      selectedTechniqueName: '',
      selectedTacticName: '',
      selectedTechniqueDescription: '',
      searchResults: [],
      suggestions: [],
      subSuggestions: [],
      tacticSuggestions: [],
    }
  },
  methods: {
    sendAttack() {
      // TODO: eseguire questo codice solo se input valido - implementare validazione input
      // force the field issued_by to a number then send the post request
      this.form.exercitation_id = parseInt(this.form.exercitation_id)

      this.$axios
        .post('/exercitations/' + this.form.exercitation_id + '/reports', this.form)
        .then(response => {
          // if the post is successful, redirect to the attacks view
          if (response.status == 200) {
            // show a bootstrap alert
            alert('Attacco creato con successo')

            // redirect to the exercitation attacks view
            this.$router.push('/exercitations/' + this.form.exercitation_id + '/attacks')
          }
        })
        .catch(error => {
          console.log(error)
          this.errored = true
        }).finally(() => this.loading = false)

    },
    getSuggestions(type) {
      const searchValue = type === 'technique' ? this.mitre_technique_id.trim() : this.form.mitre_tactic_id.trim();
      const url = type === 'technique' ? '/mitre/techniques/all' : '/mitre/tactics';
      const suggestionsArray = type === 'technique' ? this.suggestions : this.tacticSuggestions;

      if (searchValue !== '') {
        this.$axios
          .get(url)
          .then(response => {
            const data = response.data;

            const filteredData = data.filter(item => {
              const itemName = type === 'technique' ? item.name.toLowerCase() : item.tactic.toLowerCase();
              return itemName.includes(searchValue.toLowerCase());
            });

            suggestionsArray.splice(0, suggestionsArray.length, ...filteredData);
          })
          .catch(error => {
            console.log(error);
          });
      } else {
        suggestionsArray.splice(0, suggestionsArray.length);
      }
    },
    setSelectedTactic(mitreTactic) {
      this.form.mitre_tactic_id = mitreTactic.id;
      this.selectedTacticName = mitreTactic.tactic;
      this.tacticSuggestions = [];
    },
    setSelectedTechnique(mitreAttack) {
      this.selectedTechniqueName = mitreAttack.name;
      this.mitre_technique_id = '';

      this.form.techniques.push({
        ...mitreAttack,

        // elimina dal testo gruppi di parentesi che iniziano con Citation:
        description: marked(mitreAttack.description.replace(/\(Citation:.*?\)/g, '')),
      });
      
      this.suggestions = [];
    },
  },
  mounted() {
    this._keyListener = function (e) {
      if (e.key === "Enter") {
        e.preventDefault();
        this.$refs.btnSalva.click()
      }
    };
    document.addEventListener('keydown', this._keyListener.bind(this));
  },
  beforeDestroy() {
    document.removeEventListener('keydown', this._keyListener);
  }
}
</script>
 