
<template>
    <!-- TODO: placeholder -->
    <div>
        <div
            class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Nuovo Team</h1>

        </div>
        <div>
            <form v-on:submit.prevent="submitForm">
                <div class="form-group row">
                    <label for="name" class="col-sm-2 col-form-label">Nome<label style="color: red;">*</label></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control mb-sm-3" id="name" v-model="form.name" required>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="description" class="col-sm-2 col-form-label">Ruolo<label
                            style="color: red;">*</label></label>
                    <div class="col-sm-10">
                        <!-- combobox con red and blue come opzioni -->
                        <select class="form-control" id="role" v-model="form.role" required>
                            <option value="red">Red</option>
                            <option value="blue">Blue</option>
                        </select>
                    </div>
                </div>

                <span>&nbsp;</span>

                <h3>Utenti</h3>

                <!-- Create search bar to add user to a team -->
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Cerca utente" aria-label="Cerca utente"
                        aria-describedby="button-user-search" v-model="userQuery">
                    <button class="btn btn-outline-secondary" id="button-user-search" ref="btnUserSearch"
                        @click="searchUser()">Cerca</button>
                </div>
                <div class="form-group">
                    <!-- if added_user_names length is empty then show an appropriate message -->
                    <button class="btn btn-secondary btn-sm" v-if="added_users_names.length == 0">Nessun
                        utente aggiunto</button>

                    <!-- else show the added users -->
                    <span v-for="email in added_users_names">
                        <button class="btn btn-secondary btn-sm rounded bg-white text-dark" @click="removeUser(email)">{{
                            email }} <svg class="feather">
                                <use href="/feather-sprite-v4.29.0.svg#x" />
                            </svg></button>
                        <!-- space between buttons -->
                        <span>&nbsp;</span>
                    </span>
                </div>

                <!-- space -->
                <span>&nbsp;</span>

                <table class="table table-striped table-bordered table-hover">
                    <thead class="thead-dark">
                        <th scope="col">ID</th>
                        <th scope="col">Nome</th>
                        <th scope="col">Cognome</th>
                        <th scope="col">Email</th>
                        <th scope="col"></th>
                    </thead>
                    <tbody>
                        <tr v-for="user in filteredItems" v-bind:key="user.id" :id="'row' + '-' + user.id">
                            <td>{{ user.id }}</td>
                            <td>{{ user.first_name }}</td>
                            <td>{{ user.last_name }}</td>
                            <td>{{ user.email }}</td>
                            <td>
                                <button class="btn btn-success" @click="addUser(user.id)">Aggiungi</button>
                                <!-- space between buttons -->
                                <span>&nbsp;</span>
                            </td>
                        </tr>
                    </tbody>
                </table>


                <div class="form-group d-flex mr-2 justify-content-end flex-row">
                    <!-- Cancel button go back to the previous view in vuejs-->
                    <button @click.prevent="$router.push('/teams')" class="btn btn-secondary"
                        style="margin-right:10px">Annulla</button>
                    <button value="Submit" @click="sendTeam()" class="btn btn-primary" ref="btnSalva">Salva</button>
                </div>

            </form>
        </div>
    </div>
</template>

<script>

export default {
    data() {
        return {
            form: {
                name: '',
                role: 'Red'
            },
            users: [],
            usersQuery: '',
            added_users: [],
            added_users_names: [],
        }
    },
    computed: {
        filteredItems() {
            // if users is not defined or is empty
            if (!this.users) {
                // return an empty array
                return []
            }


            return this.users.filter(user => {
                // if users is not in the added_teams array, return it
                if (!this.added_users.includes(user.id)) {
                    console.log(this.added_users)
                    return user.id
                }
            })
        }
    },
    methods: {
        searchUser() {
            // if userQuery is not defined or is empty
            if (!this.userQuery) {
                // call the route search from api to get the team where kind = team and name = name got from input team
                this.$axios
                    // TODO: refactor: cambiare la route in /users/search?name=userQuery
                    .get('/search?kind=users')
                    .then(response => {
                        this.users = response.data.results
                    })
                    .catch(error => {
                        this.errored = true
                    }).finally(() => this.loading = false)
            }
            else {
                // call the route search from api to get the team where kind = team and name = name got from input team
                this.$axios
                    // TODO: refactor: cambiare la route in /users/search?name=userQuery
                    .get('/search?kind=users&name=' + this.userQuery.toString())
                    .then(response => {
                        this.users = response.data.results
                    })
                    .catch(error => {
                        this.errored = true
                    }).finally(() => this.loading = false)
            }
        },
        sendTeam(e) {
            // TODO: eseguire questa parte solo se input valido - implementare validazione
            this.$axios
                .post('/teams', this.form)
                .then(response => {
                    // for each user id in the added_users array, make a post request to add the team to the exercitation by giving team_id and and user_id
                    this.added_users.forEach(user_id => {
                        this.$axios
                            .post('/teams/' + response.data.id + '/members/' + user_id)
                            .then(response => {
                                // if the post is successful, redirect to the teams view
                                if (response.status == 200) {
                                    // if last element shows a success popup
                                    if (user_id === this.added_users[this.added_users.length - 1]) {
                                        alert('Team creato con successo.')

                                        // redirect to the teams view
                                        this.$router.push('/teams')
                                    }

                                }
                                else {
                                    alert('Ops. C\'è stato un problema. Riprova piu tardi.')
                                }
                            })
                            .catch(error => {
                                console.log(error)
                                this.errored = true
                            }).finally(() => {
                                this.loading = false
                            })
                    })

                })
                .catch(error => {
                    console.log(error)
                    this.errored = true
                }).finally(() => this.loading = false)
        },
        addUser(user_id) {
            // add the user to the list of added users
            this.added_users.push(user_id)

            // add the user name to the list of added users names
            this.added_users_names.push(this.users.find(user => user.id == user_id).email)

            // remove the user from the list of users
            this.users = this.users.filter(user => user.id != user_id)
        },
        removeUser(name) {
            // find out the index of the user in the list of added users
            let index = this.added_users_names.indexOf(name)

            // remove the user from the list of added users names
            this.added_users_names.splice(index, 1)

            // remove the id of the user from the list of added users
            this.added_users.splice(index, 1)

        }


    },
    mounted() {
        this._keyListener = function (e) {
            if (e.key === "Enter") {
                e.preventDefault();
                this.$refs.btnUserSearch.click()
            }
        };
        document.addEventListener('keydown', this._keyListener.bind(this));
    },
    beforeDestroy() {
        document.removeEventListener('keydown', this._keyListener);
    },
    created() {

        this.$axios.get('/users')
            .then(response => {
                this.users = response.data.results;
            })
            .catch(error => {
                console.log(error);
            });
    },
}   
</script>