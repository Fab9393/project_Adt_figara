
<template>
    <div>
        <div
            class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Nuovo utente</h1>

        </div>
        <div>
            <form v-on:submit.prevent="submitForm">
                <div class="form-group row">
                    <label for="first_name" class="col-sm-2 col-form-label">Nome<label style="color: red;">*</label></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control mb-sm-3" id="first_name" v-model="form.first_name" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="last_name" class="col-sm-2 col-form-label">Cognome<label
                            style="color: red;">*</label></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control mb-sm-3" id="last_name" v-model="form.last_name" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="nickname" class="col-sm-2 col-form-label">Nickname</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control mb-sm-3" id="nickname" v-model="form.nickname">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="email" class="col-sm-2 col-form-label">Email<label style="color: red;">*</label></label>
                    <div class="col-sm-10">
                        <input type="email" class="form-control mb-sm-3" id="email" v-model="form.email">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="password" class="col-sm-2 col-form-label">Password<label
                            style="color: red;">*</label></label>
                    <div class="col-sm-10">
                        <input type="password" class="form-control mb-sm-3" id="password" v-model="form.password">
                    </div>
                </div>

                <div class="form-group d-flex mr-2 justify-content-end flex-row">
                    <!-- Cancel button go back to the previous view in vuejs-->
                    <!-- <button @click.prevent="$router.push('/users')" class="btn btn-secondary"
                        style="margin-right:10px">Annulla</button> -->
                    <button value="Submit" @click="senduser" class="btn btn-primary" ref="btnSalva">Salva</button>
                </div>

            </form>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            form: {
                first_name: '',
                last_name: '',
                nickname: '',
                email: '',
                password: ''
            }
        }
    },
    methods: {

        senduser(e) {
            console.log(this.form.password)
            // TODO: eseguire questa parte solo se input valido - implementare validazione
            this.$axios
                .post('/users', this.form)
                .then(response => {
                    console.log(response)
                    // if the post is successful, redirect to the users view
                    if (response.status == 200) {
                        alert('Utente creato con successo')

                        // if cookie is set, redirect to the users view
                        if (document.cookie.split(';').some((item) => item.trim().startsWith('token='))) {
                            this.$router.push('/users')
                        }
                        // if cookie is not set, redirect to the login view
                        else {
                            this.$router.push('/')
                        }
                    }
                })
                .catch(error => {
                    console.log(error)
                    this.errored = true
                }).finally(() => {
                    this.loading = false;
                })
        }
    },
    mounted() {
        this._keyListener = function (e) {
            if (e.key === "Enter") {
                e.preventDefault();
                this.$refs.btnSalva.click()
            }
        };
        document.addEventListener('keydown', this._keyListener.bind(this));
    },
    beforeDestroy() {
        document.removeEventListener('keydown', this._keyListener);
    }
}   
</script>