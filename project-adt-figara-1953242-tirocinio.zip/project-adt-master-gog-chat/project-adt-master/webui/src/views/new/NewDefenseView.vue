<template>
  <div>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
      <h1 class="h2">Nuova difesa</h1>
    </div>
    <div>



      <div class="form-group row">
        <!-- tactic input field -->
        <label for="tactic" class="col-sm-2 col-form-label">Presunta tattica
          <label style="color: red;">*</label>
        </label>
        <div class="col-sm-10">
          <input type="text" class="form-control mb-sm-3" id="mitreTacticId" v-model="form.mitre_tactic_id"
            placeholder="Cerca una tattica dal db mitre..." @input="getSuggestions('tactic')" v-if="!selectedTacticName" />
          
          <div class="mb-sm-3 align-bottom" style="padding-top: 8px;" v-else>
            <p><strong>{{ selectedTacticName }}</strong></p>
          </div>

          <div class="suggestions" v-if="tacticSuggestions.length > 0">
            <ul>
              <li v-for="(t, index) in tacticSuggestions" :key="index" @click="setSelectedTactic(t)">
                {{ t.tactic }}
              </li>
            </ul>
          </div>

          <button class="btn btn-primary" @click="showModal = true">Aggiungi rilevamento</button>

        </div>
      </div>
      <v-divider></v-divider>

      <!--
        Tabella che stampa attacco, detection, mitigation
      -->
      <table class="table table-striped" v-if="this.form.tecdetmit.length > 0">
        <thead>
          <tr>
            <th scope="col">Attacco</th>
            <th scope="col">Detection</th>
            <th scope="col">Mitigation</th>
            <th scope="col">Azione</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="a in this.form.tecdetmit" :key="a">
            <td><span v-html=" a.technique.name" :title="a.technique.description"></span></td>
            <td v-if="a.detection"><span v-html=" a.detection.name" :title="a.detection.description"></span></td>
            <td v-else>-</td>

            <td v-if="a.mitigation"><span v-html=" a.mitigation.name" :title="a.mitigation.description"></span></td>
            <td v-else>-</td>
            <td>
              <!-- <button class="btn btn-danger" @click="removeDetection(a)">Rimuovi</button> -->
            </td>
          </tr>
        </tbody>
      </table>
















      <Transition>
        <ModalWindow v-if="showModal" @close="showModal=false" @save="showModal=false;saveThings()" name="Inserisci i dati della rilevazione">
          <!-- presunto attacco -->
          <div class="form-group row">
            <label for="mitre_alleged_technique_id" class="col-sm-2 col-form-label">Presunto attacco
              <label style="color: red;">*</label>
            </label>
            <div class="col-sm-10">
              <input type="text" class="form-control mb-sm-3" id="mitre_alleged_technique_id"
                v-model="mitre_technique_id" placeholder="Cerca un attacco..." required
                @input="getSuggestions('technique')" v-if="!selectedTecniqueName" />
              <div class="suggestions" v-if="this.techniqueSuggestions.length > 0">
                <ul>
                  <li v-for="(suggestion, index) in techniqueSuggestions" :key="index"
                    @click="setSelectedTecnique(suggestion)">
                    {{ suggestion.name }}
                  </li>
                </ul>
              </div>
              <div v-else>
                <p style="padding-top: 7px;"><strong>{{ selectedTecniqueName }}</strong></p>
                <div v-html="selectedTecniqueDescription"></div>
              </div>
            </div>
          
          <!-- detection -->
          <label for="mitreDetectionId" class="col-sm-2 col-form-label">Detection
            <label style="color: red;">*</label>
          </label>
          <div class="col-sm-10">
            <input type="text" class="form-control mb-sm-3" id="mitreDetectionId" v-model="this.mitre_detection_id"
              placeholder="Cerca una detection..." required @input="getSuggestions('detection')"
              v-if="!selectedDetectionName" />
            <div class="suggestions" v-if="detectionSuggestions.length > 0">
              <ul>
                <li v-for="(suggestion, index) in detectionSuggestions" :key="index" @click="setSelectedDetection(suggestion)">
                  {{ suggestion.name }}
                </li>
              </ul>
            </div>
            <div v-else>
              <p style="padding-top: 7px;"><strong>{{ selectedDetectionName }}</strong></p>
            </div>
          </div>

          <!-- mitigation -->
          <label for="mitreMitigationId" class="col-sm-2 col-form-label">Mitigation
            <label style="color: red;">*</label>
          </label>
          <div class="col-sm-10">
            <input type="text" class="form-control mb-sm-3" id="mitreMitigationId" v-model="this.mitre_mitigation_id"
              placeholder="Cerca una mitigation..." required @input="getSuggestions('mitigation')"
              v-if="!selectedMitigationName" />
            <div class="suggestions" v-if="mitigationSuggestions.length > 0">
              <ul>
                <li v-for="(suggestion, index) in mitigationSuggestions" :key="index" @click="setSelectedMitigation(suggestion)">
                  {{ suggestion.name }}
                </li>
              </ul>
            </div>
            <div v-else>
              <p style="padding-top: 7px;"><strong>{{ selectedMitigationName }}</strong></p>
              <div v-html="selectedMitigationDescription"></div>
            </div>
          </div>



        </div>

        </ModalWindow>
      </Transition>




      <div>
        <form v-on:submit.prevent="submitForm">

         
          <div class="form-group row">
            <label for="target" class="col-sm-2 col-form-label">Presunto Target
              <label style="color: red;">*</label>
            </label>
            <div class="col-sm-10">
              <input type="text" class="form-control mb-sm-3" id="target" v-model="form.target"
                placeholder="Inserisci il presunto target...">
            </div>
          </div>

          <div class="form-group row">
            <label for="comments" class="col-sm-2 col-form-label">Commenti <label style="color: red;">*</label></label>
            <div class="col-sm-10">
              <textarea class="form-control mb-sm-3" id="comments" v-model="form.comments"
                placeholder="Inserisci i commenti..." rows="10"></textarea>
            </div>
          </div>
          <div class="form-group d-flex mr-2 justify-content-end flex-row">
            <!-- Cancel button go back to the previous view in vuejs-->
            <!-- button will onclick prevent on the previous route -->
            <button @click.prevent="$router.push('/exercitations/' + this.form.exercitation_id + '/defenses')"
              class="btn btn-secondary" style="margin-right:10px">
              Annulla
            </button>
            <button value="Submit" @click="sendDetection()" class="btn btn-primary" ref="btnSalva">
              Salva
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>
<script>
import { marked } from 'marked'

import ModalWindow from "@/components/ModalWindow.vue";
export default {
  data() {
    return {
      form: {
        mitre_tactic_id: '',
        exercitation_id: this.$route.params.id,
        issued_by: '',   // TODO: sostituire con id dell'utente loggato
        target: '',        comments: '',
        mitre_alleged_technique_id: '', // nuovo campo per l'attacco presunto
        comments: '',
        techniques: null,
        detections: null,
        mitigations: null,
        tecdetmit: [],
      },
      mitre_technique_id: '',
      mitre_detection_id: '',
      mitre_mitigation_id: '',

      selectedTecniqueName: '',
      selectedTecniqueDescription: '',

      selectedDetectionName: '',
      selectedDetectionDescription: '',

      selectedMitigationName: '',
      selectedMitigationDescription: '',

      selectedTacticName: '',

      searchResults: [],
      techniqueSuggestions: [], // nuovo array per i suggerimenti di attacchi presunti
      tacticSuggestions: [],
      detectionSuggestions: [],
      mitigationSuggestions: [],
      showModal: false,
    }
  },
  methods: {
    sendDetection() {
      // TODO: eseguire questo codice solo se input valido - implementare validazione input
      // force the field issued_by to a number then send the post request
      this.form.issued_by = parseInt(this.form.issued_by)
      this.form.exercitation_id = parseInt(this.form.exercitation_id)

      this.$axios
        .post('/exercitations/' + this.form.exercitation_id + '/reports', this.form)
        .then(response => {
          console.log(response)
          // if the post is successful, redirect to the detections view
          if (response.status == 200) {
            // show a bootstrap alert
            alert('Detection creata con successo')

            // redirect to the exercitation detections view
            this.$router.push('/exercitations/' + this.form.exercitation_id + '/defenses')
          }
        })
        .catch(error => {
          console.log(error)
          this.errored = true
        }).finally(() => this.loading = false)

    },
    getSuggestions(type) {
      var searchValue = '';
      var url = '';

      if (type === 'technique') {

        searchValue = this.mitre_technique_id.trim();
        url = '/mitre/techniques/all';
      } else if (type === 'tactic') {

        searchValue = this.form.mitre_tactic_id.trim();
        url = '/mitre/tactics';
      } else if (type === 'mitigation') {

        searchValue = this.mitre_mitigation_id.trim();
        url = '/mitre/mitigations';
      } else {
        searchValue = this.mitre_detection_id.trim();
        url = '/mitre/datasources';
      }
      
      if (searchValue !== '') {
        this.$axios
          .get(url)
          .then(response => {
            const data = response.data;
            const filteredData = data.filter(item => {
              let itemName;
              if (type === 'tactic') {
                itemName = item.tactic.toLowerCase();
              } else {
                itemName = item.name.toLowerCase();
              }
              return itemName.includes(searchValue.toLowerCase());
            });

            this[type + 'Suggestions'].splice(0, this[type + 'Suggestions'].length, ...filteredData);
          })
          .catch(error => {
            console.log(error);
          });
      } else {
        this[type + 'Suggestions'].splice(0, this[type + 'Suggestions'].length);
      }
    },

   
    setSelectedTactic(mitreTactic) {
      this.form.mitre_tactic_id = mitreTactic.id;
      this.selectedTacticName = mitreTactic.tactic;
      this.tacticSuggestions = [];
    },
    setSelectedTecnique(mitreTecnique) {
      this.selectedTecniqueName = mitreTecnique.name;

      // elimina dal testo gruppi di parentesi che iniziano con Citation: e rimuove tutti i blocchi che contengono <code> preservando il testo
      this.selectedTecniqueDescription = marked(mitreTecnique.description.replace(/\(Citation:.*?\)/g, '').replace(/<code>.*?<\/code>/g, ''))
      this.techniqueSuggestions = [];

      this.form.techniques = mitreTecnique;
    },
    setSelectedDetection(mitreDetection) {
      this.selectedDetectionName = mitreDetection.name;

      this.form.detections = {
        ...mitreDetection,

        // elimina dal testo gruppi di parentesi che iniziano con Citation:
        description: marked(mitreDetection.description.replace(/\(Citation:.*?\)/g, '')),
      };
      this.detectionSuggestions = [];
    },
    setSelectedMitigation(mitreMitigation) {
      this.selectedMitigationName = mitreMitigation.name;

      // elimina dal testo gruppi di parentesi che iniziano con Citation: e rimuove tutti i blocchi che contengono <code> preservando il testo
      this.selectedMitigationDescription = marked(mitreMitigation.description.replace(/\(Citation:.*?\)/g, '').replace(/<code>.*?<\/code>/g, ''))

      this.form.mitigations = mitreMitigation;
      this.mitigationSuggestions = [];
    },
    saveThings() {
      // array formato da triple composte da
      // attacco, detection, mitigation

      if (this.form.techniques && (this.form.detections || this.form.mitigations )) {
        this.form.tecdetmit.push({technique: this.form.techniques, detection: this.form.detections, mitigation: this.form.mitigations})

      }
      else {
        alert("Inserire almeno un presunto attacco ed una detection o una mitigation")
      }


      this.mitre_technique_id = '';
      this.mitre_detection_id = '';
      this.mitre_mitigation_id = '';

      // DECOMMENTARE per far permettere all'utente di selezionare piu tecniche
      // this.selectedTecniqueName = '';
      // this.selectedTecniqueDescription = '';
      // this.selectedDetectionName = '';
      // this.selectedMitigationName = '';
      // this.selectedMitigationDescription = '';
      this.form.techniques = null;
      this.form.detections = null;
      this.form.mitigations = null;
    }

  },
  mounted() {
    this._keyListener = function (e) {
      if (e.key === "Enter") {
        e.preventDefault();
        this.$refs.btnSalva.click()
      }
    };
    document.addEventListener('keydown', this._keyListener.bind(this));
  },
  components: {
    ModalWindow
  },
  beforeDestroy() {
    document.removeEventListener('keydown', this._keyListener);
  }
}
</script>
