
<template>

    <div>
        <div
            class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Nuova esercitazione</h1>

        </div>
        <div>
            <form v-on:submit.prevent="submitForm">
                <div class="form-group row">
                    <label for="exercitationName" class="col-sm-2 col-form-label">Nome<label style="color: red;">*</label></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control mb-sm-3" id="exercitationName" v-model="form.name"
                            placeholder="Inserisci un nome..." required>
                    </div>
                </div>
                <!-- data di inizio (start) -->
                <div class="form-group row">
                    <label for="start_date" class="col-sm-2 col-form-label">Data di inizio<label style="color: red;">*</label></label>
                    <div class="col-sm-10">
                        <input type="datetime-local" class="form-control mb-sm-3" id="start_date" v-model="form.start_date"
                            placeholder="Inserisci una data..." required>
                    </div>
                </div>

                <!-- data di fine (end) -->
                <div class="form-group row">
                    <label for="end_date" class="col-sm-2 col-form-label">Data di fine<label style="color: red;">*</label></label>
                    <div class="col-sm-10">
                        <input type="datetime-local" class="form-control mb-sm-3" id="end_date" v-model="form.end_date"
                            placeholder="Inserisci una data..." required>
                    </div>
                </div>


                <!-- relativa ai punteggi -->
                <!-- 
                    componente che fa scegliere in base ai dati di una api
               
                <div class="form-group row"> <label for="redSteps" class="col-sm-2 col-form-label">Steps red<label style="color: red;">*</label></label> <div class="col-sm-10"> <v-autocomplete id="redSteps" v-model="redSteps" :items="sortedAttacks" item-props="{value: 'id', text: 'name'}" placeholder="Seleziona la sequenza di passi che il rosso deve eseguire" multiple clearable v-if="mitre_atks.length > 0" ></v-autocomplete> </div> </div> 
                -->

                <h3>Squadre</h3>

                <!-- Create search bar to add team to an exercitation -->
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Cerca squadra" aria-label="Cerca squadra"
                        aria-describedby="button-addon2" v-model="teamQuery">
                    <button class="btn btn-outline-secondary" type="button" id="button-addon2" ref="btnTeamSearch"
                        @click="searchTeam()">Cerca</button>
                </div>
                <div class="form-group">
                    <!-- if added_teams_names length is empty then show an appropriate message -->
                    <button class="btn btn-secondary btn-sm disabled" v-if="added_teams_names.length == 0">Nessuna
                        squadra aggiunta</button>

                   <!-- else show the added teams -->
                   <span v-for="name in added_teams_names" :key="name">
                        <button type="button" class="btn btn-secondary btn-sm rounded bg-white text-dark"
                            @click="removeTeam(name)">{{ name }} <svg class="feather">
                                <use href="/feather-sprite-v4.29.0.svg#x" />
                            </svg></button>
                        <!-- space between buttons -->
                        <span>&nbsp;</span>
                    </span>
                </div>

                <!-- space -->
                <span>&nbsp;</span>

                <table id="squadre" class="table table-striped table-bordered table-hover">
                    <thead class="thead-dark">
                        <th scope="col">ID</th>
                        <th scope="col">Nome</th>
                        <th scope="col">Ruolo</th>
                        <th scope="col"></th>
                    </thead>
                    <tbody>
                        <tr v-for="team in filteredItems" v-bind:key="team.id" :id="'row' + '-' + team.id">
                            <td>{{ team.id }}</td>
                            <td>{{ team.name }}</td>
                            
                            <!-- ruolo se rosso allora visualizza il ruolo color rosso altrimenti blu -->
                            <td v-if="team.role == 'Red'">
                                <p class="text-danger">{{ team.role }}</p>
                            </td>
                            <td v-else>
                                <p class="text-primary">{{ team.role }}</p>
                            </td>

                            <td>
                                <button class="btn btn-success"
                                    @click="addTeam(team.id)">Aggiungi</button>
                                <!-- space between buttons -->
                                <span>&nbsp;</span>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div class="alert alert-danger" role="alert" id="noResults" style="display: none;">
                    Nessun risultato
                </div>
            </form>

               <!-- Bottoni -->
                <div class="form-group row">
                    <div class="col-sm-12">
                        <button class="btn btn-outline-danger mb-2" @click="openAttackModal">Attack Ideal Path</button>
                    </div>
                    <div class="col-sm-12">
                        <button type="button" class="btn btn-outline-primary" @click="openDefenceModal">Defense Ideal Path</button>
                    </div>
                </div>

                <div>
                <!-- 'active' all'overlay quando il frame è aperto -->
                <div class="overlay" :class="{ active: showIdealPathAttackForm || showIdealPathDefenceForm }"></div>

                <div v-if="showIdealPathAttackForm" class="overlay-frame">
                    <div class="overlay-content">
                        <span class="close" @click="closeModal">×</span>
                        <!-- Contenuto del frame in sovraimpressione -->
                        <div class="content-container" :style="{ maxHeight: modalHeight + 'px' }">
                            <h1 class="h2">Ideal Path Attacco</h1>
                            <!-- Aggiungi qui gli altri elementi della modal -->
                            <div class="form-group row">
                                <!-- Tattica -->
                                <div class="col-md-12 mb-3">
                                    <div class="input-group">
                                        <label for="tactic" class="col-form-label input-group-text">Tattica     
                                            <label style="color: red;">*</label>
                                        </label>
                                        <input type="text" class="form-control" id="mitreTacticId" v-model="form.mitre_tactic_id"
                                            placeholder="Cerca una tattica dal db mitre..." @input="getAttackSuggestions('tactic')"
                                            v-if="!selectedTacticName" />
                                        <div class="suggestions" v-if="tacticSuggestions.length > 0">
                                            <ul>
                                                <li v-for="(t, index) in tacticSuggestions" :key="index" @click="setSelectedAttackTactic(t)">
                                                    {{ t.tactic }}
                                                </li>
                                            </ul>
                                        </div>
                                        <div v-else>
                                            <p style="padding-top:8px"><strong>{{ selectedTacticName }}</strong></p>
                                        </div>
                                        <!-- Pulsante di reset per la Tattica -->
                                        <button class="btn btn-outline-danger btn-sm ml-2" @click="resetTacticField">Reset</button>
                                    </div>
                                </div>
                                <!-- Tecnica -->
                                <div class="col-md-12 mb-3">
                                    <div class="input-group">
                                        <label for="mitreTechniqueId" class="col-form-label input-group-text">Tecnica     
                                            <label style="color: red;">*</label>
                                        </label>
                                        <input type="text" class="form-control" id="mitreTechniqueId" v-model="mitre_technique_attack_id"
                                            placeholder="Cerca un attacco nel db mitre..." @input="getAttackSuggestions('technique')"
                                            v-show="!selectedTechniqueName" />
                                        <div class="suggestions" v-if="suggestions.length > 0">
                                            <ul>
                                                <li v-for="(suggestion, index) in suggestions" :key="index" @click="setSelectedAttackTechnique(suggestion)">
                                                    {{ suggestion.name }}
                                                </li>
                                            </ul>
                                        </div>
                                        <div v-else>
                                            <p style="padding-top: 7px;"><strong>{{ selectedTechniqueName }}</strong></p>
                                            <div v-html="selectedTechniqueDescription"></div>
                                        </div>
                                        <!-- Pulsante di reset per la Tecnica -->
                                        <button class="btn btn-outline-danger btn-sm ml-2" @click="resetTechniqueField">Reset</button>
                                    </div>
                                </div>
                                <!-- Target -->
                                <div class="col-md-12 mb-3">
                <!-- Target -->
                <div class="col-md-12 mb-3">
                    <div class="input-group">
                        <label for="target" class="col-form-label input-group-text">Target
                            <label style="color: red;">*</label>
                        </label>
                        <input type="text" class="form-control" id="target" v-model="form.target" placeholder="Inserisci il target..." required @input="getTargetSuggestions" v-if="targetInput">
                        <!-- Suggerimenti per il campo "Target" -->
                        <div class="suggestions" v-show="targetSuggestionsVisible && targetSuggestions.length > 0">
                            <ul>
                                <li v-for="(target, index) in targetSuggestions" :key="index" @click="setSelectedTarget(target)">
                                    {{ target }}
                                </li>
                            </ul>
                        </div>
                        <!-- Mostra il testo selezionato solo se è un suggerimento valido -->
                        <div v-if="!targetSuggestionsVisible && form.target && targetSuggestions.includes(form.target)">
                            <p style="padding-top: 7px; font-weight: bold;">{{ form.target }}</p>
                        </div>
                        <!-- Pulsante di reset per il Target -->
                        <button class="btn btn-outline-danger btn-sm ml-2" @click="resetTargetField">Reset</button>
                    </div>
                </div>
            </div>

                                
                            </div>
                            <!-- Bottone "Aggiungi Attacco" sulla destra -->
                            <button class="btn btn-outline-danger" @click="addAttack">Aggiungi Attacco</button>
                            <div>
                                <table class="table table-striped mt-3">
                                    <thead>
                                        <tr>
                                            <th scope="col">Tattica</th>
                                            <th scope="col">Tecnica</th>
                                            <th scope="col">Target</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="(data, index) in tableDataAttack" :key="index">
                                            <td @click="editField(index, 'tactic')" :contenteditable="data.editable === 'tactic'">{{ data.tactic }}</td>
                                            <td @click="editField(index, 'technique')" :contenteditable="data.editable === 'technique'">{{ data.technique }}</td>
                                            <td @click="editField(index, 'target')" :contenteditable="data.editable === 'target'">{{ data.target }}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <!-- Bottone "Resetta" -->
                                <button class="btn btn-outline-danger" @click="confirmReset">Resetta</button>
                                <div class="ml-auto">
                                    <!-- Bottone "Genera Reference Graph" -->
                                    <button class="btn btn-success" v-if="tableDataAttack.length > 0" @click="handleGenerateChartClick">Genera Grafico</button>
                                </div>
                                <!-- Sezione ADTree -->
                            </div>
                            <div v-if="tableDataAttack.length > 0" style="overflow: auto;">
                                <canvas id="myChart" width="400" height="400"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                <!-- Modale Defence Ideal Path -->
                <div v-if="showIdealPathDefenceForm" class="overlay-frame">
                    <div class="overlay-content">
                        <span class="close" @click="closeModal">×</span>
                        <!-- Contenuto del frame in sovraimpressione per la difesa -->
                        <div>
                            <h1 class="h2">Ideal Path Difesa</h1>
                        </div>
                        <!-- <div class="form-group row">
                            <label for="mitre_alleged_technique_id" class="col-sm-2 col-form-label">Presunto attacco
                            <label style="color: red;">*</label>
                            </label>
                            <div class="col-sm-10">
                            <input type="text" class="form-control mb-sm-3" id="mitre_alleged_technique_id"
                                v-model="mitre_technique_id" placeholder="Cerca un attacco..." required
                                @input="getSuggestions('technique')" v-if="!selectedTecniqueName" />
                            <div class="suggestions" v-if="this.techniqueSuggestions.length > 0">
                                <ul>
                                <li v-for="(suggestion, index) in techniqueSuggestions" :key="index"
                                    @click="setSelectedTecnique(suggestion)">
                                    {{ suggestion.name }}
                                </li>
                                </ul>
                            </div>
                            <div v-else>
                                <p style="padding-top: 7px;"><strong>{{ selectedTecniqueName }}</strong></p>
                                <div v-html="selectedTecniqueDescription"></div>
                            </div>
                            </div>
                        
                         detection

                        <label for="mitreDetectionId" class="col-sm-2 col-form-label">Detection
                            <label style="color: red;">*</label>
                        </label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control mb-sm-3" id="mitreDetectionId" v-model="this.mitre_detection_id"
                            placeholder="Cerca una detection..." required @input="getSuggestions('detection')"
                            v-if="!selectedDetectionName" />
                            <div class="suggestions" v-if="detectionSuggestions.length > 0">
                            <ul>
                                <li v-for="(suggestion, index) in detectionSuggestions" :key="index" @click="setSelectedDetection(suggestion)">
                                {{ suggestion.name }}
                                </li>
                            </ul>
                            </div>
                            <div v-else>
                            <p style="padding-top: 7px;"><strong>{{ selectedDetectionName }}</strong></p>
                            </div>
                        </div>

                        mitigation

                        <label for="mitreMitigationId" class="col-sm-2 col-form-label">Mitigation
                            <label style="color: red;">*</label>
                        </label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control mb-sm-3" id="mitreMitigationId" v-model="this.mitre_mitigation_id"
                            placeholder="Cerca una mitigation..." required @input="getSuggestions('mitigation')"
                            v-if="!selectedMitigationName" />
                            <div class="suggestions" v-if="mitigationSuggestions.length > 0">
                            <ul>
                                <li v-for="(suggestion, index) in mitigationSuggestions" :key="index" @click="setSelectedMitigation(suggestion)">
                                {{ suggestion.name }}
                                </li>
                            </ul>
                            </div>
                            <div v-else>
                            <p style="padding-top: 7px;"><strong>{{ selectedMitigationName }}</strong></p>
                            <div v-html="selectedMitigationDescription"></div>
                            </div>
                        </div> 
                        </div>  -->
                        
                        <div>
                            <!-- Tabella editabile -->
                                <table class="table table-striped mt-3">
                                <thead>
                                    <tr>
                                        <th scope="col">Tattica</th>
                                        <th scope="col">Tecnica</th>
                                        <th scope="col">Target</th>
                                        <th scope="col">Detection</th>
                                        <th scope="col">Mitigazione</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Itera attraverso ogni attacco in tableDataAttack -->
                                    <tr v-for="(attack, index) in tableDataAttack" :key="index">
                                        <!-- Colonna della Tattica -->
                                        <td>{{ attack.tactic }}</td>
                                        <!-- Colonna della Tecnica -->
                                        <td>{{ attack.technique}}</td>
                                        <!-- Colonna del Target -->
                                        <td>{{ attack.target}}</td>
                                        <!-- Colonna della Migliore Detection -->
                                        <td>{{ attack.bestDetection }}</td>
                                        <!-- Colonna della Migliore Mitigazione -->
                                        <td>{{ attack.bestMitigation }}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div></div>
                        <div class="col-sm-12">
                                <button type="button" class="btn btn-outline-primary" @click="getSuggestionsDetectionAndMitigation" v-if="tableDataAttack.length>0">Calcola Difesa Ideale</button>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                          <!--   <div>
                                <Bottone "Resetta" 
                                <button class="btn btn-outline-danger" @click="confirmDefReset">Resetta</button>
                            </div> -->
                            <div  class="ml-auto">
                                <!-- Bottone "Genera Response Graph" -->
                                <button class="btn btn-success" v-if="tableData.length>0" @click="confirmResponseGenerate">Genera Response Graph</button>
                            </div>
                            <div v-if="tableData.length > 0">
                            <ADTree :data="tableData"></ADTree>
                        </div>
                        </div>
                    </div>
                </div>

                <!-- Modale di conferma per il reset -->
                <div v-if="showResetConfirmation" class="overlay-frame">
                    <div class="overlay-content">
                        <span class="close" @click="cancelReset">×</span>
                        <h3>Sei sicuro di voler resettare?</h3>
                        <button class="btn btn-outline-danger" @click="resetDefence">Conferma</button>
                        <button class="btn btn-outline-secondary" @click="cancelReset">Annulla</button>
                    </div>
                </div>

                <!-- Modale di conferma per la generazione -->
                <div v-if="showGenerateConfirmation" class="overlay-frame">
                    <div class="overlay-content">
                        <span class="close" @click="cancelGenerate">×</span>
                        <h3>Sei sicuro di voler generare il Response Graph?</h3>
                        <button class="btn btn-outline-primary" @click="generateResponseGraph">Conferma</button>
                        <button class="btn btn-outline-secondary" @click="cancelGenerate">Annulla</button>
                    </div>
                </div>


                <div class="form-group d-flex mr-2 justify-content-end flex-row">
                    <!-- Cancel button go back to the previous view in vuejs-->
                    <button @click.prevent="$router.push('/exercitations')" class="btn btn-secondary"
                        style="margin-right:10px">Annulla</button>
                    <button value="Submit" @click="sendExercitation()" class="btn btn-primary"
                        ref="btnSalva">Salva</button>
                </div>
        </div>
    </div>
</template>

<script>
import { marked } from 'marked';
import Chart from 'chart.js/auto';
import ADTree from "@/components/ADTree.vue";
export default {
    data() {
        return {
            modalHeight: 500,
            targetInput: true,
            targetSuggestionsVisible: false,
            showIdealPathAttackForm: false, // auto open idealpath attack modal
            showIdealPathDefenceForm: false, // auto open idealpath defence modal
            targetTextVisible: false,
            redSteps: [],
            blueSteps: [],
            teqs: [],
            tableDataAttack: [],
            tableData: [],
            mitre_atks: [],
            detections: [],
            mitigations: [],
            originalTargetSuggestions: [
            'Server',
            'Database',
            'Applicazione',
            'Sistema Operativo',
            'Dispositivo di Rete',
            'Dispositivo IoT',
            'Client Email',
            'Servizio Cloud',
            'Dispositivo di Archiviazione',
            'Workstation',
            'Firewall',
            'Proxy Server',
            'IDS (Intrusion Detection System)',
            'IPS (Intrusion Prevention System)',
            'Web Server',
            'FTP Server',
            'DNS Server',
            'DHCP Server',
            'SMTP Server',
            'SSH Server'
        ],
            showGenerateConfirmation: false, 
            form: {
                name: '',
                start_date: '',
                end_date: '',
                redStepsIds: [],
                mitre_tactic_id: '',
                exercitation_id: this.$route.params.id,
                target: '',
                techniques: [],
                attackTechniques: [],
                mitre_alleged_technique_id: '',
                detections: null,
                mitigations: null,
                tecdetmit: [],
            },
            teamQuery: '',
            added_teams: [],
            added_teams_names: [],
            teams: [],
            mitre_technique_id: '',
            mitre_technique_attack_id: '',
            subSuggestions: [],
            mitre_subtechnique_id: '',
            selectedTechniqueName: '',
            selectedTacticName: '',
            selectedTechniqueDescription: '',
            searchResults: [],
            suggestions: [],
            subSuggestions: [],
            tacticSuggestions: [],
            mitre_detection_id: '',
            mitre_mitigation_id: '',
            selectedTecniqueName: '',
            selectedTecniqueDescription: '',
            selectedDetectionName: '',
            selectedMitigationName: '',
            selectedMitigationDescription: '',
            techniqueSuggestions: [],
            detectionSuggestions: [],
            mitigationSuggestions: [],
        }
    },
     created() {
    // Assegna la lista completa di suggerimenti a originalTargetSuggestions
    this.originalTargetSuggestions = [/* inserisci qui la lista completa di suggerimenti */];
    },
    computed: {
        filteredItems() {
            return this.teams.filter(team => {
                // if team is not in the added_teams array, return it
                if (!this.added_teams.includes(team.id)) {
                    return team.id
                }
            })
        },
        sortedAttacks() {
            return this.mitre_atks.sort((a, b) => {
                return a.technique_id.localeCompare(b.technique_id)
            })
        }
    },
    methods: {
    
   // Metodo per ottenere sia le detections che le mitigations
    getSuggestionsDetectionAndMitigation() {
        this.getSuggestionDetections();
        this.getSuggestionMitigations();
    },

    // Metodo per ottenere le detections dal server
    getSuggestionDetections() {
        const url = '/mitre/datasources';

        this.$axios
            .get(url)
            .then(response => {
                this.detections = response.data;
                this.populateTableData();
            })
            .catch(error => {
                console.error('Errore nel recupero delle detections:', error);
            });
    },

    // Metodo per ottenere le mitigations dal server
    getSuggestionMitigations() {
        const url = '/mitre/mitigations';

        this.$axios
            .get(url)
            .then(response => {
                this.mitigations = response.data;
                this.populateTableData();
            })
            .catch(error => {
                console.error('Errore nel recupero delle mitigations:', error);
            });
    },

    // Metodo per trovare la migliore detection per un attacco
    findBestDetectionForAttack(attack, detections) {
        let bestDetection = null;
        let maxScore = -1;

        // Ciclo attraverso tutte le detections nel dataset
        detections.forEach(detection => {
            // Calcolo dello score per questa detection e questo attacco
            const score = this.calculateDetectionScore(attack, detection);

            // Se lo score è maggiore del massimo registrato finora, aggiorno i valori
            if (score > maxScore) {
                maxScore = score;
                bestDetection = detection;
            }
        });

        return bestDetection;
    },

    // Metodo per trovare la migliore mitigazione per un attacco
    findBestMitigationForAttack(attack, mitigations) {
        let bestMitigation = null;
        let maxScore = -1;

        // Ciclo attraverso tutte le mitigations nel dataset
        mitigations.forEach(mitigation => {
            // Calcolo dello score per questa mitigazione e questo attacco
            const score = this.calculateMitigationScore(attack, mitigation);

            // Se lo score è maggiore del massimo registrato finora, aggiorno i valori
            if (score > maxScore) {
                maxScore = score;
                bestMitigation = mitigation;
            }
        });

        return bestMitigation;
    },

    // Metodo per trovare le migliori detection e mitigations per ogni attacco
    findBestDetectionAndMitigationForEachAttack(tableDataAttack, detections, mitigations) {
        // Ciclo attraverso ogni attacco in tableDataAttack
        tableDataAttack.forEach(attack => {
            // Trovo la migliore detection per questo attacco
            const bestDetection = this.findBestDetectionForAttack(attack, detections);

            // Trovo la migliore mitigazione per questo attacco
            const bestMitigation = this.findBestMitigationForAttack(attack, mitigations);

            // Aggiungo le migliori detection e mitigations agli attributi dell'attacco
            attack.bestDetection = bestDetection;
            attack.bestMitigation = bestMitigation;
        });
    },

    // Funzione per popolare tableData con le migliori detection e mitigations
    populateTableData() {
        // Assicurati che tableDataAttack, detections e mitigations siano disponibili
        if (this.tableDataAttack && this.detections && this.mitigations) {
            // Cicla attraverso ogni attacco in tableDataAttack
            this.tableData = this.tableDataAttack.map(attack => {
                // Trova la migliore detection per questo attacco
                const bestDetection = this.findBestDetectionForAttack(attack, this.detections);

                // Trova la migliore mitigazione per questo attacco
                const bestMitigation = this.findBestMitigationForAttack(attack, this.mitigations);

                // Aggiungi le migliori detection e mitigations agli attributi dell'attacco
                attack.bestDetection = bestDetection ? bestDetection.name : '';
                attack.bestMitigation = bestMitigation ? bestMitigation.name : '';

                // Ritorna un oggetto con i dati necessari per la tabella
                return {
                    tattica: attack.tactic || '', 
                    tecnica: attack.technique || '',
                    bestDetection: attack.bestDetection || '',
                    bestMitigation: attack.bestMitigation || ''
                };
            });
        }
    },


// Funzione per calcolare lo score di una detection
calculateDetectionScore(attack, detection) {
    // Estrai la descrizione della tecnica dall'attacco e la descrizione della detection
    const attackTechniqueDescription = attack.techniqueDescription.toLowerCase();
    const detectionDescription = detection.description.toLowerCase();

    // Controlla se ci sono parole chiave comuni tra la descrizione della detection e la descrizione della tecnica dell'attacco
    const commonWords = attackTechniqueDescription.split(' ').filter(word => detectionDescription.includes(word));

    // Restituisci il numero di parole chiave comuni come score
    return commonWords.length;
},

// Funzione per calcolare lo score di una mitigazione
calculateMitigationScore(attack, mitigation) {
    // Estrai la descrizione della tecnica dall'attacco e la descrizione della mitigazione
    const attackTechniqueDescription = attack.techniqueDescription.toLowerCase();
    const mitigationDescription = mitigation.description.toLowerCase();

    // Controlla se ci sono parole chiave comuni tra la descrizione della mitigazione e la descrizione della tecnica dell'attacco
    const commonWords = attackTechniqueDescription.split(' ').filter(word => mitigationDescription.includes(word));

    // Restituisci il numero di parole chiave comuni come score
    return commonWords.length;
},



         // Funzione per abilitare la modifica della cella selezionata
    editField(index, field) {
        // Imposta la cella come modificabile
        this.tableDataAttack.forEach((data, i) => {
            if (i === index) {
                data.editable = field;
            } else {
                data.editable = null;
            }
        });
    },

    // Funzione per aggiornare i dati della cella modificata
    updateField(index, field, event) {
        this.tableDataAttack[index][field] = event.target.innerText;
        this.tableDataAttack[index].editable = null; // Disabilita la modifica
        
    },

        resetTacticField() {
            this.form.mitre_tactic_id = '';
            this.selectedTacticName = '';
            this.tacticSuggestions = [];
        },
        resetTechniqueField() {
            this.mitre_technique_attack_id = '';
            this.selectedTechniqueName = '';
            this.selectedTechniqueDescription = '';
            this.suggestions = [];
        },

        getAttackSuggestions(type) {
      const searchValue = type === 'technique' ? this.mitre_technique_attack_id.trim() : this.form.mitre_tactic_id.trim();
      const url = type === 'technique' ? '/mitre/techniques/all' : '/mitre/tactics';
      const suggestionsArray = type === 'technique' ? this.suggestions : this.tacticSuggestions;

      if (searchValue !== '') {
        this.$axios
          .get(url)
          .then(response => {
            const data = response.data;

            const filteredData = data.filter(item => {
              const itemName = type === 'technique' ? item.name.toLowerCase() : item.tactic.toLowerCase();
              return itemName.includes(searchValue.toLowerCase());
            });

            suggestionsArray.splice(0, suggestionsArray.length, ...filteredData);
          })
          .catch(error => {
            console.log(error);
          });
      } else {
        suggestionsArray.splice(0, suggestionsArray.length);
      }
    },
    setSelectedAttackTactic(mitreTactic) {
      this.form.mitre_tactic_id = mitreTactic.id;
      this.selectedTacticName = mitreTactic.tactic;
      this.tacticSuggestions = [];
    },
    setSelectedAttackTechnique(mitreAttack) {
      this.selectedTechniqueName = mitreAttack.name;
      this.mitre_technique_id = '';
      this.selectedTechniqueDescription = marked(mitreAttack.description.replace(/\(Citation:.*?\)/g, ''));
      this.form.attackTechniques= [mitreAttack];
      
      this.suggestions = [];
    },
        // Mostra il popup di conferma per il reset
        confirmReset() {
        if (window.confirm("Sei sicuro di voler resettare?")) {
            // Pulisci il canvas quando viene eseguito il reset
            const ctx = document.getElementById('myChart').getContext('2d');
            ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
      
            this.tableDataAttack = [];
            this.tableData = [];
        }
        },

        getTargetSuggestions() {
            const inputText = this.form.target.trim().toLowerCase();

            // Controlla se l'input dell'utente è vuoto
            if (inputText === '') {
                // Se l'input è vuoto, visualizza l'intera lista di suggerimenti
                this.targetSuggestions = this.originalTargetSuggestions.slice();
            } else {
                // Altrimenti, filtra i suggerimenti in base all'input dell'utente
                this.targetSuggestions = this.originalTargetSuggestions.filter(target => {
                    return target.toLowerCase().includes(inputText);
                });
            }

            // Imposta la visibilità dei suggerimenti
            this.targetSuggestionsVisible = inputText !== '' && this.targetSuggestions.length > 0;
        },

        setSelectedTarget(target) {
            this.form.target = target;
            this.targetSuggestionsVisible = false; // Nasconde i suggerimenti quando viene selezionato un target
            // Mostra il testo selezionato
            this.targetTextVisible = true;
            this.targetInput = false;
        },  
        resetTargetField() {
            this.form.target = ''; // Resetta il campo "Target"
            this.targetSuggestionsVisible = false; // Nasconde i suggerimenti quando il campo viene resettato
            this.targetTextVisible = false;
            this.targetInput = true;
        },

        confirmDefReset() {
        if (window.confirm("Sei sicuro di voler resettare?")) {
            // Aggiungi qui la logica per il reset
            this.tableData = [];
        }
        },

        confirmGenerate() {
            if (window.confirm("Sei sicuro di voler generare il Response Graph?")) {
                this.showADTree = true;
                this.dataForADTree = this.tabledataAttack; // Utilizza i dati già presenti
                alert("Reference Graph generato con successo.");
            }
        },

        confirmDefGenerate() {
            if (window.confirm("Sei sicuro di voler generare il Response Graph?")) {
                this.showADTree = true;
                this.dataForADTree = this.tabledata; // Utilizza i dati già presenti
                alert("Response Graph generato con successo.");
            }
        },

        openAttackModal() {
            this.showIdealPathAttackForm = true;
        },
        openDefenceModal() {
            this.showIdealPathDefenceForm = true;
        },
        closeModal() {
        this.showIdealPathAttackForm = false;
        this.showIdealPathDefenceForm = false;
        },

        searchTeam() {
            // call the route search from api to get the team where kind = team and name = name got from input team
            this.$axios
                // TODO: refactor: cambiare la route in /teams/search?name=teamQuery
                //.get('/search' + '?kind=team' + '&name=' + this.teamQuery)
                .get('/search?kind=teams&name=' + this.teamQuery.toString())
                .then(response => {
                    // se response.data.results.length == 0 allora assegna a teams l'array vuoto
                    if (response.data.metadata.total == 0) {
                        this.teams = []
                        // nascondi la tabella delle squadre
                        document.getElementById('squadre').style.display = 'none'

                        // mostra il messaggio di errore "nessuna squadra trovata"
                        document.getElementById('noResults').style.display = 'block'
                    } else {
                        // altrimenti assegna a teams l'array di teams ottenuto dalla ricerca
                        this.teams = response.data.results

                        // mostra la tabella delle squadre - rimuovi l'attributo style
                        document.getElementById('squadre').removeAttribute('style')
                        document.getElementById('noResults').style.display = 'none'
                    }
                })
                .catch(error => {
                    this.errored = true
                }).finally(() => this.loading = false)
        },
sendExercitation() {
    let exercitationId; // Declare exercitationId variable

    // First POST request to create the exercitation
    this.$axios
        .post('/exercitations', this.form)
        .then(response => {
            // Memorizza l'ID dell'esercitazione appena creata
            exercitationId = response.data.id; // Store the exercitationId
            let idealPathElements = this.tableDataAttack.map(attack => {
                return {
                    Tecnica: attack.technique,
                    Tattica: attack.tactic,
                    Target: attack.target,
                    Detection: attack.bestDetection,
                    Mitigation: attack.bestMitigation,
                    ExercitationID: exercitationId
                };
            });

            // Invia tutti gli elementi dell'Ideal Path al backend in una sola volta
            return this.$axios.post(`/exercitations/${exercitationId}/idealpath`, idealPathElements);
        })
        .then(response => {
            // for each team id in the added_teams array, make a post request to add the team to the exercitation by using the endpoint /exercitations/{exercitation_id}/teams/ and team_id is in the body as json
            this.added_teams.forEach(team_id => {
                this.$axios.post(`/exercitations/${exercitationId}/teams/${team_id}`)
                    .then(response => {
                        // if the post is successful, redirect to the exercitations view
                        if (response.status === 200 && team_id === this.added_teams[this.added_teams.length - 1]) {
                            alert('Esercitazione creata con successo.');
                            // redirect to the exercitations view
                            this.$router.push('/exercitations');
                        }
                    })
                    .catch(error => {
                        console.log(error);
                        this.errored = true;
                    })
                    .finally(() => {
                        this.loading = false;
                    });
            });
        })
        .catch(error => {
            console.log(error);
            this.errored = true;
        }).finally(() => this.loading = false);
},



        addTeam(team_id) {
            // add the team to the list of added teams
            this.added_teams.push(team_id)

            // add the team name to the list of added teams names
            this.added_teams_names.push(this.teams.find(team => team.id == team_id).name)

            // remove the team from the list of teams
            this.teams = this.teams.filter(team => team.id != team_id)
        },
        removeTeam(name) {
            // find out the index of the team in the list of added teams
            let index = this.added_teams_names.indexOf(name)

            // remove the team from the list of added teams names
            this.added_teams_names.splice(index, 1)

            // remove the id of the team from the list of added teams
            this.added_teams.splice(index, 1)

        },

        addAttack() {
            if (this.form.mitre_tactic_id !== '' &&
                this.mitre_technique_id !== '' &&
                this.form.target == '') {
                alert("Per favore, compila tutti i campi richiesti.");
                return;
            }

            // Aggiungi l'attacco all'array di techniques
            this.form.attackTechniques.push({
                tactic: this.selectedTacticName,
                technique: this.selectedTechniqueName,
                target: this.form.target
            });

            // Aggiungi l'attacco a tableData
            this.tableDataAttack.push({
                tactic: this.selectedTacticName,
                technique: this.selectedTechniqueName,
                target: this.form.target,
                techniqueDescription: this.selectedTechniqueDescription,
            });

            // Resetta i campi
            this.form.mitre_tactic_id = '';
            this.mitre_technique_attack_id = '';
            this.form.target = '';

            // Azzeramento delle variabili
            this.selectedTacticName = ''; // Azzeramento della tattica selezionata
            this.selectedTechniqueName = ''; // Azzeramento della tecnica selezionata
            this.selectedTechniqueDescription = '';
            this.targetInput = true;
            this.form.atttackTechniques  = [];
             // Aumenta l'altezza della modal di 500 pixel
            this.modalHeight += 500;

            alert('Attacco aggiunto con successo.');
        },

     addDefence() {
        // Controllo se tutti i campi richiesti sono stati compilati
        if (this.mitre_technique_id === '' || this.mitre_detection_id === '' || this.mitre_mitigation_id === '') {
            alert("Per favore, compila tutti i campi richiesti.");
            return;
        }

        // Aggiungi la difesa alla tabella dei dati
        this.tableData.push({
            tactic: this.selectedTacticName,
            technique: this.selectedTecniqueName,
            detection: this.selectedDetectionName,
            mitigation: this.selectedMitigationName,
        });

        // Resetta i campi e le etichette
        this.mitre_technique_id = '';
        this.mitre_detection_id = '';
        this.mitre_mitigation_id = '';
        this.selectedTacticName = '';
        this.selectedTecniqueName = ''; // Resetta anche il campo del presunto attacco
        this.selectedTecniqueDescription = '';
        this.selectedDetectionName = '';
        this.selectedMitigationName = '';
        this.selectedMitigationDescription = '';

        // Messaggio di conferma
        alert('Difesa aggiunta con successo.');
    },




        getSuggestions(type) {
        const searchValue = type === 'technique' ? this.mitre_technique_id.trim() :
                            type === 'detection' ? this.mitre_detection_id.trim() :
                            this.mitre_mitigation_id.trim();
        const url = type === 'technique' ? '/mitre/techniques/all' :
                    type === 'detection' ? '/mitre/datasources' :
                    '/mitre/mitigations';

        if (searchValue !== '') {
            this.$axios
            .get(url)
            .then(response => {
                const data = response.data;
                const filteredData = data.filter(item => {
                const itemName = type === 'tactic' ? item.tactic.toLowerCase() : item.name.toLowerCase();
                return itemName.includes(searchValue.toLowerCase());
                });
                this[type + 'Suggestions'].splice(0, this[type + 'Suggestions'].length, ...filteredData);
            })
            .catch(error => {
                console.log(error);
            });
        } else {
            this[type + 'Suggestions'].splice(0, this[type + 'Suggestions'].length);
        }
        },
        setSelectedTecnique(mitreTecnique) {
        this.selectedTecniqueName = mitreTecnique.name;
        this.selectedTecniqueDescription = marked(mitreTecnique.description.replace(/\(Citation:.*?\)/g, '').replace(/<code>.*?<\/code>/g, ''));
        this.techniqueSuggestions = [];
        this.form.techniques = [mitreTecnique];
        },
        setSelectedDetection(mitreDetection) {
        this.selectedDetectionName = mitreDetection.name;
        this.selectionDetectionDescription = marked(mitreDetection.description.replace(/\(Citation:.*?\)/g, ''));
        this.form.detections = mitreDetection;
        this.detectionSuggestions = [];
        },
        setSelectedMitigation(mitreMitigation) {
        this.selectedMitigationName = mitreMitigation.name;
        this.selectedMitigationDescription = marked(mitreMitigation.description.replace(/\(Citation:.*?\)/g, '').replace(/<code>.*?<\/code>/g, ''));
        this.form.mitigations = mitreMitigation;
        this.mitigationSuggestions = [];
        },
        saveThings() {
        if (this.form.techniques && (this.form.detections || this.form.mitigations)) {
            this.form.tecdetmit.push({ technique: this.form.techniques, detection: this.form.detections, mitigation: this.form.mitigations });
        } else {
            alert("Inserire almeno un presunto attacco ed una detection o una mitigation");
        }

        this.mitre_technique_id = '';
        this.mitre_detection_id = '';
        this.mitre_mitigation_id = '';
        this.form.techniques = null;
        this.form.detections = null;
        this.form.mitigations = null;
        },

    // Funzione per generare il grafico a barre con scorrimento verso il basso
    generateBarChart() {
        // Recupera il canvas HTML dal DOM
        const canvas = document.getElementById('myChart');
        const ctx = canvas.getContext('2d');

        // Cancella il canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Definisci le posizioni dei nodi
        const nodes = this.tableDataAttack.map((data, index) => {
        return { x: 100, y: 100 + index * 150, data: data }; // Posizione arbitraria per ogni nodo
        });

        // Calcola l'altezza del canvas in base al numero di nodi
        const canvasHeight = Math.max(canvas.height, nodes[nodes.length - 1].y + 100);

        // Imposta l'altezza del canvas
        canvas.height = canvasHeight;

        // Disegna i nodi
        nodes.forEach((node) => {
        this.drawNode(ctx, node);
        });

        // Disegna le frecce
        for (let i = 0; i < nodes.length - 1; i++) {
        this.drawArrow(ctx, nodes[i], nodes[i + 1]);
        }
    },

    // Funzione per disegnare un nodo
    // Funzione per disegnare un nodo
    drawNode(ctx, node) {
    const textPaddingX = 10; // Padding orizzontale per il testo
    const textPaddingY = 20; // Padding verticale per il testo
    const lineHeight = 20; // Altezza della linea per il testo

    // Testo per ogni campo
    const tacticText = "Tattica: " + node.data.tactic;
    const techniqueText = "Tecnica: " + node.data.technique;
    const targetText = "Target: " + node.data.target;

    // Calcola la lunghezza massima del testo tra i campi
    const maxTextWidth = Math.max(
        ctx.measureText(tacticText).width,
        ctx.measureText(techniqueText).width,
        ctx.measureText(targetText).width
    );

    // Larghezza dell'etichetta (in questo caso, consideriamo che ogni etichetta abbia la stessa larghezza)
    const labelWidth = ctx.measureText("Tattica: ").width;

    // Calcola la larghezza del rettangolo considerando sia il testo che l'etichetta
    const maxWidth = maxTextWidth + labelWidth + 2 * textPaddingX; // Aggiungi il padding orizzontale

    ctx.beginPath();
    ctx.fillStyle = '#ff9999'; // Colore del nodo
    ctx.fillRect(node.x, node.y, maxWidth, 100); // Dimensioni del nodo
    ctx.strokeRect(node.x, node.y, maxWidth, 100); // Bordi del nodo

    // Disegna il testo
    ctx.fillStyle = '#000'; // Colore del testo
    ctx.font = '12px Arial'; // Font del testo
    ctx.fillText(tacticText, node.x + textPaddingX, node.y + textPaddingY);
    ctx.fillText(techniqueText, node.x + textPaddingX, node.y + textPaddingY + lineHeight);
    ctx.fillText(targetText, node.x + textPaddingX, node.y + textPaddingY + 2 * lineHeight);
    },

    // Funzione per disegnare una freccia tra due nodi
    drawArrow(ctx, fromNode, toNode) {
        ctx.beginPath();
        ctx.moveTo(fromNode.x + 100, fromNode.y + 100); // Posizione iniziale della freccia (centro del nodo)
        ctx.lineTo(toNode.x + 100, toNode.y); // Posizione finale della freccia (parte alta del nodo successivo)
        ctx.strokeStyle = '#000'; // Colore della freccia
        ctx.stroke();
    },


        // Funzione per gestire il click sul bottone nella modale
        handleGenerateChartClick() {
        // Chiama la funzione per generare il grafico a barre
        this.generateBarChart();
        },
        },
        mounted() {
            this._keyListener = function (e) {
                if (e.key === "Enter") {
                    e.preventDefault();
                    this.$refs.btnTeamSearch.click()
                }
            };
            document.addEventListener('keydown', this._keyListener.bind(this));
        },
        beforeDestroy() {
            document.removeEventListener('keydown', this._keyListener);
        },
    
    created() {
        // utilizza l'API endpoint '/teams' per ottenere la lista dei team dal backend
        this.$axios.get('/teams')
            .then(response => {
                this.teams = response.data
            })
            .catch(error => {
                console.log(error)
            })

        this.$axios.get('/mitre/techniques').then(response => {
            this.mitre_atks = response.data

            // add a name property to each object in the array
            this.mitre_atks.forEach(atk => {
                atk.title = atk.name
            })
        })
    },
}   
</script>