<template>
  <div>
    <div v-if="time_left !== '00:00:00' && onGoingExercitation">
      <div class="display-1 text-center mb-5">{{ onGoingExercitation.name }}</div>
      <!-- line separator -->
      <v-divider></v-divider>
      <div class="display-2 mb-5 text-center">
        Tempo rimasto
        <div
          style="
            box-shadow: inset;
            border-radius: 10px;
            background-color: #f5f5f5;
          "
          v-if="onGoingExercitation"
        >
          {{ time_left }}
        </div>
      </div>
      <v-divider></v-divider>
      <div class="display-3 text-center mb-5">Squadre</div>
      <div class="container">
        <v-card :color="team.role === 'Red' ? 'error' : 'info'" v-for="team in onGoingExercitation.teams" :key="team.name" class="text-center">
          <v-card-title>{{ team.name }}</v-card-title>
        </v-card>
      </div>
      <v-divider></v-divider>
      <!-- se da mobile una colonna, altrimenti due colonne -->
      <div class="text-center display-3">Reference vs. Response Graph</div>
      <div id="alberi" v-if="exercitation && (reports && reports.length > 0 || blueReps && blueReps.length > 0)">
        <!-- reference graph -->
        <ADTree v-if="exercitation && reports && reports.length > 0" :exercitation-id="onGoingExercitation.id" :exercitation="exercitation" :reports="reports || []" :show-date="false"></ADTree>
        <div class="d-flex" style="height: 200px;">
          <div class="vr"></div>
        </div>
        <ADTree v-if="exercitation && blueReps && blueReps.length > 0" :exercitation-id="onGoingExercitation.id" :exercitation="exercitation" :reports="blueReps || []"></ADTree>
      </div>
      <p style="padding-top: 20px" v-else class="text-center">Niente da visualizzare (per ora)...</p>
      <br />
      <v-divider></v-divider>
      <div class="display-4 text-center mb-5">Cosa sta succedendo</div>
      <div v-if="onGoingExercitation && (reports.length > 0 || blueReps.length > 0)">
        <TimelineComponent v-if="onGoingExercitation && role !== ''" :exercitation-id="onGoingExercitation.id" :role="role"></TimelineComponent>
        <div v-else class="text-center">
          <div class="spinner-border" style="width: 10rem; height: 10rem" role="status">
            <span class="sr-only"></span>
          </div>
        </div>
      </div>
      <p style="padding-top: 20px" v-else class="text-center">Niente da visualizzare (per ora)...</p>
    </div>
    <!-- else mostriamo un messaggio "nessuna esercitazione in corso" -->
    <div v-else>
      <div class="display-2 text-center mb-5">Nessuna esercitazione in corso</div>
      <div class="text-center" style="margin-top: 10px;">Per ora...</div>
      <div class="desert">
        <div class="tumbleweed"></div>
      </div>
    </div>
    <div class="container-chat" v-if="onGoingExercitation">
    <div class="header">
        <span class="header-text">Chat: {{ currentChat }}</span>
    </div>
    <div class="main-content">
      <div class="user-list" id="user-list">
        <!-- Iterate over userList to display available chats -->
        <div v-for="user in userList" :key="user" class="user-list-item" @click="selectUser(user)" :class="{ selected: user === currentChat }">
          {{ user }}
          <span v-if="chatNotifications[user] > 0" class="notification-badge">{{ chatNotifications[user] }}</span>
        </div>
      </div>
      <div class="chat" id="chat">
        <div v-for="(message, index) in displayMessages(currentChat)" :key="index" :class="[message.class, 'message']">
          {{ message.text }}
        </div>
      </div>
    </div>
    <div class="input-container">
        <input type="text" id="message-input" placeholder="Scrivi il tuo messaggio...">
        <button @click="sendMessage()">Send</button>
    </div>
  </div>
  </div>
</template>

<script>
import TimelineComponent from "../components/TimelineComponent.vue";
import ADTree from "@/components/ADTree.vue";
import io from 'socket.io-client';

export default {
  data() {
    return {
      onGoingExercitation: null,
      socket: null,
      exercitation: null,
      loading: false,
      some_data: null,
      showModal: false,
      userId:"",
      nickname:"General",
      role: "",
      chatMessages: {}, // Object to store messages for each chat
      currentChat: "General", // Initialize current chat to "General"
      userList: [], // Array to store user list
      reports: [],
      timeDiff: 1,
      messages: [],
      newMessage: "",
      isExpanded: false,
      blueReps: [],
      showChatButton: true, // Initially show the chat button
      chatNotifications: {}
    };

    
  },


  methods: {

    async refresh() {
      this.loading = true;
      this.errormsg = null;
      try {
        let response = await this.$axios.get("/home");
        this.some_data = response.data;
      } catch (e) {
        this.errormsg = e.toString();
      }
      this.loading = false;
    },

    updateTimeLeft() {
      if (this.time_left !== "00:00:00") {
        const endDateTime = new Date(this.onGoingExercitation.end_date);
        const now = new Date();
        this.timeDiff = endDateTime - now;
        const secondsLeft = Math.floor((this.timeDiff / 1000) % 60);
        const minutesLeft = Math.floor((this.timeDiff / 1000 / 60) % 60);
        let hoursLeft =
          Math.floor((this.timeDiff / 1000 / 60 / 60) % 24) - 2;

        this.time_left = `${hoursLeft
          .toString()
          .padStart(2, "0")}:${minutesLeft
          .toString()
          .padStart(2, "0")}:${secondsLeft.toString().padStart(2, "0")}`;
      }
    },

    selectUser(user) {
      this.currentChat = user;
      this.chatNotifications[user] = 0;
    },
    // Metodo per caricare i messaggi salvati al caricamento della pagina
    loadSavedMessages() {
      const savedMessages = localStorage.getItem('chatMessages');
      if (savedMessages) {
        this.chatMessages = JSON.parse(savedMessages);
      }
    },

    connectToSocket() {
    // Connessione al server Socket.io
    this.socket = io('http://localhost:3001');

    this.socket.on('connect', () => {
      console.log("Invio del ruolo al server:", this.role);
      console.log("invio dell'id al server", this.userId);
      if (this.role === 'admin') {
      this.socket.emit('role',{ userId: this.userId, role: this.role});
      }
      else {
        this.role = this.nickname;
        console.log("Invio del ruolo al server:", this.nickname);
        this.socket.emit('role',{ userId: this.userId, role: this.role});
      }
    });


    this.socket.on('message', (data) => {
      const { message, role, to } = data;
      console.log("messaggio ricevto: " + data.message + ", inviato da: " + data.role + ", messagio per: "+ data.to);
      if (to === 'General') {
        if (!this.chatMessages['General']) {
          this.chatMessages['General'] = [];
        }
        // Aggiungi il messaggio all'array di messaggi della chat corrispondente
        this.chatMessages['General'].push(data);
          // Aggiorna anche la localStorage con i nuovi messaggi
        localStorage.setItem('chatMessages', JSON.stringify(this.chatMessages));
        if ( this.currentChat != to) {
          if (!this.chatNotifications['General']) {
              this.chatNotifications['General'] = 1;
            } else {
              this.chatNotifications['General']++;
            }
        }

        // Aggiorna la chat corrispondente
        this.displayMessages('General');
        }
      else {
      // Se non esiste ancora un array di messaggi per questa chat, creane uno
        if (!this.chatMessages[role]) {
          this.chatMessages[role] = [];
        }
        // Aggiungi il messaggio all'array di messaggi della chat corrispondente

        // Aggiorna la chat corrispondente
        if (role === 'admin') {
          this.chatMessages['White'].push(data);
         // Aggiorna anche la localStorage con i nuovi messaggi
        localStorage.setItem('chatMessages', JSON.stringify(this.chatMessages));
          if ('White'!= this.currentChat) {
            if (!this.chatNotifications['White']) {
              this.chatNotifications['White']= 1;
            } else {
              this.chatNotifications['White']++;
            }
          }
        }
        else {
          this.chatMessages[role].push(data);
          // Aggiorna anche la localStorage con i nuovi messaggi
          localStorage.setItem('chatMessages', JSON.stringify(this.chatMessages));
          if (role != this.currentChat) {
            if (!this.chatNotifications[role]) {
              this.chatNotifications[role] = 1;
            } else {
              this.chatNotifications[role]++;
            }
          }
        }
        this.displayMessages(role);

      }
    });

  },

  sendMessage() {
    console.log(this.currentChat);
    var input = document.getElementById('message-input');
    var messageText = input.value.trim();
    if (messageText !== '') {
      console.log('Ruolo:', this.role);
      console.log('Destinatario:', this.currentChat);
      const msg = { message: messageText, role: this.role, to: this.currentChat};
      if (this.currentChat != 'General') {
        this.chatMessages[this.currentChat].push(msg);
         // Aggiorna anche la localStorage con i nuovi messaggi
         localStorage.setItem('chatMessages', JSON.stringify(this.chatMessages));
      }
      this.socket.emit('message', { message: messageText, role: this.role, to: this.currentChat});
      console.log('Messaggio inviato:', messageText,this.role,this.currentChat);
      input.value = '';
    }
  },
  displayMessages(user) {
    console.log(user);
    // Crea un nuovo array per i messaggi formattati
    let formattedMessages = [];
    if (!this.chatMessages[user]) {
      this.chatMessages[user] = [];
    }
    let formattedMessage = "";
    let cssClass = "";
    // Itera sui messaggi e aggiungi la formattazione desiderata
    for (let mex of this.chatMessages[user]) {

      // Formatta il messaggio come preferisci
      console.log(mex);
      if (mex.role === this.role) {
        formattedMessage  = 'Me: ' + mex.message;
        cssClass = 'me';
      }
      else {
        if (mex.role === 'admin') {
          formattedMessage = "White: " + mex.message;
        }
        else {
          formattedMessage = mex.role + ": " + mex.message;
        }

        cssClass = 'other';
      }

      // Aggiungi il messaggio formattato e la classe CSS al nuovo array
      formattedMessages.push({ text: formattedMessage, class: cssClass });
    }

    // Restituisci il nuovo array di messaggi formattati
    return formattedMessages;
  },

  clearLocalStorage() {
    localStorage.removeItem('chatMessages');
    console.log("LocalStorage dei messaggi delle chat svuotata.");
  },

  async fetchUserData() {
      try {
        const response = await this.$axios.get("http://localhost:3002/my/", { withCredentials: true });
        this.name = response.data.name || response.data.first_name;
        this.isGoogleAuth = response.data.isGoogleAuth || false;
        this.isLogged = true;
      } catch (error) {
        console.error("Errore nel recupero dei dati dell'utente:", error);
      }
    },

    async fetchUserRole() {
      try {
        const response = await this.$axios.get("http://localhost:3002/my/role", { withCredentials: true });
        this.role = response.data.role;
        this.getDataForSidebar();
      } catch (error) {
        console.error("Errore nel recupero del ruolo dell'utente:", error);
      }
    }

  },

  watch: {
  // Watcher per rilevare i cambiamenti di onGoingExercitation
  onGoingExercitation(newValue, oldValue) {
    // Se il valore precedente era true e il nuovo valore è false
    if (oldValue && !newValue) {
      // Svuota completamente la localStorage dei messaggi delle chat
      this.clearLocalStorage();
    }
  },
},

  mounted() {
    let isGoogleAuth = false;
    const token = document.cookie.split(";").find((item) => item.trim().startsWith("token="));

    this.$nextTick(() => {
    const messageInput = document.getElementById('message-input');
    if (messageInput) {
      messageInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
          this.sendMessage();
        }
      });
    } else {
      console.error('Elemento con ID "message-input" non trovato.');
    }
  });


    this.$axios
      .get("/my/", { withCredentials: true })
      .then((myData) => {
        console.log(myData.data);
        this.userId = myData.data.id;
        this.nickname = myData.data.nickname;

      }).catch((error) => {
        console.log(error);
      });

      this.$axios
      .get("/my/role", { withCredentials: true })
      .then((myRoleData) => {
        this.role = myRoleData.data.role;

        // Verifica se l'utente è autorizzato per mostrare il pulsante della chat
        if (this.role === "admin" || this.role === "blue") {
          this.showChatButton = true;
        }

        // Una volta ottenuto il ruolo, procedi con il recupero dei dati dell'esercitazione in corso
        return this.$axios.get("/ongoing");
      })
      .then((onGoingData) => {
        // Assegna i dati dell'esercitazione in corso alle variabili di dati del componente
        this.onGoingExercitation = onGoingData.data;
        this.exercitation = onGoingData.data;
        this.updateTimeLeft();
        setInterval(this.updateTimeLeft, 1000);
        if (this.role === "admin" || this.role === "red") {
          return this.$axios.get(
            `/exercitations/${this.onGoingExercitation.id}/reports?type=red`
          );
        }
      })
      .then((redReportsData) => {
        if (redReportsData) {
          this.reports = redReportsData.data;
        }
        if (this.role === "admin" || this.role === "blue") {
          return this.$axios.get(
            `/exercitations/${this.onGoingExercitation.id}/reports?type=blue`
          );
        }
      })
      .then((blueReportsResponse) => {
        if (blueReportsResponse) {
          this.blueReps = blueReportsResponse.data;
        }
      })
      .catch((error) => {
        console.log(error);
      });

    

  this.$axios.get("/users")
  .then(response => {
    this.userList.push('General');
    this.chatMessages['General'] = [];
    this.loadSavedMessages();
    this.displayMessages('General');
    // Initialize chat messages object for each user
    if (this.role ==="admin") {
      response.data.forEach(user => {
        // For each user, make a request to fetch their role using their ID
        this.$axios.get(`/api/user/${user.id}/teamrole`)
          .then(roleResponse => {
            // Once you get the role response, you can add the user to the userList if their role is 'blue'
            if (roleResponse.data.role === 'Blue') {
              this.userList.push(user.nickname);
              this.chatMessages[user.nickname] = []; // Initialize an empty array for each user
              this.loadSavedMessages();
              this.displayMessages(user.nickname);
            }
          })
          .catch(error => {
            console.error("Error fetching user role:", error);
          });
      });
    }
    else {
      this.userList.push('White');
      this.chatMessages['White'] = [];
      this.loadSavedMessages();
      this.displayMessages('White');
    }
  })
  .catch(error => {
    console.error("Error fetching user list:", error);
  });
  this.connectToSocket();
  this.fetchUserData();
  this.fetchUserRole();
  },

  components: {
    ADTree,
    TimelineComponent,
  },
};

</script>

<style scoped>
.container {
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
}

.v-card {
  width: 45%;
}

@media only screen and (min-width: 768px) {
  div#alberi {
    display: flex;
    justify-content: center;
    align-items: center;
  }
}

@media only screen and (max-width: 767px) {
  div#alberi {
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  .vr {
    transform: rotate(90deg);
  }
}


    .body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }
    .container-chat {
    display: flex;
    flex-direction: column;
    height: 100vh;
    font-family: 'Roboto', sans-serif;
    max-height: 500px;
    overflow: auto; 
    margin-right: 80px;
    box-shadow: 0 0 20px rgba(9, 147, 240, 0.3);
    border-radius: 12px;
    border: 2px solid rgba(9, 147, 240, 0.3);
}

.header {
    background-color: #0088cc;
    color: white;
    padding: 10px 20px;
    display: flex;
    align-items: center;
}

.header-text {
    font-weight: bold;
    flex-grow: 1;
}

.header-icon {
    font-size: 1.5em;
}

.main-content {
    display: flex;
    flex: 1;
}

.user-list {
    flex: 1;
    background-color: #f5f5f5;
    padding: 20px;
    overflow-y: auto;
    max-width: 150px;
}

.user-list-item {
    display: flex;
    align-items: center;
    padding: 10px;
    cursor: pointer;
    border-radius: 5px;
    color: #0088cc;
}

.user-list-item:hover {
    background-color: #e0e0e0;
    color: #0088cc;
}

.user-icon {
    margin-right: 10px;
}

.chat {
    flex: 3;
    padding: 20px;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
}

.message {
    background-color: #DCF8C6;
    padding: 8px;
    border-radius: 15px;
    margin-bottom: 10px;
    max-width: 70%;
    position: relative;
}

.message.me {
    background-color: #7ec1ff;
    align-self: flex-start;
}

.message.other {
    background-color: #ffa4a4;
    align-self: flex-end;
}

.input-container {
    background-color: #f5f5f5;
    padding: 10px 20px;
    display: flex;
    align-items: center;
}

.input-container input {
    width: calc(100% - 20px);
    padding: 10px;
    border: none;
    border-radius: 15px;
    margin-right: 10px;
}

.input-container button {
    padding: 10px 20px;
    border: none;
    border-radius: 15px;
    background-color: #0088cc;
    font-size: 1.2em;
    color: white;
    font-weight: bold;
    cursor: pointer;
}
.input-container button:hover {
    background-color: #e0e0e0;
    color:#0088cc;
}

.selected {
    background-color: #0088cc;
    color: white;
    font-weight: bold;
}

.notification-badge {
  background-color: #ff4929; /* Colore rosso vivace */
  color: white;
  font-size: 0.8em;
  padding: 0.2em 0.5em;
  border-radius: 50%;
  margin-left: 0.5em;
  box-shadow: 0 0 3px rgba(0, 0, 0, 0.3); /* Ombra leggera */
}



</style>