<template>
  <div>
    <BannerBar @logout="logout" :name="name" />
    <SideLeftBar :role="role" :ongoing="ongoing" />
    <main class="main">
      <RouterView :role="role" />
    </main>
  </div>
</template>

<script>
import SideLeftBar from "./components/SideLeftBar.vue";
import BannerBar from "./components/BannerBar.vue";

export default {
  components: { SideLeftBar, BannerBar },
  data() {
    return {
      role: "",
      name: "",
      ongoing: 0,
      isLogged: false,
    };
  },
  methods: {
    logout() {
      // delete cookie
      if (
        document.cookie.split(";").some((item) => item.trim().startsWith("token="))
      ) {
        document.cookie =
          "token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
      }
      this.deleteCookie('token'); // cookie rimosso
      this.role = "";
      window.location.href = "/";
    },

    getDataForSidebar() {
      // if cookie token is set
      if (
        document.cookie.split(";").some((item) => item.trim().startsWith("token="))
      ) {
        this.$axios
          .get("/ongoing")
          .then((response) => {
            this.ongoing = response.data.id;
          })
          .catch((e) => {
            this.errormsg = e.toString();
            this.ongoing = 0;
          });
      }
    },
    async fetchUserData() {
      try {
        const response = await this.$axios.get("http://localhost:3002/my/", { withCredentials: true });
        this.name = response.data.name || response.data.first_name;
        this.isGoogleAuth = response.data.isGoogleAuth || false;
        this.isLogged = true;
        console.log("APPVUE: is google AUTHHHHHHHHHHHHHHHHHHHHHHHHHH", this.isGoogleAuth);
      } catch (error) {
        console.error("Errore nel recupero dei dati dell'utente:", error);
      }
    },

    async fetchUserRole() {
      try {
        const response = await this.$axios.get("http://localhost:3002/my/role", { withCredentials: true });
        this.role = response.data.role;
        this.getDataForSidebar();
      } catch (error) {
        console.error("Errore nel recupero del ruolo dell'utente:", error);
      }
    },

    deleteCookie(name) {
      document.cookie = name + '=; Max-Age=-99999999;';
    }

  },
  mounted() {
    let isGoogleAuth = false;
    const token = document.cookie.split(";").find((item) => item.trim().startsWith("token="));

  if (token) {
    console.log("Token JWT trovato:", token);

    // Controlla se l'utente è loggato con Google
    isGoogleAuth = window.location.search.includes('auth=google');

  }

  this.fetchUserData();
  this.fetchUserRole();

    // Recupera il nome dell'utente
    this.$axios
      .get("/my/", { withCredentials: true })
      .then((response) => {
        this.name = response.data.first_name;
      })
      .then(() => {
        // Recupera il ruolo dell'utente
        return this.$axios.get("/my/role", { withCredentials: true });
      })
      .then((response) => {
        // Imposta il ruolo dell'utente
        this.role = response.data.role;

        // Esegui azioni dipendenti dal ruolo dell'utente qui
        this.getDataForSidebar();
      })
      .catch((e) => {
        this.errormsg = e.toString();
      });

    /* execute method every five seconds */
    setInterval(this.getDataForSidebar, 5000);
  },
};
</script>
