const express = require('express');
const session = require('express-session');
const passport = require('passport');
const path = require('path');
const cors = require('cors');
const authRoutes = require('./config/auth-routes');
const passportSetup = require('./config/passport-setup');
const authenticateToken = require('./config/authenticateToken');
const cookieParser = require('cookie-parser');

const app = express();

app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

app.use(cors({
  origin: 'http://localhost:5173',
  credentials: true
}));

app.use((req, res, next) => {
  res.setHeader("Content-Security-Policy", "default-src 'self'; img-src 'self';");
  next();
});

app.use(session({
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: true
}));

app.use(passport.initialize());
app.use(passport.session());

app.use(cookieParser());

app.use(authRoutes);

app.get('/', (req, res) => {
  res.send('Home Page');
});

app.get('/session', (req, res) => {
  res.json(req.session);
});

app.get('/user', (req, res) => {
  res.json(req.user);
});

app.get('/my/', authenticateToken, (req, res) => {
  res.json(req.user);
});

app.get('/my/role', authenticateToken, (req, res) => {
  res.json({ role: req.user.role });
});

app.listen(3002, () => {
  console.log('server listening on 3002');
});
