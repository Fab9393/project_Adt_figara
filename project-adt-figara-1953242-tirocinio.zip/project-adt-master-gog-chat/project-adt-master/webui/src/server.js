// server.js
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();

const httpServer = http.createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "http://localhost:5173",
    methods: ['GET', 'POST']
  }
});

app.use(cors());

const sockets = {}; // Oggetto per memorizzare i socket di tutti gli utenti

io.on('connection', (socket) => {
  console.log('Nuova connessione:', socket.id);

  socket.on('role', (data) => {
    const { userId, role } = data;
    if (role === 'admin') {
      sockets['white'] = socket;
    } else {
      sockets[role] = socket;
    }
    console.log(`Ruolo assegnato: ${role} a ${userId}`);
  });

  socket.on('message', (data) => {
    console.log('Messaggio ricevuto da:', data);
    const { message, role, to } = data;
    if (to === 'White') {
      // Inoltra il messaggio all'admin
      sockets['white'].emit("message", data);
      console.log("mando messaggio a white", data);
    } else if (to === 'General') {
      // Inoltra il messaggio a tutti gli utenti
      for (let nickname in sockets) {
        sockets[nickname].emit("message", data);
      }
      console.log("mando messaggio su general", data);
    } else {
      if (sockets[to]) {
        sockets[to].emit("message", data);
        console.log("mando messaggio a marietto", data);
      }
    }
  });

  socket.on('disconnect', () => {
    console.log('Disconnesso:', socket.id);
    if (sockets['white'] && sockets['white'].id === socket.id) {
      delete sockets['white'];
    } else {
      for (let nick in sockets) {
        if (sockets[nick].id === socket.id) {
          delete sockets[nick];
          break;
        }
      }
    }
  });
});

httpServer.listen(3001, () => {
  console.log(`Server in ascolto sulla porta 3001`);
});
